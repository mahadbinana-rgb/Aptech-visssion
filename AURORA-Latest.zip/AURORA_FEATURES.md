# AURORA vNext feature map

## CodeSpace
- Private and company-shared project workspaces
- File tree + local editor + autosized line gutter
- Project-aware Ollama AI that can create/update files
- AI actions are permission-gated by backend rules
- Company project permissions: Viewer / Commenter / Editor / Developer
- Project ownership and role-level access controls

## Roles
- Admin: full company and project access; can delete any project
- Manager: broad operational access; full company-project access; cannot remove admins/managers
- Lead: people visibility and team-level management
- Employee: standard work access; can create private/company projects and delete their own projects

## Privacy
- MongoDB defaults to localhost
- Ollama defaults to localhost
- Browser no longer talks directly to Ollama
- Company chat file storage is local
- External font CDN removed
- Original uploaded `.env` is not included in this deliverable

## Existing AURORA modules kept
Dashboard, tasks, notes, reminders, company chat, recognitions, activity feed, AI hub, AI logs, profiles, analytics, and administration.
