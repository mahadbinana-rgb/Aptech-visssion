# AURORA Local Privacy

AURORA is designed to run as a local/private workspace.

- MongoDB defaults to `127.0.0.1`.
- Ollama defaults to `127.0.0.1:11434`.
- CodeSpace AI requests go through the AURORA backend; the browser does not call Ollama directly.
- CodeSpace sends the project files stored in the current AURORA project to the local Ollama instance to generate edits.
- Company chat uploads are stored under the local `backend/uploads/chat` directory instead of Cloudinary.
- No external font CDN is used by the frontend.

For strict air-gapped operation, run AURORA, MongoDB, Ollama, and the frontend/backend on the same machine or trusted local network and do not configure external integrations.
