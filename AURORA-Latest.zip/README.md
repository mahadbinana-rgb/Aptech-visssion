# AURORA — Private Productivity + CodeSpace

AURORA is a local-first MERN workspace for company productivity, private AI, collaboration, and project development.

## Highlights

- CodeSpace: project/file editor with project-aware local Ollama coding AI.
- Private projects: owned by the creator; local AI remains available without company sharing.
- Company projects: share with specific coworkers using Viewer, Commenter, Editor, or Developer permissions.
- Roles: Admin, Manager, Lead, Employee. Admins have full company management access; managers have broad operational/project access; leads manage people visibility and assigned work.
- Admin/manager/lead access is separated by backend role middleware, not only hidden frontend buttons.
- Company chat uploads are stored locally under `backend/uploads/chat`.
- No Cloudinary runtime integration and no external font CDN.
- AI requests are server-mediated so the browser does not call Ollama directly.

## Local setup

1. Start MongoDB locally.
2. Start Ollama locally and make sure the model in `backend/.env` is installed.
3. `cd backend && npm install && npm start`
4. `cd frontend && npm install && npm run dev`

The default backend is `http://localhost:1000` and the default Ollama endpoint is `http://127.0.0.1:11434/api/generate`.

For strict no-internet operation, keep all configured AI/database/storage services on localhost or your trusted private LAN and do not add external integrations.
