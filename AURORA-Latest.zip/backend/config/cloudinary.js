// Cloudinary integration intentionally removed. AURORA stores uploaded chat files locally for privacy.
module.exports = null;
