const mongoose = require('mongoose');

const connectDB = async () => {
  const uri = "mongodb+srv://test:123@cluster0.bnd6aos.mongodb.net/?appName=Cluster0";
  try {
    await mongoose.connect(uri);
    console.log('MongoDB connected');
  } catch (error) {
    console.error('MongoDB connection failed:', error.message);
    process.exit(1);
  }
};

module.exports = connectDB;