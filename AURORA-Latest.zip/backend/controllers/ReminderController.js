const Reminder = require("../models/Reminder");

// CREATE
const createReminder = async (req, res) => {
  try {
    const reminder = await Reminder.create({
      userId: req.user.id,
      companyId: req.user.companyId,
      title: req.body.title,
      message: req.body.message,
      dueTime: req.body.dueTime,
    });
    res.status(201).json(reminder);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET ALL
const getReminders = async (req, res) => {
  try {
    const reminders = await Reminder.find({ userId: req.user?.id }).sort({ dueTime: 1 });
    res.json(reminders);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// DELETE
const deleteReminder = async (req, res) => {
  try {
    await Reminder.findByIdAndDelete(req.params.id);
    res.json({ message: "Deleted" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
const getDueReminders = async (
  req,
  res
) => {
  try {
    const reminders = await Reminder.find({
      sent: true,
      notified: { $ne: true }
    });

    res.json(reminders);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
const markReminderNotified =
  async (req, res) => {

  await Reminder.findByIdAndUpdate(
    req.params.id,
    {
      notified: true
    }
  );

  res.json({
    success: true
  });
};

module.exports = {
  createReminder,
  getReminders,
  deleteReminder,
  getDueReminders,
  markReminderNotified
};