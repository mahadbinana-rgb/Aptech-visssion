const Activity = require('../models/Activity');

const getActivities = async (req, res, next) => {
  try {
    const query = ['admin', 'manager'].includes(req.user.role) ? { companyId: req.user.companyId } : { userId: req.user.id, companyId: req.user.companyId };
    const activities = await Activity.find(query).sort({ timestamp: -1 }).populate('userId', 'name email');
    res.json(activities);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getActivities,
};