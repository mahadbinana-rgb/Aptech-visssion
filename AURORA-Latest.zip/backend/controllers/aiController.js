const AiLog = require('../models/AiLog');
const aiService = require('../services/aiService');

/**
 * Generate AI response using the AI service
 * Handles validation, calls Ollama, and logs the request
 */
const generateAiResponse = async (req, res, next) => {
  try {
    const { type, input } = req.body;

    // 1. Strict Validation
    if (!type || !input || typeof input !== 'string') {
      return res.status(400).json({
        success: false,
        message: 'Both "type" and a valid string "input" are required',
      });
    }

    // 2. Generate AI response
    const response = await aiService.askAI(type, input.trim());

    // 3. Isolated Background Logging (Prevents DB issues from blocking the user response)
    let logData = null;
    try {
      const log = await AiLog.create({
        userId: req.user?.id || null,
        toolType: type,
        prompt: input,
        companyId: req.user?.companyId || null,
        response,
      });
      logData = { id: log._id, createdAt: log.createdAt };
    } catch (dbError) {
      console.error('[AI Controller] Logging Failed:', dbError);
      // Log fails silently to the user so they still get their AI response
    }

    // 4. Success Response
    return res.status(201).json({
      success: true,
      response,
      ...(logData && { log: logData }),
    });

  } catch (error) {
    console.error('[AI Controller] Error:', error);

    // Guard against undefined error messages
    const errorMsg = error instanceof Error ? error.message : String(error);

    // 5. Specific Error Classifications
    if (errorMsg.includes('Invalid request type')) {
      return res.status(400).json({ success: false, message: errorMsg });
    }

    if (errorMsg.includes('Ollama')) {
      return res.status(503).json({ success: false, message: 'AI service is temporarily unavailable' });
    }

    next(error);
  }
};


/**
 * Get all AI logs (paginated)
 * Admin: see all logs
 * Users: see only their logs
 */
const getAiLogs = async (req, res, next) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const skip = (page - 1) * limit;

    let query;

    if (['admin', 'manager'].includes(req.user.role)) {
      query = {
        companyId: req.user.companyId
      };
    } else {
      query = {
        userId: req.user.id,
        companyId: req.user.companyId
      };
    }

    const logs = await AiLog.find(query)
      .sort({ createdAt: -1 })
      .limit(limit)
      .skip(skip)
      .populate('userId', 'name email');

    const total = await AiLog.countDocuments(query);

    res.json({
      success: true,
      logs,
      pagination: {
        total,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    next(error);
  }
};

const getaiLogsForEmployee = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const skip = (page - 1) * limit;


    const query = { userId: req.user.id, companyId: req.user.companyId };


    const [logs, total] = await Promise.all([
      AiLog.find(query)
        .sort({ createdAt: -1 })
        .limit(limit)
        .skip(skip)
        .populate('userId', 'name email'),
      AiLog.countDocuments(query)
    ]);

    res.json({
      success: true,
      logs,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    next(error);
  }
};
const createLog = async (req, res, next) => {
  try {
    const { toolType, prompt, response } = req.body;

    const newLog = await AiLog.create({
      userId: req.user.id,
      toolType,
      prompt,
      response
    });

    res.status(201).json({
      success: true,
      log: newLog
    });
  } catch (error) {
    next(error);
  }
}
/**
 * Get total AI requests count
 */
const getTotalAIRequests = async (req, res, next) => {
  try {
    const total = await AiLog.countDocuments({
      companyId: req.user.companyId
    });
    res.json({ success: true, total });
  } catch (error) {
    next(error);
  }
};


/**
 * Get most used AI tool
 */
const getMostUsedTool = async (req, res, next) => {
  try {
    const result = await AiLog.aggregate([
      {
        $match: {
          companyId: req.user.companyId
        }
      },
      {
        $group: {
          _id: '$toolType',
          count: { $sum: 1 }
        }
      },
    ]);

    const mostUsed = result.length > 0 ? result[0] : null;
    res.json({ success: true, mostUsed });
  } catch (error) {
    next(error);
  }
};

/**
 * Get recent AI requests
 */
const getRecentRequests = async (req, res, next) => {
  try {
    const { limit = 10 } = req.query;

    const recent = await AiLog.find({
      companyId: req.user.companyId
    })
      .sort({ createdAt: -1 })
      .limit(parseInt(limit))
      .populate('userId', 'name email');

    res.json({ success: true, recent });
  } catch (error) {
    next(error);
  }
};

/**
 * Get most active AI users
 */
const getMostActiveUsers = async (req, res, next) => {
  try {
    const { limit = 10 } = req.query;

    const activeUsers = await AiLog.aggregate([
      {
        $match: {
          companyId: req.user.companyId
        }
      },
      {
        $group: {
          _id: '$userId',
          count: { $sum: 1 },
        },
      },
      { $sort: { count: -1 } },
      { $limit: parseInt(limit) },
      {
        $lookup: {
          from: 'users',
          localField: '_id',
          foreignField: '_id',
          as: 'userInfo',
        },
      },
      {
        $unwind: '$userInfo',
      },
      {
        $project: {
          userId: '$_id',
          name: '$userInfo.name',
          email: '$userInfo.email',
          requestCount: '$count',
          _id: 0,
        },
      },
    ]);

    res.json({ success: true, activeUsers });
  } catch (error) {
    next(error);
  }
};

const addAiLog = async (req, res, next) => {
  try {
    const { toolType, prompt, response } = req.body;
    if (!toolType || !prompt || !response) {
      return res.status(400).json({ success: false, message: 'toolType, prompt, and response are required' });
    }
    const log = await AiLog.create({
      userId: req.user.id,
      companyId: req.user.companyId,
      toolType,
      prompt,
      response
    });
    res.json({ success: true, log });
  } catch (error) {
    console.error('Add AI Log Error:', error);
  }
}
/**
 * Get AI usage statistics
 */
const getAIStatistics = async (req, res, next) => {
  try {
    const totalRequests = await AiLog.countDocuments({
      companyId: req.user.companyId
    });
    const toolStats = await AiLog.aggregate([
      {
        $group: {
          _id: '$toolType',
          count: { $sum: 1 },
        },
      },
      { $sort: { count: -1 } },
    ]);

    const recentRequests = await AiLog.find()
      .sort({ createdAt: -1 })
      .limit(5)
      .populate('userId', 'name email');

    res.json({
      success: true,
      statistics: {
        totalRequests,
        toolStats,
        recentRequests,
      },
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  generateAiResponse,
  getAiLogs,
  getTotalAIRequests,
  getMostUsedTool,
  getRecentRequests,
  getMostActiveUsers,
  getAIStatistics,
  addAiLog,
  getaiLogsForEmployee
};