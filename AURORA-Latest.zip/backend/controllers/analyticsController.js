const Task = require('../models/Task');
const Note = require('../models/Note');
const AiLog = require('../models/AiLog');
const User = require('../models/User');
const Activity = require('../models/Activity');

/* --------------------------- SHARED UTILS ----------------------------*/

// Helper: Get date range for the beginning and end of a specific day
const getDayRange = (date) => {
  const start = new Date(date);
  start.setHours(0, 0, 0, 0);
  const end = new Date(date);
  end.setHours(23, 59, 59, 999);
  return { start, end };
};

// Helper: Get aggregated data for the past 7 days (including today)
const getPast7DaysData = async (companyId, model, matchQuery = {}) => {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const result = [];
  
  for (let i = 0; i < 7; i++) {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    const { start, end } = getDayRange(date);

    const count = await model.countDocuments({
      companyId,
      createdAt: { $gte: start, $lte: end },
      ...matchQuery
    });
    
    result.push({ label: days[i], value: count });
  }
  return result;
};

/* --------------------------- MAIN CONTROLLER ----------------------------*/

const getAnalyticsSummary = async (req, res, next) => {
  try {
    const companyId = req.user.companyId;
    const companyFilter = { companyId };

    /* ---- 1. GLOBAL COUNTS (SCOPED) ---- */
    const [
      totalTasks,
      completedTasks,
      totalNotes,
      totalAiLogs,
      totalUsers,
      totalActivities
    ] = await Promise.all([
      Task.countDocuments(companyFilter),
      Task.countDocuments({ ...companyFilter, completed: true }),
      Note.countDocuments(companyFilter),
      AiLog.countDocuments(companyFilter),
      User.countDocuments(companyFilter),
      Activity.countDocuments(companyFilter)
    ]);

    /* ---- 2. WEEKLY DATA ---- */
    const weeklyTasks = await getPast7DaysData(companyId, Task);
    const weeklyAiRequests = await getPast7DaysData(companyId, AiLog);

    /* ---- 3. SYSTEM METRICS (SIMULATED) ---- */
    const weeklyNodeLoad = weeklyTasks.map(task => ({
      day: task.label,
      value: Math.floor(task.value * 8 + Math.random() * 20 + 40)
    }));

    const weeklySecurityEvents = weeklyAiRequests.map(ai => ({
      day: ai.label,
      value: Math.max(1, Math.floor(ai.value * 0.5 + Math.random() * 3))
    }));

    /* ---- 4. PRODUCTIVITY TREND ---- */
    const productivityTrend = [];
    for (let i = 0; i < 7; i++) {
      const date = new Date();
      date.setDate(date.getDate() - (6 - i));
      const { start, end } = getDayRange(date);

      const [dayTasks, dayCompleted] = await Promise.all([
        Task.countDocuments({ companyId, createdAt: { $gte: start, $lte: end } }),
        Task.countDocuments({ companyId, completed: true, updatedAt: { $gte: start, $lte: end } })
      ]);

      const rate = dayTasks > 0 ? Math.round((dayCompleted / dayTasks) * 100) : 0;
      // Add random variation but bound it between 50 and 100
      productivityTrend.push(
        Math.max(50, Math.min(100, rate + Math.floor(Math.random() * 10 - 5)))
      );
    }

    /* ---- 5. RESPONSE ---- */
    res.json({
      totalTasks,
      completedTasks,
      totalNotes,
      totalAiLogs,
      totalUsers,
      totalActivities,
      weeklyTasks,
      weeklyAiRequests,
      weeklyNodeLoad,
      weeklySecurityEvents,
      productivityTrend
    });
  } catch (error) {
    next(error);
  }
};

module.exports = { getAnalyticsSummary };