const path = require('path');
const CompanyMessage = require("../models/CompanyMessage");
const ChatChannel = require("../models/ChatChannel");
const { logActivity } = require("../services/activityService");

// ===================== CHANNELS =====================

// GET all channels for a company
exports.getChannels = async (req, res) => {
  try {
    const { companyId } = req.params;
    if (String(companyId) !== String(req.user.companyId)) return res.status(403).json({ message: 'Access denied' });
    const channels = await ChatChannel.find({ companyId }).sort({ createdAt: 1 });
    res.json(channels);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch channels" });
  }
};

// CREATE channel (admin only — checked in routes)
exports.createChannel = async (req, res) => {
  try {
    const { companyId, name, description } = req.body;
    if (!name || !name.trim()) {
      return res.status(400).json({ message: "Channel name is required" });
    }
    const channel = await ChatChannel.create({
      name: name.trim(),
      description: description || "",
      companyId,
      createdBy: req.user._id,
    });

    // Log activity
    const io = req.app.get("io");
    const action = `${req.user.role === "admin" ? "Admin" : req.user.role === "manager" ? "Manager" : req.user.name} created channel #${name.trim()}`;
    await logActivity({ userId: req.user._id, action, io, companyId });

    res.status(201).json(channel);
  } catch (err) {
    res.status(500).json({ message: err.message || "Failed to create channel" });
  }
};

// DELETE channel (admin only)
exports.deleteChannel = async (req, res) => {
  try {
    const { id } = req.params;
    const channel = await ChatChannel.findById(id);
    if (!channel) return res.status(404).json({ message: "Channel not found" });

    const channelName = channel.name;
    const companyId = channel.companyId;

    await ChatChannel.findByIdAndDelete(id);
    // Also delete all messages in that channel
    await CompanyMessage.deleteMany({ roomId: id });

    // Log activity
    const io = req.app.get("io");
    const action = `${req.user.role === "admin" ? "Admin" : req.user.role === "manager" ? "Manager" : req.user.name} deleted channel #${channelName}`;
    await logActivity({ userId: req.user._id, action, io, companyId });

    res.json({ message: "Channel deleted" });
  } catch (err) {
    res.status(500).json({ message: "Failed to delete channel" });
  }
};

// ===================== MESSAGES =====================

// GET messages (protected)
exports.getMessages = async (req, res) => {
  try {
    const { companyId, roomId } = req.params;
    if (String(companyId) !== String(req.user.companyId)) return res.status(403).json({ message: 'Access denied' });
    const messages = await CompanyMessage.find({
      companyId,
      roomId,
    }).sort({ createdAt: 1 });
    res.json(messages);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch messages" });
  }
};

// SEND message (REST fallback)
exports.sendMessage = async (req, res) => {
  try {
    console.log("BODY:", req.body);
    console.log("FILE:", req.file);

    let fileData = null;
    if (req.file) {
      fileData = {
        url: `/uploads/chat/${path.basename(req.file.path)}`,
        name: req.file.originalname,
        fileType: req.file.mimetype, // Match the new key name
        size: req.file.size
      };
    }

    const msg = await CompanyMessage.create({
      companyId: req.user.companyId,
      roomId: req.body.roomId || "general",
      message: req.body.message,
      file: fileData,                 // Explicitly set your object here
      senderId: req.user._id,
      senderName: req.user.name,
      role: req.user.role
    });

    res.json(msg);
  } catch (err) {
    console.error(err);
    res.status(500).json({
      message: "Failed to send message"
    });
  }
};

// DELETE message (admin only)
exports.deleteMessage = async (req, res) => {
  try {
    const { id } = req.params;
    const msg = await CompanyMessage.findById(id);
    if (!msg) return res.status(404).json({ message: "Message not found" });

    const { companyId } = msg;

    await CompanyMessage.findByIdAndDelete(id);

    // Log activity
    const io = req.app.get("io");
    const action = `${req.user.role === "admin" ? "Admin" : req.user.role === "manager" ? "Manager" : req.user.name} deleted a message`;
    await logActivity({ userId: req.user._id, action, io, companyId });

    res.json({ message: "Message deleted" });
  } catch (err) {
    res.status(500).json({ message: "Failed to delete message" });
  }
};