const Project = require('../models/Project');
const User = require('../models/User');
const aiService = require('../services/aiService');
const { hasRoleLevel } = require('../middleware/roleMiddleware');
const { canDeleteProject, canEditProject, permissionFor } = require('../services/projectAccessService');
const { logActivity } = require('../services/activityService');

const safeProject = (project) => ({
  ...project.toObject(),
  fileCount: project.files.length,
});

const createProject = async (req, res, next) => {
  try {
    const { name, description = '', kind = 'private', files = [], rootFile = '' } = req.body;
    if (!name?.trim()) return res.status(400).json({ message: 'Project name is required' });
    if (!['private', 'company'].includes(kind)) return res.status(400).json({ message: 'Invalid project kind' });
    if (kind === 'company' && !req.user.companyId) return res.status(400).json({ message: 'Company projects require a company' });
    const normalizedFiles = Array.isArray(files) ? files.slice(0, 500).map((file) => ({
      path: String(file.path || '').trim(),
      content: String(file.content || ''),
      language: String(file.language || 'text'),
      updatedBy: req.user._id,
    })).filter((file) => file.path) : [];

    const project = await Project.create({
      name: name.trim(),
      description,
      kind,
      companyId: kind === 'company' ? req.user.companyId : null,
      ownerId: req.user._id,
      files: normalizedFiles,
      rootFile: rootFile || normalizedFiles[0]?.path || '',
    });

    await logActivity({
      userId: req.user._id,
      companyId: req.user.companyId,
      io: req.app.get('io'),
      action: `${req.user.name} created ${kind} CodeSpace project "${project.name}"`,
    });

    res.status(201).json(safeProject(project));
  } catch (error) { next(error); }
};

const listProjects = async (req, res, next) => {
  try {
    const query = hasRoleLevel(req.user, 'admin')
      ? {}
      : hasRoleLevel(req.user, 'manager')
        ? { $or: [{ ownerId: req.user._id, kind: 'private' }, { companyId: req.user.companyId, kind: 'company' }] }
        : { $or: [{ ownerId: req.user._id }, { companyId: req.user.companyId, kind: 'company' }] };
    const projects = await Project.find(query).sort({ updatedAt: -1 });
    const visible = projects.filter((project) => permissionFor(project, req.user));
    res.json(visible.map(safeProject));
  } catch (error) { next(error); }
};

const getProject = async (req, res) => {
  res.json({ ...safeProject(req.project), permission: permissionFor(req.project, req.user) });
};

const upsertFile = async (req, res, next) => {
  try {
    if (!canEditProject(req.project, req.user)) return res.status(403).json({ message: 'You do not have edit permission for this project' });
    const { path, content = '', language = 'text' } = req.body;
    if (!path?.trim()) return res.status(400).json({ message: 'File path is required' });
    const normalized = path.trim().replace(/^[/\\]+/, '').replace(/\\/g, '/');
    if (normalized.includes('..')) return res.status(400).json({ message: 'Invalid file path' });

    const file = req.project.files.find((entry) => entry.path === normalized);
    if (file) {
      file.content = String(content);
      file.language = String(language);
      file.updatedBy = req.user._id;
      file.updatedAt = new Date();
    } else {
      req.project.files.push({ path: normalized, content: String(content), language: String(language), updatedBy: req.user._id });
    }
    if (!req.project.rootFile) req.project.rootFile = normalized;
    await req.project.save();
    res.json(safeProject(req.project));
  } catch (error) { next(error); }
};

const deleteFile = async (req, res, next) => {
  try {
    if (!canEditProject(req.project, req.user)) return res.status(403).json({ message: 'You do not have edit permission for this project' });
    req.project.files = req.project.files.filter((file) => file.path !== req.params.path);
    if (req.project.rootFile === req.params.path) req.project.rootFile = req.project.files[0]?.path || '';
    await req.project.save();
    res.json(safeProject(req.project));
  } catch (error) { next(error); }
};

const updateProject = async (req, res, next) => {
  try {
    if (!canEditProject(req.project, req.user)) return res.status(403).json({ message: 'You do not have edit permission for this project' });
    const { name, description, status, rootFile, collaborators } = req.body;
    if (name !== undefined) req.project.name = String(name).trim().slice(0, 120);
    if (description !== undefined) req.project.description = String(description).slice(0, 1000);
    if (status && ['active', 'archived'].includes(status)) req.project.status = status;
    if (rootFile !== undefined) req.project.rootFile = String(rootFile);

    if (collaborators !== undefined) {
      if (req.project.kind !== 'company') return res.status(400).json({ message: 'Private projects cannot have company collaborators' });
      if (!hasRoleLevel(req.user, 'manager') && String(req.project.ownerId) !== String(req.user._id)) {
        return res.status(403).json({ message: 'Only the project owner or manager can change project access' });
      }
      const ids = [...new Set((Array.isArray(collaborators) ? collaborators : []).map((entry) => String(entry.userId || entry.id || '')))].filter(Boolean);
      const users = await User.find({ _id: { $in: ids }, companyId: req.user.companyId }).select('_id');
      const validIds = new Set(users.map((u) => String(u._id)));
      req.project.collaborators = (Array.isArray(collaborators) ? collaborators : [])
        .filter((entry) => validIds.has(String(entry.userId || entry.id)))
        .map((entry) => ({ userId: entry.userId || entry.id, permission: entry.permission || 'viewer' }));
    }

    await req.project.save();
    res.json({ ...safeProject(req.project), permission: permissionFor(req.project, req.user) });
  } catch (error) { next(error); }
};

const deleteProject = async (req, res, next) => {
  try {
    if (!canDeleteProject(req.project, req.user)) return res.status(403).json({ message: 'You can only delete projects you are allowed to delete' });
    const name = req.project.name;
    await req.project.deleteOne();
    await logActivity({ userId: req.user._id, companyId: req.user.companyId, io: req.app.get('io'), action: `${req.user.name} deleted CodeSpace project "${name}"` });
    res.json({ message: 'Project deleted successfully' });
  } catch (error) { next(error); }
};

const editWithAI = async (req, res, next) => {
  try {
    if (!canEditProject(req.project, req.user)) return res.status(403).json({ message: 'You need edit permission to let CodeSpace AI write changes' });
    if (req.project.settings?.aiWriteEnabled === false) return res.status(403).json({ message: 'AI write actions are disabled for this project' });
    const { prompt, path, mode = 'edit' } = req.body;
    if (!prompt?.trim()) return res.status(400).json({ message: 'AI instruction is required' });

    const result = await aiService.codeSpaceEdit({
      project: req.project,
      prompt: prompt.trim(),
      selectedPath: path || req.project.rootFile || req.project.files[0]?.path || '',
      mode,
    });

    let applied = [];
    if (Array.isArray(result.files) && result.files.length) {
      for (const proposed of result.files.slice(0, 30)) {
        const normalized = String(proposed.path || '').trim().replace(/^[/\\]+/, '').replace(/\\/g, '/');
        if (!normalized || normalized.includes('..') || typeof proposed.content !== 'string') continue;
        const existing = req.project.files.find((file) => file.path === normalized);
        if (existing) {
          existing.content = proposed.content;
          existing.language = proposed.language || existing.language;
          existing.updatedBy = req.user._id;
          existing.updatedAt = new Date();
        } else {
          req.project.files.push({ path: normalized, content: proposed.content, language: proposed.language || 'text', updatedBy: req.user._id });
        }
        applied.push(normalized);
      }
      if (applied.length) await req.project.save();
    }

    await logActivity({ userId: req.user._id, companyId: req.user.companyId, io: req.app.get('io'), action: `${req.user.name} used CodeSpace AI on "${req.project.name}"${applied.length ? ` (${applied.join(', ')})` : ''}` });

    res.json({
      ...result,
      appliedFiles: applied,
      project: safeProject(req.project),
    });
  } catch (error) { next(error); }
};

module.exports = { createProject, listProjects, getProject, updateProject, deleteProject, upsertFile, deleteFile, editWithAI };
