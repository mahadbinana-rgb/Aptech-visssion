const Recognition = require("../models/Recognition");
const User = require("../models/User");
const { logActivity } = require("../services/activityService");

const RECOGNITION_TYPES = {
  employee_of_month: { label: "Employee of the Month", icon: "⭐" },
  most_productive: { label: "Most Productive", icon: "🔥" },
  most_helpful: { label: "Most Helpful", icon: "🤝" },
  best_ideas: { label: "Best Ideas", icon: "💡" },
};

// GET recognitions for a specific employee (employee sees own, admin sees any in company)
exports.getEmployeeRecognitions = async (req, res) => {
  try {
    const targetUserId = req.params.userId;
    const currentUser = req.user;

    // Security: employees can only see their own; admins can see any in their company
    if (currentUser.role !== "admin" && currentUser.id !== targetUserId) {
      return res.status(403).json({ message: "Access denied" });
    }

    // If admin, verify the target user is in the same company
    if (currentUser.role === "admin") {
      const targetUser = await User.findById(targetUserId);
      if (!targetUser || targetUser.companyId.toString() !== currentUser.companyId.toString()) {
        return res.status(403).json({ message: "Access denied: different company" });
      }
    }

    const recognitions = await Recognition.find({ employeeId: targetUserId })
      .sort({ awardedAt: -1 })
      .populate("awardedBy", "name role")
      .populate("employeeId", "name email role");

    res.json(recognitions);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ADMIN: award recognition to an employee
exports.awardRecognition = async (req, res) => {
  try {
    const { employeeId, type, note } = req.body;
    const currentUser = req.user;

    if (currentUser.role !== "admin") {
      return res.status(403).json({ message: "Only admins can award recognitions" });
    }

    const recognitionType = RECOGNITION_TYPES[type];
    if (!recognitionType) {
      return res.status(400).json({ message: "Invalid recognition type" });
    }

    // Verify the employee exists and is in the same company
    const employee = await User.findById(employeeId);
    if (!employee || employee.companyId.toString() !== currentUser.companyId.toString()) {
      return res.status(404).json({ message: "Employee not found in your company" });
    }

    const recognition = await Recognition.create({
      employeeId,
      awardedBy: currentUser._id,
      companyId: currentUser.companyId,
      type,
      label: recognitionType.label,
      icon: recognitionType.icon,
      note: note || "",
    });

    // Log activity
    const io = req.app.get("io");
    const action = `Admin awarded ${recognitionType.icon} ${recognitionType.label} to ${employee.name}`;
    await logActivity({ userId: currentUser._id, action, io, companyId: currentUser.companyId });

    res.status(201).json(recognition);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ADMIN: delete a recognition
exports.deleteRecognition = async (req, res) => {
  try {
    const { id } = req.params;
    if (req.user.role !== "admin") {
      return res.status(403).json({ message: "Only admins can delete recognitions" });
    }
    await Recognition.findByIdAndDelete(id);
    res.json({ message: "Recognition deleted" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// ADMIN: get all recognitions for the company (for overview)
exports.getCompanyRecognitions = async (req, res) => {
  try {
    const recognitions = await Recognition.find({ companyId: req.user.companyId })
      .sort({ awardedAt: -1 })
      .populate("employeeId", "name email role")
      .populate("awardedBy", "name");

    res.json(recognitions);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};