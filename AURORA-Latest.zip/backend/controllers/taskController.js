const Task = require('../models/Task');
const { logActivity } = require('../services/activityService');

/**
 * GET TASKS
 * Admin → sees all company tasks
 * Employee → sees only their tasks
 */
const getTasks = async (req, res, next) => {
  try {
    const filter = {
      companyId: req.user.companyId
    };

    if (!['admin', 'manager'].includes(req.user.role)) {
      filter.assignedTo = req.user._id;
    }

    const tasks = await Task.find(filter)
      .populate('assignedTo', 'name email role');

    res.json(tasks);
  } catch (error) {
    next(error);
  }
};

/**
 * CREATE TASK
 */
const createTask = async (req, res, next) => {
  try {
    const { title, description, priority, assignedTo } = req.body;
    const task = await Task.create({
      title,
      description,
      priority,
      assignedTo: assignedTo || req.user._id,
      companyId: req.user.companyId
    });

    const populated = await task.populate('assignedTo', 'name email role');
    const io = req.app.get("io");
    const action = ['admin', 'manager'].includes(req.user.role)
      ? `Admin assigned a task to employee ${populated.assignedTo.name}`
      : `${req.user.name} assigned a task to employee ${populated.assignedTo.name}`;
    await logActivity({ userId: req.user._id, action, io, companyId: req.user.companyId });

    res.status(201).json(populated);
  } catch (error) {
    console.log(error)
    next(error);
  }
};

/**
 * UPDATE TASK
 */
const updateTask = async (req, res, next) => {
  try {
    const task = await Task.findById(req.params.id);

    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    // security check: same company
    if (task.companyId.toString() !== req.user.companyId.toString()) {
      return res.status(403).json({ message: 'Not allowed (wrong company)' });
    }

    if (
      !['admin', 'manager'].includes(req.user.role) &&
      task.assignedTo.toString() !== req.user._id.toString()
    ) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    Object.assign(task, req.body);
    await task.save();

    const updated = await task.populate('assignedTo', 'name email role');

    res.json(updated);
  } catch (error) {
    next(error);
  }
};

/**
 * DELETE TASK
 */
const deleteTask = async (req, res, next) => {
  try {
    const task = await Task.findById(req.params.id);

    if (!task) {
      return res.status(404).json({ message: 'Task not found' });
    }

    if (task.companyId.toString() !== req.user.companyId.toString()) {
      return res.status(403).json({ message: 'Not allowed (wrong company)' });
    }

    if (
      !['admin', 'manager'].includes(req.user.role) &&
      task.assignedTo.toString() !== req.user._id.toString()
    ) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    await Task.findByIdAndDelete(req.params.id);

    res.json({ message: 'Task removed' });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getTasks,
  createTask,
  updateTask,
  deleteTask,
};