const ROLE_LEVELS = {
  employee: 10,
  lead: 20,
  manager: 30,
  admin: 40,
};

const hasRoleLevel = (user, minimumRole) => {
  if (!user) return false;
  return (ROLE_LEVELS[user.role] || 0) >= (ROLE_LEVELS[minimumRole] || 999);
};

const requireRole = (...roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.role)) {
    return res.status(403).json({ message: 'Insufficient role privileges' });
  }
  next();
};

const requireMinimumRole = (minimumRole) => (req, res, next) => {
  if (!hasRoleLevel(req.user, minimumRole)) {
    return res.status(403).json({ message: `Requires ${minimumRole} privileges or higher` });
  }
  next();
};

module.exports = { ROLE_LEVELS, hasRoleLevel, requireRole, requireMinimumRole };
