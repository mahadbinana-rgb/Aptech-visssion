const mongoose = require('mongoose');

const projectFileSchema = new mongoose.Schema({
  path: { type: String, required: true, trim: true },
  content: { type: String, default: '' },
  language: { type: String, default: 'text' },
  updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  updatedAt: { type: Date, default: Date.now },
}, { _id: false });

const collaboratorSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  permission: {
    type: String,
    enum: ['viewer', 'commenter', 'editor', 'developer'],
    default: 'viewer',
  },
}, { _id: false });

const projectSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 120 },
  description: { type: String, default: '', maxlength: 1000 },
  ownerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  companyId: { type: mongoose.Schema.Types.ObjectId, ref: 'Company', default: null },
  kind: { type: String, enum: ['private', 'company'], default: 'private' },
  status: { type: String, enum: ['active', 'archived'], default: 'active' },
  collaborators: { type: [collaboratorSchema], default: [] },
  files: { type: [projectFileSchema], default: [] },
  rootFile: { type: String, default: '' },
  settings: {
    aiModel: { type: String, default: 'qwen3.5:4b' },
    aiWriteEnabled: { type: Boolean, default: true },
  },
}, { timestamps: true });

projectSchema.index({ companyId: 1, updatedAt: -1 });
projectSchema.index({ ownerId: 1, updatedAt: -1 });

module.exports = mongoose.model('Project', projectSchema);
