const mongoose = require("mongoose");

const recognitionSchema = new mongoose.Schema({
  employeeId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  awardedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  companyId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Company",
    required: true,
  },
  type: {
    type: String,
    enum: ["employee_of_month", "most_productive", "most_helpful", "best_ideas"],
    required: true,
  },
  label: {
    type: String,
    required: true,
  },
  icon: {
    type: String,
    default: "⭐",
  },
  note: {
    type: String,
    default: "",
  },
  awardedAt: {
    type: Date,
    default: Date.now,
  },
});

recognitionSchema.index({ employeeId: 1, awardedAt: -1 });
recognitionSchema.index({ companyId: 1 });

module.exports = mongoose.model("Recognition", recognitionSchema);