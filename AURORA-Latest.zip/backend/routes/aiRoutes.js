const express = require('express');
const {
  generateAiResponse,
  getAiLogs,
  getTotalAIRequests,
  getMostUsedTool,
  getRecentRequests,
  getMostActiveUsers,
  getAIStatistics,
  addAiLog,
  getaiLogsForEmployee
} = require('../controllers/aiController');
const { protect, admin } = require('../middleware/authMiddleware');
const { requireMinimumRole } = require('../middleware/roleMiddleware');

const router = express.Router();

// All routes require authentication
router.use(protect);

/**
 * Main AI Generation Endpoint
 * POST /api/ai/generate
 * Body: { type: "startup"|"roadmap"|"project"|"summarize"|"chat", input: string }
 */
router.post('/generate', protect , generateAiResponse);
router.get('/employee-logs', protect, getaiLogsForEmployee); // New route for employee-specific logs
/**
 * Get AI Logs (paginated) - Admin only
 * GET /api/ai/logs?page=1&limit=10
 */
router.get('/logs', requireMinimumRole('manager'), getAiLogs);

router.post("/logs/add", protect, addAiLog);
/**
 * Get total AI requests count - Admin only
 * GET /api/ai/stats/total
 */
router.get('/stats/total', requireMinimumRole('manager'), getTotalAIRequests);

/**
 * Get most used AI tool - Admin only
 * GET /api/ai/stats/most-used
 */
router.get('/stats/most-used', requireMinimumRole('manager'), getMostUsedTool);

/**
 * Get recent AI requests - Admin only
 * GET /api/ai/stats/recent?limit=10
 */
router.get('/stats/recent', requireMinimumRole('manager'), getRecentRequests);

/**
 * Get most active AI users - Admin only
 * GET /api/ai/stats/active-users?limit=10
 */
router.get('/stats/active-users', requireMinimumRole('manager'), getMostActiveUsers);

/**
 * Get comprehensive AI usage statistics - Admin only
 * GET /api/ai/stats/all
 */
router.get('/stats/all', requireMinimumRole('manager'), getAIStatistics);

module.exports = router;
