const express = require('express');
const { getAnalyticsSummary } = require('../controllers/analyticsController');
const { protect, admin } = require('../middleware/authMiddleware');
const router = express.Router();

router.use(protect);
// Summary is accessible to all authenticated users
router.get('/summary', getAnalyticsSummary);

module.exports = router;
