const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const router = express.Router();
const controller = require('../controllers/companyChatController');
const { protect, admin } = require('../middleware/authMiddleware');
const { requireMinimumRole } = require('../middleware/roleMiddleware');

const uploadDir = path.join(process.cwd(), 'uploads', 'chat');
fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_');
    cb(null, `${Date.now()}-${Math.random().toString(36).slice(2, 9)}-${safe}`);
  },
});
const upload = multer({ storage, limits: { fileSize: 25 * 1024 * 1024 } });

router.get('/channels/:companyId', protect, controller.getChannels);
router.post('/channels', protect, requireMinimumRole('manager'), controller.createChannel);
router.delete('/channels/:id', protect, requireMinimumRole('manager'), controller.deleteChannel);
router.get('/:companyId/:roomId', protect, controller.getMessages);
router.post('/send', protect, upload.single('file'), controller.sendMessage);
router.delete('/message/:id', protect, requireMinimumRole('manager'), controller.deleteMessage);

module.exports = router;
