const express = require('express');
const { getNotes, createNote, updateNote, deleteNote } = require('../controllers/noteController');
const { protect } = require('../middleware/authMiddleware');
const multer = require('multer');
const pdf = require('pdf-parse');
const mammoth = require('mammoth');

const router = express.Router();

const upload = multer({
    storage: multer.memoryStorage()
});

router.use(protect);
router.route('/').get(getNotes).post(createNote);
router.route('/:id').put(updateNote).delete(deleteNote);
router.post('/upload', upload.single('file'), async (req, res) => {
    try {
        console.log("FILE RECEIVED:", req.file);
        console.log("CONTENT:", content);
        if (!req.file) {
            return res.status(400).json({ message: 'No file uploaded' });
        }

        let content = '';

        // TXT FILE ONLY (safe + reliable)
        content = req.file.buffer.toString('utf-8');

        if (!content || content.trim().length === 0) {
            return res.status(400).json({
                message: 'File is empty or unreadable'
            });
        }

        const note = await Note.create({
            title: req.file.originalname,
            content: content.trim()
        });

        return res.status(201).json(note);

    } catch (err) {
        console.error('Upload error:', err);
        return res.status(500).json({
            message: 'Upload failed'
        });
    }
});

module.exports = router;