const express = require('express');
const { protect } = require('../middleware/authMiddleware');
const { loadProject } = require('../services/projectAccessService');
const { createProject, listProjects, getProject, updateProject, deleteProject, upsertFile, deleteFile, editWithAI } = require('../controllers/projectController');

const router = express.Router();
router.use(protect);
router.get('/', listProjects);
router.post('/', createProject);
router.get('/:id', loadProject, getProject);
router.put('/:id', loadProject, updateProject);
router.delete('/:id', loadProject, deleteProject);
router.post('/:id/files', loadProject, upsertFile);
router.delete('/:id/files/*path', loadProject, deleteFile);
router.post('/:id/ai', loadProject, editWithAI);

module.exports = router;