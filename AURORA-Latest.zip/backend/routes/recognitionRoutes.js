const express = require("express");
const router = express.Router();
const { protect, admin } = require("../middleware/authMiddleware");
const {
  getEmployeeRecognitions,
  awardRecognition,
  deleteRecognition,
  getCompanyRecognitions,
} = require("../controllers/recognitionController");

// ADMIN: get all recognitions for the company
router.get("/company", protect, admin, getCompanyRecognitions);

// GET recognitions for a specific employee (employee or admin)
router.get("/employee/:userId", protect, getEmployeeRecognitions);

// ADMIN: award recognition
router.post("/award", protect, admin, awardRecognition);

// ADMIN: delete recognition
router.delete("/:id", protect, admin, deleteRecognition);

module.exports = router;