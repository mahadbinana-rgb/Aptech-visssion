const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");

const {
  createReminder,
  getReminders,
  deleteReminder,
  getDueReminders,
  markReminderNotified
} = require("../controllers/reminderController");

router.post("/", protect, createReminder);
router.get("/", protect, getReminders);
router.get("/due", protect, getDueReminders);
router.delete("/:id", protect, deleteReminder);
router.put("/:id/notified", protect, markReminderNotified);
router.get("/due-system", protect, getDueReminders);

module.exports = router;