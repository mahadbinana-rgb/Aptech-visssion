const express = require('express');
const { getUsers, getUserById, deleteUser, getMyProfile } = require('../controllers/userController');
const { protect, admin } = require('../middleware/authMiddleware');
const { requireMinimumRole } = require('../middleware/roleMiddleware');
const router = express.Router();
const { provisionEmployee } = require('../controllers/userController');

router.use(protect);
router.get('/', requireMinimumRole('lead'), getUsers);
router.get('/me', getMyProfile);
router.get('/:id', getUserById);
router.delete('/delete/:id', requireMinimumRole('manager'), deleteUser);
router.post('/provision', requireMinimumRole('manager'), provisionEmployee);

module.exports = router;
