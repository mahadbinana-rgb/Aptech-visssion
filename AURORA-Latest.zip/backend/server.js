const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const connectDB = require('./config/db');
const seedDatabase = require('./config/seed');
const authRoutes = require('./routes/authRoutes');
const taskRoutes = require('./routes/taskRoutes');
const noteRoutes = require('./routes/noteRoutes');
const activityRoutes = require('./routes/activityRoutes');
const aiRoutes = require('./routes/aiRoutes');
const userRoutes = require('./routes/userRoutes');
const analyticsRoutes = require('./routes/analyticsRoutes');
const { errorHandler } = require('./middleware/errorMiddleware');
const reminderRoutes = require("./routes/reminderRoutes");
const recognitionRoutes = require("./routes/recognitionRoutes");
const cron = require("node-cron");
const Reminder = require("./models/Reminder");
const { Server } = require("socket.io")
const http = require("http");
// const { showNotification } = require("../desktop/main"); 

// cron.schedule("* * * * *", async () => {
//   const now = new Date();

//   const due = await Reminder.find({
//     dueTime: { $lte: now },
//     sent: false
//   });

//   for (const reminder of due) {

//     reminder.sent = true;
//     await reminder.save();

//     console.log(
//       "Reminder Triggered:",
//       reminder.title
//     );
//   }
// });

dotenv.config();

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: "*",
  },
});

// ========== SOCKET LOGIC ==========
io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  socket.on("join-company-room", ({ companyId, roomId }) => {
    const room = `${companyId}-${roomId}`;
    socket.join(room);
  });

  socket.on("join-company-feed", ({ companyId }) => {
    if (companyId) {
      const feedRoom = `company-${companyId}`;
      socket.join(feedRoom);
      console.log(`Socket ${socket.id} joined company feed: ${feedRoom}`);
    }
  });

  socket.on("send-company-message", (data) => {
    const room = `${data.companyId}-${data.roomId}`;

    io.to(room).emit("receive-company-message", data);
  });
});

// Make io accessible to controllers via req.app
app.set("io", io);

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

app.use('/api/auth', authRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/notes', noteRoutes);
app.use('/api/activities', activityRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/users', userRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use("/api/reminders", reminderRoutes);
app.use("/api/chat", require("./routes/companyChatRoutes"));
app.use("/api/recognitions", recognitionRoutes);
app.use('/api/projects', require('./routes/projectRoutes'));

app.get('/', (req, res) => {
  res.json({ message: 'AURORA AI backend is online' });
});

app.use(errorHandler);

const PORT = process.env.PORT || 1000;

const startServer = async () => {
  await connectDB();
  await seedDatabase();
  server.listen(PORT, () => {
    console.log("BACKEND_READY")
    console.log(`Server running on http://localhost:${PORT}`);
  });
};

if (require.main === module) {
  startServer();
}

module.exports = { app, server, io };