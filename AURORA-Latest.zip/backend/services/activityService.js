const Activity = require("../models/Activity");

/**
 * Log an activity to the database.
 * @param {Object} options
 * @param {string} options.userId - The user who performed the action
 * @param {string} options.action - Human-readable description (e.g. "Admin created channel #announcements")
 * @param {object} [options.io] - Socket.io server instance to broadcast
 * @param {string} [options.companyId] - Company ID to broadcast to
 */
async function logActivity({ userId, action, io, companyId }) {
  try {
    // Save to DB
    const activity = await Activity.create({ userId, companyId: companyId || undefined, action });

    // Broadcast via socket to all users in this company
    if (io && companyId) {
      const companyRoom = `company-${companyId}`;
      io.to(companyRoom).emit("activity-alert", {
        action,
        timestamp: activity.timestamp || new Date(),
      });
    }

    return activity;
  } catch (err) {
    console.error("Failed to log activity:", err.message);
    return null;
  }
}

module.exports = { logActivity };