const axios = require('axios');

/**
 * SYSTEM PROMPTS - Centralized prompt management for all AI tools
 */
const SYSTEM_PROMPTS = {
  startup: `You are an expert business strategist and startup advisor. When given a topic, generate a comprehensive startup idea with the following structure:

**Startup Name:** [Create a catchy, memorable name]
**Problem:** [Identify the core problem this startup solves]
**Solution:** [Describe the solution]
**Target Audience:** [Define the ideal customer]
**Revenue Model:** [Explain how the startup makes money]
**Key Features:** [List 3-5 main features]
**Why It Can Succeed:** [Provide compelling reasons]

Be creative, practical, and make it sound viable.`,

  roadmap: `You are an expert learning path designer. When given a skill name, create a detailed learning roadmap with three stages. Each stage should have specific topics, recommended resources (books, courses, projects), and estimated time to complete.

Format your response as:

**Beginner Stage:**
- Topics to learn
- Key concepts
- Practice projects
- Estimated time

**Intermediate Stage:**
- Advanced topics
- Complex projects
- Best practices
- Estimated time

**Advanced Stage:**
- Expert-level topics
- Industry applications
- Contribution opportunities
- Estimated time

Make it practical and achievable.`,

  project: `You are an expert software architect. When given a project idea, provide a comprehensive project plan with:

**Project Overview:** [Brief description of the project]
**Core Features:** [List main features to build]
**Recommended Tech Stack:** [Frontend, Backend, Database recommendations]
**Database Design:** [Key entities and relationships]
**Development Steps:** [Step-by-step implementation plan, numbered]
**Future Improvements:** [Potential enhancements and scaling strategies]

Be specific and practical.`,

  summarize: `You are an expert content summarizer. When given a long note or document, create a concise bullet-point summary that captures the key information.

Format as:
• Key point 1
• Key point 2
• Key point 3
• Key point 4
• Key point 5

Make it clear, actionable, and comprehensive.`,

  chat: `You are a productivity and life coach assistant. Your goal is to provide helpful, practical advice focused on productivity, time management, learning, and personal growth. Be supportive, clear, and give actionable recommendations.`
};

/**
 * DEMO RESPONSES - Instant fallback responses for demo/offline scenarios
 * Used when specific keywords are detected for instant response
 */
const DEMO_RESPONSES = {
  'Agriculture': {
    startup: `**Startup Name:** AgroTech Pro
**Problem:** Farmers struggle with crop management, weather forecasting, and market access, leading to lower yields and reduced profits.
**Solution:** AgroTech Pro combines AI-powered crop monitoring, real-time weather alerts, market price data, and direct buyer connections through a mobile-first platform.
**Target Audience:** Small to medium-scale farmers in developing regions seeking to modernize operations.
**Revenue Model:** Freemium model with premium features ($5-10/month), commission on direct sales (2-3%), and corporate partnerships with agricultural input suppliers.
**Key Features:**
- Satellite-based crop monitoring
- AI-powered pest detection
- Real-time market prices
- Weather alerts
- Direct market linkage
- Soil health analysis
**Why It Can Succeed:** Billions of smallholder farmers need solutions. Government subsidies exist. Growing demand for tech adoption in agriculture.`
  },
  'Healthcare': {
    startup: `**Startup Name:** MedAI Companion
**Problem:** Limited access to healthcare information, long wait times for consultations, and high costs burden patients in underserved regions.
**Solution:** MedAI Companion provides AI-powered symptom analysis, medicine information, appointment management, and telemedicine connections—all accessible offline-first.
**Target Audience:** Patients in emerging markets, health workers, remote communities without reliable internet.
**Revenue Model:** B2B partnerships with clinics ($100/month), B2C premium tier ($2/month), corporate wellness programs.
**Key Features:**
- Symptom analyzer
- Medicine database
- Appointment booking
- Telemedicine integration
- Health records storage
- Prescription management
**Why It Can Succeed:** Healthcare is universal need. Growing telehealth adoption. Regulatory support for digital health.`
  },
  'Education': {
    startup: `**Startup Name:** LearnFlow
**Problem:** Students lack personalized learning paths, affordable tutoring, and progress tracking tools.
**Solution:** LearnFlow provides AI-powered personalized learning journeys, adaptive quizzes, mentor matching, and progress analytics accessible to all students.
**Target Audience:** Students (K-12 and college), teachers, parents seeking affordable quality education.
**Revenue Model:** B2B school partnerships ($50/month per teacher), B2C subscription ($5/month), corporate training contracts.
**Key Features:**
- Personalized learning paths
- AI tutoring
- Adaptive assessments
- Progress analytics
- Peer collaboration
- Expert mentor network
**Why It Can Succeed:** Education is critical. Online learning is normalized. Global market size exceeds $1T.`
  },
  'Artificial Intelligence': {
    startup: `**Startup Name:** AI Ops Studio
**Problem:** Enterprises struggle to implement AI due to complexity, cost, and lack of in-house expertise.
**Solution:** AI Ops Studio provides low-code AI tools for enterprise automation, predictions, and insights without requiring data scientists.
**Target Audience:** SMBs and enterprises across retail, finance, healthcare, and manufacturing.
**Revenue Model:** SaaS subscription ($500-5000/month), implementation services, custom model development.
**Key Features:**
- No-code AI builder
- Pre-trained models
- Data pipeline automation
- Real-time analytics
- Integration marketplace
- Enterprise security
**Why It Can Succeed:** AI adoption is accelerating. Talent gap exists. ROI is proven. Regulatory frameworks emerging.`
  }
};

/**
 * AIService - Centralized AI integration with Ollama
 */
class AIService {
  constructor() {
    this.ollamaEndpoint = process.env.OLLAMA_ENDPOINT || 'http://localhost:11434/api/generate';
    this.model = process.env.OLLAMA_MODEL || 'qwen3.5:4b';
    this.timeout = 130000; // 130 seconds timeout
  }

  /**
   * Check if demo keywords are present in input
   * Returns demo response if matched, null otherwise
   */
  checkDemoKeywords(input, type) {
    const inputLower = input.toLowerCase();
    
    for (const [keyword, responses] of Object.entries(DEMO_RESPONSES)) {
      if (inputLower.includes(keyword.toLowerCase())) {
        if (responses[type]) {
          return responses[type];
        }
      }
    }
    return null;
  }

  /**
   * Validate AI request type
   */
  validateRequestType(type) {
    const validTypes = ['startup', 'roadmap', 'project', 'summarize', 'chat', 'code', 'marketing', 'email', 'meeting', 'brainstorm'];
    if (!validTypes.includes(type)) {
      throw new Error(`Invalid request type: ${type}. Valid types are: ${validTypes.join(', ')}`);
    }
  }

  /**
   * Get system prompt based on type
   */
  getSystemPrompt(type) {
    if (type === 'code') return 'You are AURORA\'s local coding assistant. Analyze code carefully, preserve project context supplied in the prompt, provide correct code, and do not call or recommend external cloud services.';
    return SYSTEM_PROMPTS[type] || SYSTEM_PROMPTS.chat;
  }

  /**
   * Build final prompt combining system prompt and user input
   */
  buildPrompt(type, input) {
    const systemPrompt = this.getSystemPrompt(type);
    return `${systemPrompt}\n\nUser Input: ${input}\n\nPlease provide a comprehensive response:`;
  }

  /**
   * Call Ollama API with timeout handling
   */
  async callOllama(prompt) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.timeout);

    try {
      const response = await axios.post(
        this.ollamaEndpoint,
        {
          model: this.model,
          prompt: prompt,
          stream: false,
        },
        {
          signal: controller.signal,
          timeout: this.timeout,
        }
      );

      clearTimeout(timeoutId);
      return response.data.response;
    } catch (error) {
      clearTimeout(timeoutId);

      if (error.code === 'ECONNREFUSED') {
        throw new Error('Ollama is offline. Make sure Ollama is running at ' + this.ollamaEndpoint);
      }
      if (error.name === 'AbortError') {
        throw new Error('Ollama request timeout. The model took too long to respond.');
      }
      throw error;
    }
  }

  /**
   * Main method - Generate AI response
   * @param {string} type - Type of AI tool (startup, roadmap, project, summarize, chat)
   * @param {string} input - User input/prompt
   * @returns {Promise<string>} - AI generated response
   */
  async askAI(type, input) {
    // Validate input
    if (!type || !input) {
      throw new Error('Type and input are required');
    }

    if (typeof input !== 'string' || input.trim().length === 0) {
      throw new Error('Input must be a non-empty string');
    }

    // Validate request type
    this.validateRequestType(type);

    // Check for demo keywords - return instantly if matched
    const demoResponse = this.checkDemoKeywords(input, type);
    if (demoResponse) {
      console.log(`[AI Service] Demo response triggered for keyword in: ${input}`);
      return demoResponse;
    }

    // Build prompt
    const finalPrompt = this.buildPrompt(type, input);

    // Call Ollama
    console.log(`[AI Service] Calling Ollama for type: ${type}`);
    const response = await this.callOllama(finalPrompt);

    if (!response || response.trim().length === 0) {
      throw new Error('Empty response from Ollama');
    }

    return response;
  }
}

module.exports = new AIService();
// CodeSpace-specific structured project editing. It deliberately stays on the configured local Ollama endpoint.
AIService.prototype.codeSpaceEdit = async function ({ project, prompt, selectedPath, mode = 'edit' }) {
  const files = project.files.map((file) => ({
    path: file.path,
    language: file.language,
    content: file.content,
  }));

  const context = JSON.stringify({
    project: { name: project.name, description: project.description, mode },
    selectedPath,
    files,
  }, null, 2);

  const systemPrompt = `You are AURORA CodeSpace, a local-only senior software engineer working inside an existing project.\n` +
    `The project context below is authoritative. NEVER invent files or project conventions when context already contains them.\n` +
    `Return ONLY valid JSON with this exact top-level shape:\n` +
    `{"summary":"...","files":[{"path":"relative/path","language":"javascript","content":"FULL FILE CONTENT"}],"notes":["..."]}\n` +
    `Only include files that need to be created or changed. For changed files, return the complete new file content, not a diff.\n` +
    `Preserve unrelated behavior. Do not use external URLs, package downloads, or cloud services unless the user explicitly asks and the project already permits them.\n` +
    `Never include markdown fences around the JSON.`;

  const finalPrompt = `${systemPrompt}\n\nPROJECT CONTEXT:\n${context}\n\nUSER INSTRUCTION:\n${prompt}`;
  const raw = await this.callOllama(finalPrompt, project.settings?.aiModel || this.model);
  let parsed;
  try {
    const cleaned = String(raw).trim().replace(/^```json\s*/i, '').replace(/```$/i, '').trim();
    parsed = JSON.parse(cleaned);
  } catch {
    return { summary: 'AI returned a non-structured response.', files: [], notes: [String(raw)] };
  }
  return {
    summary: parsed.summary || 'CodeSpace completed the request.',
    files: Array.isArray(parsed.files) ? parsed.files : [],
    notes: Array.isArray(parsed.notes) ? parsed.notes : [],
  };
};

// Preserve backwards compatibility while allowing CodeSpace to choose a project model.
const originalCallOllama = AIService.prototype.callOllama;
AIService.prototype.callOllama = async function (prompt, modelOverride) {
  const previous = this.model;
  if (modelOverride) this.model = modelOverride;
  try {
    return await originalCallOllama.call(this, prompt);
  } finally {
    this.model = previous;
  }
};
