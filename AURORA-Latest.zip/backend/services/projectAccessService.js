const Project = require('../models/Project');
const { hasRoleLevel } = require('../middleware/roleMiddleware');

const sameId = (a, b) => String(a) === String(b);

const canViewProject = (project, user) => {
  if (!project || !user) return false;
  if (hasRoleLevel(user, 'admin')) return true;
  if (sameId(project.ownerId, user._id)) return true;
  if (project.kind === 'company' && sameId(project.companyId, user.companyId)) {
    if (hasRoleLevel(user, 'manager')) return true;
    return project.collaborators.some((entry) => sameId(entry.userId, user._id));
  }
  return false;
};

const permissionFor = (project, user) => {
  if (!project || !user) return null;
  if (hasRoleLevel(user, 'admin')) return 'owner';
  if (sameId(project.ownerId, user._id)) return 'owner';
  if (project.kind === 'company' && hasRoleLevel(user, 'manager') && sameId(project.companyId, user.companyId)) {
    return 'owner';
  }
  const member = project.collaborators.find((entry) => sameId(entry.userId, user._id));
  return member?.permission || null;
};

const canEditProject = (project, user) => {
  const permission = permissionFor(project, user);
  return permission === 'owner' || permission === 'developer' || permission === 'editor';
};

const canDeleteProject = (project, user) => {
  if (!project || !user) return false;
  if (hasRoleLevel(user, 'admin')) return true;
  if (project.kind === 'company' && hasRoleLevel(user, 'manager') && sameId(project.companyId, user.companyId)) return true;
  return sameId(project.ownerId, user._id);
};

const loadProject = async (req, res, next) => {
  try {
    const project = await Project.findById(req.params.id);
    if (!project) return res.status(404).json({ message: 'Project not found' });
    if (!canViewProject(project, req.user)) return res.status(403).json({ message: 'You do not have access to this project' });
    req.project = project;
    next();
  } catch (error) {
    next(error);
  }
};

module.exports = { sameId, canViewProject, canEditProject, canDeleteProject, permissionFor, loadProject };
