import { useEffect, useRef } from "react";
import { io } from "socket.io-client";
import { useAuth } from "../context/AuthContext";

const RAW_URL = import.meta.env.VITE_API_URL || "http://localhost:1000";
const SOCKET_URL = RAW_URL.replace(/\/api\/?$/, "");

/**
 * Global component that connects to socket and listens for activity alerts.
 * Wraps the entire app so ALL online users in the company get alerts on EVERY page.
 */
export default function ActivityFeed({ children }) {
  const { user } = useAuth();
  const socketRef = useRef(null);
  const companyId = user?.companyId;

  useEffect(() => {
    if (!companyId) return;

    // Only create one socket instance globally
    if (socketRef.current) return;

    const socket = io(SOCKET_URL, {
      transports: ["websocket", "polling"],
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 2000,
    });

    socketRef.current = socket;

    socket.on("connect", () => {
      console.log("ActivityFeed: Socket connected");
      // Join the company-wide feed room
      socket.emit("join-company-feed", { companyId });
    });

    socket.on("disconnect", (reason) => {
      console.log("ActivityFeed: Socket disconnected:", reason);
    });

    socket.on("connect_error", (err) => {
      console.error("ActivityFeed: Socket error:", err.message);
    });

    // THIS is the key — listen for activity alerts on EVERY page
    socket.on("activity-alert", (data) => {
      alert(`🔔 ${data.action}`);
    });

    return () => {
      if (socketRef.current) {
        socketRef.current.off("connect");
        socketRef.current.off("disconnect");
        socketRef.current.off("connect_error");
        socketRef.current.off("activity-alert");
        socketRef.current.disconnect();
        socketRef.current = null;
      }
    };
  }, [companyId]);

  return children;
}