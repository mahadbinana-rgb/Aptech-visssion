import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function AdminSidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const { logout, user } = useAuth();

  const getActiveTab = () => {
    if (location.pathname === '/employees') return 'identity';
    if (location.pathname === '/ailogs') return 'audit';
    return 'network';
  };

  const activeTab = getActiveTab();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <aside className="aura-admin-sidebar">
      <div className="logo">
        <i className="fa-solid fa-terminal"></i> AURA ROOT
      </div>
      <ul className="nav-links">
        <li>
          <a
            href="#network"
            className={activeTab === 'network' ? 'active' : ''}
            onClick={(e) => {
              e.preventDefault();
              navigate('/admin');
            }}
          >
            <i className="fa-solid fa-network-wired"></i> Network Overview
          </a>
        </li>
        <li>
          <a
            href="#identity"
            className={activeTab === 'identity' ? 'active' : ''}
            onClick={(e) => {
              e.preventDefault();
              navigate('/employees');
            }}
          >
            <i className="fa-solid fa-users-gear"></i> Identity & Access
          </a>
        </li>
        <li>
          <a
            href="#audit"
            className={activeTab === 'audit' ? 'active' : ''}
            onClick={(e) => {
              e.preventDefault();
              navigate('/ailogs');
            }}
          >
            <i className="fa-solid fa-shield-halved"></i> Security Audit Logs
          </a>
        </li>
        <li>
          <a
            href="#chat"
            className={activeTab === 'chat' ? 'active' : ''}
            onClick={(e) => {
              e.preventDefault();
              navigate('/adminchat');
            }}
          >
          <i className="fa-solid fa-shield-halved"></i> Secure Company Chat </a>
        </li>
        <li>
          <a
            href="#activities"
            className={activeTab === 'chat' ? 'active' : ''}
            onClick={(e) => {
              e.preventDefault();
              navigate('/activities');
            }}
          >
          <i className="fa-solid fa-shield-halved"></i> Comapny Activities </a>
        </li>
      </ul>
      <div className="user-info">
        <i className="fa-solid fa-crown"></i>
        <span>{user?.name || 'Administrator'}</span>
      </div>
      <button className="btn-logout" onClick={handleLogout}>
        <i className="fa-solid fa-right-from-bracket"></i> Log Out
      </button>
    </aside>
  );
}
