import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const ROLE_LEVELS = { employee: 10, lead: 20, manager: 30, admin: 40 };

export default function ProtectedRoute({ children, role, minRole }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (role && user.role !== role) return <Navigate to="/" replace />;
  if (minRole && (ROLE_LEVELS[user.role] || 0) < (ROLE_LEVELS[minRole] || 999)) return <Navigate to="/" replace />;
  return children;
}
