import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const links = [
  ['/', '⌂', 'Dashboard'],
  ['/tasks', '✓', 'Tasks'],
  ['/notes', '▱', 'Notes'],
  ['/codespace', '⌘', 'CodeSpace'],
  ['/ai', '✦', 'AI Hub'],
  ['/reminders', '◷', 'Reminders'],
  ['/message', '◌', 'Company Chat'],
  ['/activities', '≋', 'Activity'],
  ['/profile', '○', 'Profile'],
];

export default function Sidebar({ className = '' }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const elevated = ['admin','manager','lead'].includes(user?.role);

  const handleLogout = async () => { await logout(); navigate('/login'); };

  return (
    <aside className={`sidebar ${className}`}>
      <div className="brand-block">
        <div className="brand-mark">A</div>
        <div><strong>AURORA</strong><span>Private workspace</span></div>
      </div>
      <div className="privacy-chip"><span /> Offline-first · Ollama local</div>
      <div className="nav-section">WORKSPACE</div>
      <nav className="nav-links">
        {links.map(([to, icon, label]) => <NavLink key={to} to={to} end={to === '/'} className={({ isActive }) => isActive ? 'active' : ''}><span className="nav-icon">{icon}</span>{label}</NavLink>)}
      </nav>
      {elevated && <><div className="nav-section management">MANAGEMENT</div><nav className="nav-links"><NavLink to="/employees" className={({isActive}) => isActive ? 'active' : ''}><span className="nav-icon">◉</span>People</NavLink><NavLink to="/admin" className={({isActive}) => isActive ? 'active' : ''}><span className="nav-icon">▦</span>Management</NavLink><NavLink to="/ailogs" className={({isActive}) => isActive ? 'active' : ''}><span className="nav-icon">⌁</span>AI Audit</NavLink></nav></>}
      <div className="sidebar-spacer" />
      <div className="user-card"><div className="avatar">{(user?.name || 'U').slice(0,1).toUpperCase()}</div><div className="user-meta"><strong>{user?.name || 'Guest'}</strong><span>{user?.role || 'guest'}{user?.companyName ? ` · ${user.companyName}` : ''}</span></div></div>
      <button className="btn-logout" onClick={handleLogout}>Sign out <span>↗</span></button>
    </aside>
  );
}
