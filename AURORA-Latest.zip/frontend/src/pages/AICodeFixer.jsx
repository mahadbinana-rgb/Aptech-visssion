import React, { useState } from 'react';
import mockApi from '../services/mockApi.js';
import Sidebar from '../components/Sidebar';
import '../main.css';
import '../AiEngine.css';

const CODE_ASSISTANT_PROMPTS = {
  fix: `You are an expert code debugging and optimization assistant. Your task is to analyze the provided code, automatically detect its programming language, fix any bugs, optimize performance, and explain your changes. Format your response exactly like this:\n**Detected Language:** [Language Name]\n**What Was Wrong:** [Brief explanation of the bugs, errors, or inefficiencies]\n**Fixed Code:**\n\`\`\`[detected-language]\n[Your clean, optimized, fully working code here]\n\`\`\`\n**Explanation of Changes:**\n[Bullet points explaining the fixes]`,
  explain: `You are an expert code explainer. Analyze the provided code, identify the language, and explain the behavior, data flow, and purpose of each major section. Provide a clear summary, any important assumptions, and action items for improving readability or correctness.`,
  refactor: `You are an expert software engineer. Refactor the provided code to improve readability, maintainability, and structure while preserving behavior. Keep the same functionality and add brief comments for clarity. Return the refactored code within code fences and include a summary of the main changes made.`,
  test: `You are an expert software testing engineer. Review the provided code and generate a set of relevant unit tests or test cases. Detect the programming language, describe the testing framework used, and provide complete sample test code with comments explaining each test scenario.`,
  comment: `You are an expert documentation and inline comment writer. Read the provided code and add helpful comments, documentation blocks, and explanations to improve comprehension for future developers. Preserve the original logic and output the fully annotated code in code fences.`,
  translate: `You are an expert code translator and migration specialist. Convert the provided code into a different programming language as requested by the user. Preserve the original behavior, use idiomatic constructs in the target language, and include the translated code inside code fences. Also explain any language-specific changes made.`
};

const CODE_PLACEHOLDER_TEXTS = {
  fix: 'Paste the code you want to fix, optimize, or debug...',
  explain: 'Paste the code you want explained by the AI...',
  refactor: 'Paste the code you want cleaned up and refactored...',
  test: 'Paste the code you want unit tests or test cases for...',
  comment: 'Paste the code you want documented with inline comments...',
  translate: 'Paste the code you want translated and specify the target language below...'
};

const TRANSLATE_HINT = 'Optional: indicate the desired target language, e.g. Python, JavaScript, Java, C#.';

export default function AICodeFixer() {
  const [mode, setMode] = useState('fix');
  const [userCode, setUserCode] = useState("");
  const [useCase, setUseCase] = useState("");
  const [result, setResult] = useState("");
  const [codeLoading, setCodeLoading] = useState(false);


  const handleFixCode = async (e) => {
    if (e) e.preventDefault();
    if (!userCode.trim() || codeLoading) return;

    try {
      setCodeLoading(true);
      setResult("");

      const systemPrompt = CODE_ASSISTANT_PROMPTS[mode] || CODE_ASSISTANT_PROMPTS.fix;
      const instructions = useCase.trim() ||
        (mode === 'translate'
          ? 'Translate this code to the target language and specify the desired language in the prompt.'
          : 'Provide the best possible result for the selected code assistant mode.');

      const finalPrompt = `${systemPrompt}\n\nUser Code:\n\`\`\`\n${userCode.trim()}\n\`\`\`\n\nInstructions: ${instructions}\n\nPlease provide a comprehensive response:`;
      const combinedLogInput = `Mode: ${mode}\nInstructions: ${instructions}\nCode: ${userCode}`;

      const response = await mockApi.generate({ tool: 'code', input: finalPrompt });
      setResult(response.response);
      await mockApi.addAiLog({
        userId: null,
        toolType: `code_${mode}`,
        prompt: combinedLogInput,
        response: response.response
      });
    } catch (err) {
      console.error('Ollama code fixer error:', err);
      if (err.code === 'ERR_NETWORK') {
        setResult('AI request failed: Could not connect to the local AURORA AI service. Ensure Ollama is running on this computer.');
      } else {
        setResult('AI request failed: ' + (err.message || 'Unknown error'));
      }
    } finally {
      setCodeLoading(false);
    }
  };

  const actionLabel = {
    fix: 'Fix & Optimize Code',
    explain: 'Explain Code',
    refactor: 'Refactor Code',
    test: 'Generate Tests',
    comment: 'Document Code',
    translate: 'Translate Code'
  }[mode] || 'Run Code Assistant';

  return (
    <div style={{ display: 'flex' }}>
      <Sidebar />
      <div className="ai-engine main-content">
        <h2>Smart Code Assistant</h2>
        
        <div className="code-card card">
          <p className="text-sm my-1">AI runs locally on your device. Your secure code never leaves your computer.</p>
          
          <div className="ai-input-group mt-3">
            <label className="ai-label">Paste Your Code</label>
            <textarea 
              value={userCode} 
              onChange={(e) => setUserCode(e.target.value)} 
              className="ai-textarea font-mono" 
              placeholder="Paste the code you want to fix or improve..." 
              style={{ resize: 'none', height: '150px' }} 
              required 
            />
          </div>

          <div className="ai-input-group mt-3">
            <label className="ai-label">What should this code do? / Error message (Optional)</label>
            <input 
              type="text" 
              value={useCase} 
              onChange={(e) => setUseCase(e.target.value)} 
              className="ai-select" 
              placeholder="e.g., It's throwing a KeyError, or Make this fetch data faster" 
            />
            <p className="text-xs text-amber-600 mt-1">⚠️ Local 1.5B AI: Code fixes are highly accurate, but written explanations may occasionally contain minor inaccuracies.</p>
          </div>

          <div className="text-right mt-3">
            <button 
              className="btn btn-primary" 
              onClick={handleFixCode} 
              disabled={codeLoading || !userCode.trim()}
            >
              {codeLoading ? "Analyzing..." : "Fix & Optimize Code"}
            </button>
          </div>
        </div>

        {(result || codeLoading) && (
          <div className="ai-result">
            <div className="ai-result-title">{codeLoading ? "Processing..." : "Analysis Result"}</div>
            <div className="ai-result-content" style={{ whiteSpace: 'pre-wrap' }}>
              {codeLoading ? "The local model is compiling optimizations, please wait..." : result}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}