import React, { useState } from 'react';
import mockApi from '../services/mockApi.js';
import Sidebar from '../components/Sidebar';
import '../main.css';
import '../AiEngine.css';

const SYSTEM_PROMPTS = {
  startup: `You are an expert business strategist and startup advisor. When given a topic, generate a comprehensive startup idea with the following structure:\n**Startup Name:** [Create a catchy, memorable name]\n**Problem:** [Identify the core problem this startup solves]\n**Solution:** [Describe the solution]\n**Target Audience:** [Define the ideal customer]\n**Revenue Model:** [Explain how the startup makes money]\n**Key Features:** [List 3-5 main features]\n**Why It Can Succeed:** [Provide compelling reasons]\nBe creative, practical, and make it sound viable.`,
  roadmap: `You are an expert learning path designer. When given a skill name, create a detailed learning roadmap with three stages. Each stage should have specific topics, recommended resources (books, courses, projects), and estimated time to complete. Format your response as:\n**Beginner Stage:**\n- Topics to learn\n- Key concepts\n- Practice projects\n- Estimated time\n**Intermediate Stage:**\n- Advanced topics\n- Complex projects\n- Best practices\n- Estimated time\n**Advanced Stage:**\n- Expert-level topics\n- Industry applications\n- Contribution opportunities\n- Estimated time\nMake it practical and achievable.`,
  project: `You are an expert software architect. When given a project idea, provide a comprehensive project plan with:\n**Project Overview:** [Brief description of the project]\n**Core Features:** [List main features to build]\n**Recommended Tech Stack:** [Frontend, Backend, Database recommendations]\n**Database Design:** [Key entities and relationships]\n**Development Steps:** [Step-by-step implementation plan, numbered]\n**Future Improvements:** [Potential enhancements and scaling strategies]\nBe specific and practical.`,
  summarize: `You are an expert content summarizer. When given a long note or document, create a concise bullet-point summary that captures the key information. Format as:\n• Key point 1\n• Key point 2\n• Key point 3\n• Key point 4\n• Key point 5\nMake it clear, actionable, and comprehensive.`,
  marketing: `You are an expert growth marketer and copywriter. When given a product, service, or campaign idea, create persuasive marketing content with the following structure:\n**Headline:** [A catchy attention-grabbing headline]\n**Value Proposition:** [Why this matters to customers]\n**Target Audience:** [Who this is for]\n**Key Benefits:** [Primary advantages and outcomes]\n**Call to Action:** [What the reader should do next]\nWrite the response in a tone suitable for digital ads, landing pages, or product messaging.`,
  email: `You are an expert business communications specialist. When given the purpose of an email, draft a professional, clear, and polite message with a strong opening, relevant context, and a concise closing. Include subject line suggestions and make the tone appropriate for business recipients.`,
  meeting: `You are an expert productivity facilitator. When given a meeting topic, attendees, and goals, create a detailed meeting agenda with sections for objectives, topics, time allocation, and follow-up actions. Keep it structured and easy to share with a team.`,
  brainstorm: `You are an expert ideation coach. When given a challenge, product, or theme, generate a list of creative ideas, variations, and concepts that can be used for product design, marketing, or business strategy. Organize the response into clear sections and make it actionable.`
};

const PLACEHOLDER_TEXTS = {
  startup: 'Enter a market, industry, or problem space to generate a startup idea...',
  roadmap: 'Enter a skill, technology, or topic to build a structured learning roadmap...',
  project: 'Enter a project concept or app idea to receive a detailed implementation plan...',
  summarize: 'Paste notes, meeting minutes, or a document to get a concise summary...',
  marketing: 'Enter a product, feature, or campaign goal for marketing copy and positioning...',
  email: 'Enter the email purpose, recipient context, and key details for a polished draft...',
  meeting: 'Enter the meeting goals, agenda topic, and attendees to generate a plan...',
  brainstorm: 'Enter a challenge, feature area, or business idea to generate creative concepts...'
};

export default function AIGenerator() {
  const [type, setType] = useState("startup");
  const [input, setInput] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const handleGenerate = async (e) => {
    if (e) e.preventDefault();
    if (!input.trim() || loading) return;

    try {
      setLoading(true);
      setResult("");
      const systemPrompt = SYSTEM_PROMPTS[type] || "";
      const finalPrompt = `${systemPrompt}\n\nUser Input: ${input.trim()}\n\nPlease provide a comprehensive response:`;

      const response = await mockApi.generate({ tool: type, input: finalPrompt });

      setResult(response.response);
      await mockApi.addAiLog({
        userId: null,
        toolType: type,
        companyId: null,
        prompt: input.trim(),
        response: response.response
      });
    } catch (err) {
      console.error("Ollama generator error:", err);
      if (err.code === 'ERR_NETWORK') {
        setResult("AI request failed: Could not connect to the local AURORA AI service. Ensure Ollama is running on this computer.");
      } else {
        setResult("AI request failed: " + (err.message || "Unknown error"));
      }
    } finally {
      setLoading(false);
    }
  };
  return (
    <div style={{ display: 'flex' }}>
      <Sidebar />
      <div className="ai-engine main-content">
        <h2>AI Strategy & Blueprint Generator</h2>
        
        <div className="card">
          <div className="ai-input-group">
            <label className="ai-label">Tool Mode</label>
            <select value={type} onChange={(e) => setType(e.target.value)} className="ai-select">
              <option value="startup">Generate Startup Idea</option>
              <option value="roadmap">Learning Roadmap</option>
              <option value="project">Project Outline</option>
              <option value="summarize">Note Summarizer</option>
              <option value="marketing">Marketing Copy Generator</option>
              <option value="email">Professional Email Writer</option>
              <option value="meeting">Meeting Agenda Planner</option>
              <option value="brainstorm">Creative Brainstorm Assistant</option>
            </select>
          </div>

          <div className="ai-input-group">
            <label className="ai-label">Prompt Input</label>
            <textarea 
              value={input} 
              onChange={(e) => setInput(e.target.value)} 
              className="ai-textarea" 
              placeholder={PLACEHOLDER_TEXTS[type] || 'Enter context, target keywords, or basic concept details...'} 
              style={{ resize: 'none' }} 
              required 
            />
          </div>
          <p className="text-xs text-amber-600 mt-1">⚠️ Local AI features are fast and private, but please review the response for context accuracy and adjust details as needed.</p>

          <div className="text-right mt-3">
            <button className="btn btn-primary" onClick={handleGenerate} disabled={loading}>
              {loading ? "Generating..." : "Run Engine"}
            </button>
          </div>
        </div>

        {(result || loading) && (
          <div className="ai-result">
            <div className="ai-result-title">{loading ? "Processing..." : "Engine Result"}</div>
            <div className="ai-result-content" style={{ whiteSpace: 'pre-wrap' }}>
              {loading ? "Aurora is thinking, please wait..." : result}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}