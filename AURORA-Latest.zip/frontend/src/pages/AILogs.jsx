import React, { useEffect, useState } from 'react';
import mockApi from '../services/mockApi';
import AdminSidebar from '../components/AdminSidebar';
import '../AuraAdmin.css';
import '../AiLogs.css';

export default function AILogs() {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    let mounted = true;
    mockApi.getAiLogs().then((response) => {
      if (mounted) {
        // Handle both direct array response and object with logs property
        const logsData = Array.isArray(response) ? response : response.logs || [];
        setLogs(logsData);
      }
    }).catch(console.error);
    return () => { mounted = false; };
  }, []);

  // CSV Export Function for Admin AI Logs
  const exportToCSV = () => {
    if (logs.length === 0) {
      alert("No AI audit logs available to export!");
      return;
    }

    // 1. Define admin audit headers
    const headers = ['Log ID', 'Tool Type', 'Timestamp', 'User Prompt', 'System Response'];

    // 2. Map log fields and systematically clean complex inputs to avoid CSV field splitting
    const rows = logs.map((l) => [
      l._id || l.id || '',
      `"${(l.toolType || '').replace(/"/g, '""')}"`,
      `"${l.createdAt ? new Date(l.createdAt).toLocaleString() : 'N/A'}"`,
      `"${(l.prompt || '').replace(/"/g, '""')}"`,
      `"${(l.response || '').replace(/"/g, '""')}"`
    ]);

    // 3. Assemble document layout structure strings
    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');

    // 4. Force file payload compilation under UTF-8 specification standard
    const blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), csvContent], { 
      type: 'text/csv;charset=utf-8;' 
    });

    // 5. Mount a secure invisible virtual downloader trigger and auto-execute
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `security_ai_logs_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    
    // Clear system resources
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="aura-admin-wrapper">
      {/* Top Security Banner */}
      <div className="security-banner">
        <i className="fa-solid fa-triangle-exclamation"></i> Administrator Privileges Active — Proceed with Caution
      </div>

      <div className="layout-wrapper">
        {/* Sidebar Navigation */}
        <AdminSidebar />

        {/* Main Content */}
        <main className="main-content">
          <header className="header">
            <div>
              <h1>Security Audit Logs</h1>
              <p>Monitor all AI requests and system audit trail.</p>
            </div>
            {/* Action buttons wrapper container */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '15px' }}>
              <button 
                className="btn-export-admin" 
                onClick={exportToCSV}
                style={{
                  padding: '8px 16px',
                  cursor: 'pointer',
                  backgroundColor: '#27272a',
                  color: '#f4f4f5',
                  border: '1px solid #3f3f46',
                  borderRadius: '6px',
                  fontWeight: '500',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px'
                }}
              >
                <i className="fa-solid fa-file-csv"></i> Export Audit Trail
              </button>
              <div className="status-badge">
                <i className="fa-solid fa-shield-halved"></i> AUDIT LOGGING ACTIVE
              </div>
            </div>
          </header>

          <div className="panel">
            <div className="panel-header">
              <h3>AI Request History</h3>
            </div>
            {logs.length === 0 ? (
              <div style={{ padding: '40px', textAlign: 'center', color: '#a1a1aa' }}>
                No AI requests logged yet.
              </div>
            ) : (
              <div className="ai-logs-list">
                {logs.map((l) => (
                  <div key={l._id || l.id} className="log-entry">
                    <div className="log-header">
                      {/* <span className="log-user">{l.userId || 'Anonymous'}</span> */}
                      <span className="log-tool">{l.toolType}</span>
                      <span className="log-time">{new Date(l.createdAt).toLocaleString()}</span>
                    </div>
                    <div className="log-prompt">
                      <strong>Prompt:</strong> {l.prompt}
                    </div>
                    <div className="log-response">{l.response}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}