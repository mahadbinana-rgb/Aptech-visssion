import React, { useState, useEffect } from 'react';
import mockApi from '../services/mockApi.js';
import Sidebar from '../components/Sidebar';
import '../main.css';
import '../AiEngine.css';
import { Link } from 'react-router-dom';

export default function AILogsEmp() {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    let mounted = true;
    mockApi.getaiLogsForEmployee()
      .then((response) => {
        if (mounted) {
          const logsData = Array.isArray(response) ? response : response.logs || [];
          setLogs(logsData);
        }
      })
      .catch(console.error);

    return () => {
      mounted = false;
    };
  }, []);

  // CSV Export Function for Employee AI Logs
  const exportToCSV = () => {
    if (logs.length === 0) {
      alert("No AI history logs available to export!");
      return;
    }

    // 1. Define specific column headers
    const headers = ['Log ID', 'Tool Type', 'Timestamp', 'Prompt Issued', 'AI Response'];

    // 2. Map data rows and securely escape string elements
    const rows = logs.map((l) => [
      l._id || l.id || '',
      `"${(l.toolType || '').replace(/"/g, '""')}"`,
      `"${l.createdAt ? new Date(l.createdAt).toLocaleString() : 'N/A'}"`,
      `"${(l.prompt || '').replace(/"/g, '""')}"`,
      `"${(l.response || '').replace(/"/g, '""')}"`
    ]);

    // 3. Assemble document rows
    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');

    // 4. Force character encoding configurations using UTF-8 standard definitions
    const blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), csvContent], { 
      type: 'text/csv;charset=utf-8;' 
    });

    // 5. Instantly compile background links and prompt filesystem downloads
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `my_ai_history_${new Date().toISOString().split('T')}.csv`);
    document.body.appendChild(link);
    link.click();
    
    // Deallocate local DOM resources 
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div style={{ display: 'flex' }}>
      <Sidebar />
      <div className="ai-engine main-content">
        <h2 style={{ marginBottom: '20px' }}>AI Management Console</h2>
        <button className="btn btn-primary" style={{ marginRight: '10px', marginBottom: '20px' }}>
          <Link to="/aiGen">Generate AI Idea</Link>
        </button>
        <button className="btn btn-primary" style={{ marginRight: '10px', marginBottom: '20px' }}>
          <Link to="/aiCode">Fix/improve your code by local AI</Link>
        </button>
        {/* Integrated Export Action Button */}
        <button 
          className="btn" 
          onClick={exportToCSV}
          style={{ 
            marginRight: '10px', 
            marginBottom: '20px', 
            cursor: 'pointer',
            backgroundColor: '#6c757d',
            color: '#fff',
            border: 'none',
            padding: '10px 15px',
            borderRadius: '4px'
          }}
        >
          Export History to CSV
        </button>

        <div className="logs-card card">
          <h4>View your past AI logs:</h4>
          <div className="ai-logs-list">
            {logs.map((l) => (
              <div key={l._id || l.id} className="log-entry">
                <div className="log-header">
                  <span className="log-tool">{l.toolType}</span>
                  <span className="log-time">{new Date(l.createdAt).toLocaleString()}</span>
                </div>
                <div className="log-prompt">
                  <strong>Prompt:</strong> {l.prompt}
                </div>
                <div className="log-response">{l.response}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}