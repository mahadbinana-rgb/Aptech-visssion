import { useEffect, useState } from 'react';
import Sidebar from '../components/Sidebar';
import '../main.css';
import '../Tasks.css';
import mockApi from '../services/mockApi';

export default function Activity() {
    const [tasks, setTasks] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        let mounted = true;

        const fetchTasks = async () => {
            try {
                const t = await mockApi.getActivities();
                if (mounted) {
                    setTasks(t);
                }
            } catch (error) {
                console.error('Failed to fetch activities', error);
            } finally {
                if (mounted) {
                    setLoading(false);
                }
            }
        };

        fetchTasks();

        return () => {
            mounted = false;
        };
    }, []);
    const exportToCSV = () => {
        if (tasks.length === 0) {
            alert("No tasks available to export!");
            return;
        }

        // 1. Define column headers
        const headers = ['Task ID', 'Title', 'Description', 'Priority', 'Status'];

        // 2. Map data rows and escape internal quotes to prevent layout breakage in Excel
        const rows = tasks.map((t) => [
            t._id || t.id || '',
            `"${(t.title || '').replace(/"/g, '""')}"`,
            `"${(t.description || '').replace(/"/g, '""')}"`,
            t.priority || 'Medium',
            t.completed ? 'Completed' : 'Pending'
        ]);

        // 3. Combine headers and rows with new lines
        const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');

        // 4. Create a Blob with UTF-8 character encoding BOM for Excel compatibility
        const blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), csvContent], {
            type: 'text/csv;charset=utf-8;'
        });

        // 5. Generate hidden download link and click it
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', `tasks_export_${new Date().toISOString().split('T')[0]}.csv`);
        document.body.appendChild(link);
        link.click();

        // Clean up memory
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };
    return (
        <>
            <div style={{ display: 'flex' }}>
                <Sidebar />
                <div style={{ flex: 1, padding: '20px' }} className="main-content">
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <h2 style={{ marginTop: '0' }}>Activities</h2>
                        <div style={{ display: 'flex', gap: '10px' }}>
                            <button
                                className="task-csv"
                                onClick={exportToCSV}
                                style={{ padding: '8px 16px', cursor: 'pointer' }}
                            >
                                Export CSV
                            </button>
                        </div>
                    </div>
                    <div className="task-list">
                        {tasks.map((t) => (
                            <div key={t._id || t.id} className="card task-item">
                                <div className="task-info">
                                    <div className="task-title">{t.action}</div>
                                    <div className="task-desc">{t.timestamp}</div>
                                    <div className="task-desc">Done by user{t.userId}</div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </>
    );
}