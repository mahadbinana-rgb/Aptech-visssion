import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bar, Doughnut, Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, PointElement, LineElement, ArcElement, Tooltip, Legend, Title, Filler } from 'chart.js';
import mockApi from '../services/mockApi';
import AdminSidebar from '../components/AdminSidebar';
import '../AuraAdmin.css'; // Importing the associated CSS file

ChartJS.register(CategoryScale, LinearScale, BarElement, PointElement, LineElement, ArcElement, Tooltip, Legend, Title, Filler);

export default function AuraAdmin() {
    const navigate = useNavigate();
    const [stats, setStats] = useState({
        totalEmployees: 0,
        totalTasks: 0,
        completedTasks: 0,
        aiRequests: 0,
        completionPct: 0,
        weeklyNodeLoad: [],
        weeklySecurityEvents: []
    });
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        async function loadStats() {
            try {
                setLoading(true);
                const [data, userList] = await Promise.all([
                    mockApi.fetchDashboardStats(),
                    mockApi.getUsers()
                ]);
                setStats(data);
                setUsers(userList);
            } catch (error) {
                console.error("Failed to load admin dashboard", error);
            } finally {
                setLoading(false);
            }
        }
        loadStats();
    }, []);

    const weeklyNodeLoad = stats.weeklyNodeLoad?.length > 0
        ? stats.weeklyNodeLoad
        : [
            { day: 'Mon', value: 72 },
            { day: 'Tue', value: 64 },
            { day: 'Wed', value: 78 },
            { day: 'Thu', value: 69 },
            { day: 'Fri', value: 84 },
            { day: 'Sat', value: 58 },
            { day: 'Sun', value: 46 },
        ];

    const weeklyThreatEvents = stats.weeklySecurityEvents?.length > 0
        ? stats.weeklySecurityEvents
        : [
            { day: 'Mon', value: 4 },
            { day: 'Tue', value: 6 },
            { day: 'Wed', value: 5 },
            { day: 'Thu', value: 7 },
            { day: 'Fri', value: 3 },
            { day: 'Sat', value: 2 },
            { day: 'Sun', value: 1 },
        ];

    const accessRequests = [
        { label: 'HR', value: 32 },
        { label: 'IT', value: 27 },
        { label: 'Ops', value: 21 },
        { label: 'Sales', value: 18 },
    ];

    const nodeLoadChartData = {
        labels: weeklyNodeLoad.map((item) => item.day),
        datasets: [
            {
                label: 'Node Load',
                data: weeklyNodeLoad.map((item) => item.value),
                borderColor: 'rgba(16, 185, 129, 1)',
                backgroundColor: 'rgba(16, 185, 129, 0.15)',
                fill: true,
                tension: 0.35,
                pointRadius: 5,
                pointBackgroundColor: '#10b981',
            },
        ],
    };

    const nodeLoadChartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { display: false },
            title: {
                display: true,
                text: 'Node Load Trend',
                color: '#f4f4f5',
                font: { size: 14, weight: '700' },
            },
        },
        scales: {
            x: { ticks: { color: '#a1a1aa' }, grid: { display: false } },
            y: {
                beginAtZero: true,
                ticks: { color: '#a1a1aa', stepSize: 20 },
                grid: { color: 'rgba(255,255,255,0.08)' },
            },
        },
    };

    const threatChartData = {
        labels: weeklyThreatEvents.map((item) => item.day),
        datasets: [
            {
                label: 'Security Events',
                data: weeklyThreatEvents.map((item) => item.value),
                backgroundColor: 'rgba(239, 68, 68, 0.75)',
                borderColor: 'rgba(239, 68, 68, 1)',
                borderWidth: 1,
                borderRadius: 8,
                maxBarThickness: 40,
            },
        ],
    };

    const threatChartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { display: false },
            title: {
                display: true,
                text: 'Security Events',
                color: '#f4f4f5',
                font: { size: 14, weight: '700' },
            },
        },
        scales: {
            x: { ticks: { color: '#a1a1aa' }, grid: { display: false } },
            y: {
                beginAtZero: true,
                ticks: { color: '#a1a1aa', stepSize: 2 },
                grid: { color: 'rgba(255,255,255,0.08)' },
            },
        },
    };

    const accessRequestsChartData = {
        labels: accessRequests.map((item) => item.label),
        datasets: [
            {
                label: 'Requests',
                data: accessRequests.map((item) => item.value),
                backgroundColor: ['#f59e0b', '#22c55e', '#38bdf8', '#818cf8'],
                hoverOffset: 6,
            },
        ],
    };

    const accessRequestsChartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom',
                labels: { color: '#a1a1aa' },
            },
            title: {
                display: true,
                text: 'Access Request Distribution',
                color: '#f4f4f5',
                font: { size: 14, weight: '700' },
            },
        },
    };

    const handleProvisionEmployee = async () => {
        const name = prompt("Enter employee's full name:");
        const email = prompt("Enter employee's corporate email:");
        const password = prompt("Assign temporary login password:");

        if (!name || !email || !password) {
            alert("Provisioning aborted: All identification fields are mandatory.");
            return;
        }

        try {
            await mockApi.provisionEmployee({
                name,
                email,
                password
            });
            const updatedStats = await mockApi.fetchDashboardStats();
            const updatedUsers = await mockApi.getUsers();
            setStats(updatedStats);
            setUsers(updatedUsers);
            alert(`Successfully provisioned network node for ${email}.`);
            location.reload()
        } catch (err) {
            console.error("FULL ERROR:", err);
            console.error("RESPONSE:", err.response);
            console.error("DATA:", err.response?.data);

            alert(
                `Provisioning Failed: ${err.response?.data?.message ||
                err.message ||
                "Unknown network rejection."
                }`
            );
        }
    };

    const handleDeleteEmployee = async (employeeId) => {
        if (!window.confirm("Are you sure you want to deprovision this employee? This action cannot be undone.")) {
            return;
        }

        try {
            await mockApi.deleteUser(employeeId);
            const updatedStats = await mockApi.fetchDashboardStats();
            const updatedUsers = await mockApi.getUsers();
            setStats(updatedStats);
            setUsers(updatedUsers);
            alert(`Successfully deprovisioned employee.`);
        } catch (err) {
            console.error("FULL ERROR:", err);
        }
    };
    if (loading) {
        return (
            <div className="aura-admin-wrapper">
                <div style={{ padding: '40px', textAlign: 'center', color: '#e2e8f0' }}>
                    Loading admin dashboard...
                </div>
            </div>
        );
    }

    return (
        <div className="aura-admin-wrapper">
            {/* Top Security Banner */}
            <div className="security-banner">
                <i className="fa-solid fa-triangle-exclamation"></i> Administrator Privileges Active — Proceed with Caution
            </div>

            <div className="layout-wrapper">
                {/* Sidebar Navigation */}
                <AdminSidebar />

                {/* Main Interface Workstation */}
                <main className="main-content">
                    <header className="header">
                        <div>
                            <h1>Identity & Access Management</h1>
                            <p>Manage intranet access and monitor local LLM provisioning.</p>
                        </div>
                        <div className="status-badge">
                            <i className="fa-solid fa-server"></i> PORT: 11434 SECURE
                        </div>
                    </header>

                    {/* Dynamic Metrics Panel Grid */}
                    <div className="stats-grid">
                        <div className="stat-card">
                            <div className="stat-label">Active Nodes</div>
                            <div className="stat-value">
                                {loading ? '...' : `${stats.totalUsers || 0} / 50`}
                            </div>
                        </div>
                        <div className="stat-card">
                            <div className="stat-label">Engine Status</div>
                            <div className="stat-value text-emerald">Operational</div>
                        </div>
                        <div className="stat-card border-emerald">
                            <div className="stat-label">Total Tasks</div>
                            <div className="stat-value text-emerald">{stats.totalTasks || 0}</div>
                        </div>
                        <div className="stat-card">
                            <div className="stat-label">AI Requests</div>
                            <div className="stat-value">{stats.totalAiLogs || 0}</div>
                        </div>
                        <div className="stat-card border-emerald">
                            <div className="stat-label">Completion Rate</div>
                            <div className="stat-value text-emerald">
                                {stats.totalTasks > 0
                                    ? Math.round((stats.completedTasks / stats.totalTasks) * 100)
                                    : 0}%
                            </div>
                        </div>
                        <div className="stat-card">
                            <div className="stat-label">Active Users</div>
                            <div className="stat-value">{stats.totalUsers || 0}</div>
                        </div>
                    </div>

                    <div className="admin-chart-grid">
                        <div className="admin-chart-card chart-card-wrapper">
                            <Line data={nodeLoadChartData} options={nodeLoadChartOptions} className="chart-wrapper" />
                        </div>

                        <div className="admin-chart-card chart-card-wrapper">
                            <Bar data={threatChartData} options={threatChartOptions} className="chart-wrapper" />
                        </div>

                        <div className="admin-chart-card chart-card-wrapper">
                            <Doughnut data={accessRequestsChartData} options={accessRequestsChartOptions} className="chart-wrapper" />
                        </div>
                    </div>

                    {/* Personnel Directory Data Table */}
                    <div className="panel">
                        <div className="panel-header">
                            <h3>Authorized Personnel Directory</h3>
                            <button className="btn-add" onClick={handleProvisionEmployee}>
                                <i className="fa-solid fa-plus"></i> Provision Employee
                            </button>
                        </div>
                        <table>
                            <thead>
                                <tr>
                                    <th>Employee ID</th>
                                    <th>Network Identity</th>
                                    <th>Access Level</th>
                                    <th>Authentication</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {users
                                    .filter(employee => employee.role !== 'admin')
                                    .map((employee, idx) => (
                                        <tr key={employee._id || employee.id}>
                                            <td className="font-mono">EMP-{String(idx + 1).padStart(3, '0')}</td>
                                            <td>{employee.email}</td>
                                            <td>
                                                <span className={`role-badge ${employee.role === 'admin' ? 'role-admin' : 'role-user'}`}>
                                                    {employee.role === 'admin' ? 'ROOT ADMIN' : 'STANDARD STAFF'}
                                                </span>
                                            </td>
                                            <td>
                                                <span className="auth-secure">
                                                    <i className="fa-solid fa-lock"></i> BCRYPT SECURED
                                                </span>
                                            </td>
                                            <td className="action-cell">
                                                <button className="delete-btn" onClick={() => handleDeleteEmployee(employee._id || employee.id)}>
                                                    Delete
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                            </tbody>
                        </table>
                    </div>
                </main>
            </div>
        </div>
    );
}