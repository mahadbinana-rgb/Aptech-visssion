import React, { useEffect, useMemo, useState } from 'react';
import Sidebar from '../components/Sidebar';
import { useAuth } from '../context/AuthContext';
import api from '../services/mockApi';
import './CodeSpace.css';

const starterFiles = [
  { path: 'README.md', language: 'markdown', content: '# New AURORA CodeSpace Project\n\nDescribe your project here.\n' },
  { path: 'src/app.js', language: 'javascript', content: "function start() {\n  console.log('Hello from CodeSpace');\n}\n\nstart();\n" },
];

const languageFromPath = (path) => {
  const ext = path.split('.').pop()?.toLowerCase();
  return ({ js:'javascript', jsx:'javascript', ts:'typescript', tsx:'typescript', py:'python', cs:'csharp', html:'html', css:'css', json:'json', md:'markdown', sql:'sql', java:'java', cpp:'cpp', c:'c' }[ext] || 'text');
};

export default function CodeSpace() {
  const { user } = useAuth();
  const [projects, setProjects] = useState([]);
  const [project, setProject] = useState(null);
  const [selectedPath, setSelectedPath] = useState('');
  const [draft, setDraft] = useState('');
  const [prompt, setPrompt] = useState('');
  const [aiBusy, setAiBusy] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [newProjectOpen, setNewProjectOpen] = useState(false);
  const [form, setForm] = useState({ name: '', description: '', kind: 'private' });
  const [permissionMode, setPermissionMode] = useState(false);
  const [employees, setEmployees] = useState([]);

  const selectedFile = useMemo(() => project?.files?.find((file) => file.path === selectedPath), [project, selectedPath]);

  useEffect(() => {
    loadProjects();
  }, []);

  useEffect(() => {
    if (selectedFile) setDraft(selectedFile.content || '');
  }, [selectedFile?.path, selectedFile?.content]);

  const loadProjects = async () => {
    try {
      const data = await api.getProjects();
      setProjects(data || []);
      if (!project && data?.length) openProject(data[0]._id);
    } catch (error) {
      setMessage(error.response?.data?.message || error.message || 'Could not load projects');
    }
  };

  const openProject = async (id) => {
    try {
      const data = await api.getProject(id);
      setProject(data);
      setSelectedPath(data.rootFile || data.files?.[0]?.path || '');
      setPermissionMode(false);
    } catch (error) {
      setMessage(error.response?.data?.message || 'Could not open project');
    }
  };

  const saveFile = async () => {
    if (!project || !selectedPath || !selectedFile) return;
    setSaving(true);
    try {
      const updated = await api.upsertProjectFile(project._id, { path: selectedPath, content: draft, language: selectedFile.language || languageFromPath(selectedPath) });
      setProject(updated);
      setProjects((items) => items.map((item) => item._id === updated._id ? updated : item));
      setMessage('Saved locally to the AURORA project vault.');
    } catch (error) {
      setMessage(error.response?.data?.message || 'Save failed');
    } finally { setSaving(false); }
  };

  const createProject = async (e) => {
    e.preventDefault();
    try {
      const created = await api.createProject({ ...form, files: starterFiles, rootFile: 'src/app.js' });
      setProjects((items) => [created, ...items]);
      setProject(created);
      setSelectedPath('src/app.js');
      setNewProjectOpen(false);
      setForm({ name: '', description: '', kind: 'private' });
      setMessage(`${created.kind === 'company' ? 'Company' : 'Private'} project created.`);
    } catch (error) {
      setMessage(error.response?.data?.message || 'Could not create project');
    }
  };

  const runAI = async () => {
    if (!project || !prompt.trim() || aiBusy) return;
    setAiBusy(true);
    setMessage('CodeSpace AI is reading the project context locally…');
    try {
      const result = await api.codeSpaceAI(project._id, { prompt, path: selectedPath, mode: 'edit' });
      if (result.project) {
        setProject(result.project);
        setProjects((items) => items.map((item) => item._id === result.project._id ? result.project : item));
      }
      const applied = result.appliedFiles?.length ? ` Updated: ${result.appliedFiles.join(', ')}.` : '';
      setMessage(`${result.summary || 'AI task completed.'}${applied}`);
      setPrompt('');
    } catch (error) {
      setMessage(error.response?.data?.message || 'CodeSpace AI request failed');
    } finally { setAiBusy(false); }
  };

  const deleteProject = async () => {
    if (!project || !window.confirm(`Delete “${project.name}”? This cannot be undone.`)) return;
    try {
      await api.deleteProject(project._id);
      const next = projects.filter((item) => item._id !== project._id);
      setProjects(next);
      setProject(null);
      setSelectedPath('');
      setDraft('');
      if (next[0]) openProject(next[0]._id);
      setMessage('Project deleted.');
    } catch (error) {
      setMessage(error.response?.data?.message || 'Delete failed');
    }
  };

  const loadEmployees = async () => {
    try {
      setEmployees(await api.getUsers());
      setPermissionMode(true);
    } catch (error) {
      setMessage(error.response?.data?.message || 'Could not load company members');
    }
  };

  const savePermissions = async () => {
    try {
      const collaborators = employees.filter((employee) => employee._selectedPermission).map((employee) => ({ userId: employee._id, permission: employee._selectedPermission }));
      const updated = await api.updateProject(project._id, { collaborators });
      setProject(updated);
      setPermissionMode(false);
      setMessage('Project permissions updated.');
    } catch (error) { setMessage(error.response?.data?.message || 'Could not save permissions'); }
  };

  return (
    <div className="codespace-shell">
      <Sidebar />
      <main className="codespace main-content">
        <header className="codespace-topbar">
          <div>
            <div className="eyebrow">LOCAL DEVELOPMENT HUB</div>
            <h1>CodeSpace</h1>
            <p>Project-aware AI development with Ollama. No cloud coding API is used by this workspace.</p>
          </div>
          <div className="topbar-actions">
            <span className="privacy-pill"><span className="dot" /> Local AI</span>
            <button className="btn btn-primary" onClick={() => setNewProjectOpen(true)}>+ New project</button>
          </div>
        </header>

        {message && <div className="codespace-banner">{message}</div>}

        <section className="codespace-grid">
          <aside className="project-panel">
            <div className="panel-heading"><span>Projects</span><span className="muted">{projects.length}</span></div>
            <div className="project-groups">
              <div className="group-label">YOUR PROJECTS</div>
              {projects.filter((item) => item.kind === 'private').map((item) => (
                <button key={item._id} className={`project-row ${project?._id === item._id ? 'selected' : ''}`} onClick={() => openProject(item._id)}>
                  <span className="project-icon private">◇</span><span className="project-name">{item.name}</span><span className="project-type">Private</span>
                </button>
              ))}
              <div className="group-label company">COMPANY PROJECTS</div>
              {projects.filter((item) => item.kind === 'company').map((item) => (
                <button key={item._id} className={`project-row ${project?._id === item._id ? 'selected' : ''}`} onClick={() => openProject(item._id)}>
                  <span className="project-icon company">◆</span><span className="project-name">{item.name}</span><span className="project-type">Shared</span>
                </button>
              ))}
              {!projects.length && <div className="empty-state">Create your first private or company project.</div>}
            </div>
          </aside>

          {project ? (
            <>
              <aside className="file-panel">
                <div className="project-header">
                  <div><strong>{project.name}</strong><span>{project.kind === 'company' ? 'Company project' : 'Private project'}</span></div>
                  <span className="permission-tag">{project.permission || 'owner'}</span>
                </div>
                <div className="file-list">
                  {(project.files || []).map((file) => (
                    <button key={file.path} className={`file-row ${selectedPath === file.path ? 'active' : ''}`} onClick={() => setSelectedPath(file.path)}>
                      <span className="file-lang">{(file.language || languageFromPath(file.path)).slice(0, 2).toUpperCase()}</span>
                      <span>{file.path}</span>
                    </button>
                  ))}
                </div>
                <button className="file-add" onClick={async () => {
                  const path = window.prompt('New file path, e.g. src/utils.js');
                  if (!path) return;
                  try { const updated = await api.upsertProjectFile(project._id, { path, content: '', language: languageFromPath(path) }); setProject(updated); setProjects((items) => items.map((item) => item._id === updated._id ? updated : item)); setSelectedPath(path); } catch (error) { setMessage(error.response?.data?.message || 'Could not create file'); }
                }}>+ Add file</button>
              </aside>

              <section className="editor-workspace">
                <div className="editor-toolbar">
                  <div className="breadcrumbs"><span>{project.name}</span><b>/</b><span>{selectedPath || 'No file selected'}</span></div>
                  <div className="editor-actions">
                    {project.kind === 'company' && ['admin','manager'].includes(user?.role) && <button className="ghost-btn" onClick={loadEmployees}>Permissions</button>}
                    <button className="ghost-btn danger" onClick={deleteProject}>Delete</button>
                    <button className="save-btn" onClick={saveFile} disabled={saving || !selectedFile}>{saving ? 'Saving…' : 'Save file'}</button>
                  </div>
                </div>
                <div className="editor-body">
                  <div className="line-numbers">{draft.split('\n').map((_, i) => <span key={i}>{i + 1}</span>)}</div>
                  <textarea value={draft} onChange={(e) => setDraft(e.target.value)} spellCheck="false" disabled={!selectedFile || !['owner','editor','developer'].includes(project.permission)} />
                </div>
                <div className="ai-console">
                  <div className="ai-console-heading"><div><span className="ai-spark">✦</span> CodeSpace AI</div><span>Project context enabled</span></div>
                  <div className="quick-prompts">
                    {['Fix the current bug and explain the root cause', 'Refactor this project for maintainability', 'Add tests for the selected file', 'Improve this UI without changing its behavior'].map((item) => <button key={item} onClick={() => setPrompt(item)}>{item}</button>)}
                  </div>
                  <div className="ai-input-row">
                    <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} onKeyDown={(e) => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') runAI(); }} placeholder="Tell CodeSpace what to build, change, debug, explain, or refactor…" />
                    <button className="ai-run" disabled={!prompt.trim() || aiBusy} onClick={runAI}>{aiBusy ? 'Working…' : 'Run AI ↵'}</button>
                  </div>
                  <div className="ai-footnote">Ctrl/Cmd + Enter to run · AI receives the current project files as context · Ollama endpoint stays server-side</div>
                </div>
              </section>
            </>
          ) : (
            <section className="codespace-empty"><div className="empty-orbit">✦</div><h2>Build privately. Ship confidently.</h2><p>Open a project or create a new workspace. Company projects can be shared with fine-grained permissions; private projects stay with their owner.</p><button className="btn btn-primary" onClick={() => setNewProjectOpen(true)}>Create project</button></section>
          )}
        </section>
      </main>

      {newProjectOpen && <div className="modal-backdrop"><form className="modal-card" onSubmit={createProject}><div className="modal-heading"><div><span className="eyebrow">CODESPACE</span><h2>New project</h2></div><button type="button" className="modal-close" onClick={() => setNewProjectOpen(false)}>×</button></div><label>Name<input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Atlas website" required /></label><label>Description<textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="What are you building?" /></label><div className="kind-switch"><button type="button" className={form.kind === 'private' ? 'active' : ''} onClick={() => setForm({ ...form, kind: 'private' })}>Private</button><button type="button" className={form.kind === 'company' ? 'active' : ''} onClick={() => setForm({ ...form, kind: 'company' })}>Company shared</button></div><p className="modal-note">Private projects use local Ollama and can only be edited by their owner. Company projects can be shared with selected coworkers; managers and admins retain full project access.</p><button className="btn btn-primary" type="submit">Create CodeSpace</button></form></div>}

      {permissionMode && <div className="modal-backdrop"><div className="modal-card permissions"><div className="modal-heading"><div><span className="eyebrow">ACCESS CONTROL</span><h2>{project?.name}</h2></div><button className="modal-close" onClick={() => setPermissionMode(false)}>×</button></div><p className="modal-note">Managers and admins have full company-project access. Choose extra access for other company members below.</p><div className="member-permissions">{employees.filter((employee) => String(employee._id) !== String(user?.id)).map((employee) => <div className="member-row" key={employee._id}><div><strong>{employee.name}</strong><span>{employee.role}</span></div><select defaultValue={project?.collaborators?.find((c) => String(c.userId) === String(employee._id))?.permission || 'none'} onChange={(e) => { employee._selectedPermission = e.target.value === 'none' ? null : e.target.value; }}><option value="none">No access</option><option value="viewer">Viewer</option><option value="commenter">Commenter</option><option value="editor">Editor</option><option value="developer">Developer</option></select></div>)}</div><button className="btn btn-primary" onClick={savePermissions}>Save access</button></div></div>}
    </div>
  );
}
