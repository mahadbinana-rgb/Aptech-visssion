import React, { useEffect, useState } from 'react';
import { Bar, Doughnut, Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
  Title,
  Filler
} from 'chart.js';

import mockApi from '../services/mockApi';
import { useAuth } from '../context/AuthContext';
import '../main.css';
import '../Dashboard.css';
import Sidebar from '../components/Sidebar';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  PointElement,
  LineElement,
  Tooltip,
  Legend,
  Title,
  Filler
);

export default function Dashboard() {
  const { user } = useAuth();

  const [stats, setStats] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [remindersToday, setRemindersToday] = useState([]);
  const [totalNotes, setTotalNotes] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    // Execute all API requests concurrently on mount
    Promise.all([
      mockApi.fetchDashboardStats(),
      mockApi.getTasks(),
      mockApi.getReminders(),
      mockApi.getNotes()
    ])
      .then(([summary, taskList, reminderList, notesList]) => {
        if (!mounted) return;

        // Filter reminders for today safely
        const today = new Date().toDateString();
        const filteredReminders = (reminderList || []).filter(r => {
          return new Date(r.dueTime).toDateString() === today;
        });

        setStats(summary);
        setTasks(taskList || []);
        setRemindersToday(filteredReminders);
        setTotalNotes(notesList?.length || 0);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Dashboard load error:', err);
        if (mounted) setLoading(false);
      });

    return () => {
      mounted = false;
    };
  }, []);

  if (loading) {
    return (
      <div className="aura-workspace-container">
        <Sidebar />
        <main className="main-content">
          <div className="panel">
            Loading Dashboard...
          </div>
        </main>
      </div>
    );
  }

  // Employee Metrics calculations
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => t.completed).length;
  const pendingTasks = totalTasks - completedTasks;
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const highTasks = tasks.filter(t => (t.priority || '').toLowerCase() === 'high').length;
  const mediumTasks = tasks.filter(t => (t.priority || '').toLowerCase() === 'medium').length;
  const lowTasks = tasks.filter(t => (t.priority || '').toLowerCase() === 'low').length;

  const pendingTaskList = tasks.filter(task => !task.completed).slice(0, 5);

  // Chart 1 - Task Status
  const statusChartData = {
    labels: ['Completed', 'Pending'],
    datasets: [
      {
        label: 'Tasks',
        data: [completedTasks, pendingTasks],
        backgroundColor: ['rgba(34,197,94,0.8)', 'rgba(239,68,68,0.8)']
      }
    ]
  };

  // Chart 2 - Priority Distribution
  const priorityChartData = {
    labels: ['High', 'Medium', 'Low'],
    datasets: [
      {
        label: 'Tasks',
        data: [highTasks, mediumTasks, lowTasks],
        backgroundColor: ['rgba(239,68,68,0.8)', 'rgba(234,179,8,0.8)', 'rgba(34,197,94,0.8)']
      }
    ]
  };

  // Chart 3 - Productivity Trend
  const productivityChartData = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        label: 'Productivity %',
        data: stats?.productivityTrend || [0, 0, 0, 0, 0, 0, 0],
        borderColor: '#38bdf8',
        backgroundColor: 'rgba(56,189,248,0.15)',
        fill: true,
        tension: 0.4
      }
    ]
  };

  // Chart 4 - Weekly Tasks
  const weeklyTasksData = {
    labels: (stats?.weeklyTasks || []).map(x => x.day),
    datasets: [
      {
        label: 'Tasks',
        data: (stats?.weeklyTasks || []).map(x => x.value),
        backgroundColor: 'rgba(59,130,246,0.8)',
        borderRadius: 8
      }
    ]
  };

  const commonOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        labels: {
          color: '#e2e8f0'
        }
      }
    }
  };

  return (
    <div className="aura-workspace-container">
      <Sidebar />

      <main className="main-content">
        <header className="header">
          <div>
            <h1>Welcome, {user?.name || 'Employee'}</h1>
            <p>
              You currently have {pendingTasks} pending task
              {pendingTasks !== 1 ? 's' : ''}.
            </p>
          </div>

          <div className="status-badge">
            <div className="pulse"></div>
            Local AI Online • Qwen2.5 1.5B
          </div>
        </header>

        <div className="dashboard-grid">
          {/* Stats Summary */}
          <div className="panel">
            <h3 className="panel-title">My Workspace Summary</h3>
            <div className="stats-row">
              <div className="stat-card">
                <span>My Tasks: </span>
                <strong>{totalTasks}</strong>
              </div>
              <div className="stat-card">
                <span>Completed: </span>
                <strong>{completedTasks}</strong>
              </div>
              <div className="stat-card">
                <span>Pending: </span>
                <strong>{pendingTasks}</strong>
              </div>
              <div className="stat-card">
                <span>Completion: </span>
                <strong>{completionRate}%</strong>
              </div>
              <div className="stat-card">
                <span>Notes: </span>
                <strong>{totalNotes}</strong>
              </div>
            </div>
          </div>

          {/* Today's Reminders */}
          <div className="panel">
            <h3 className="panel-title">Today's Reminders</h3>
            <div className="reminders-list">
              {remindersToday.length > 0 ? (
                remindersToday.map(r => (
                  <div key={r._id} className="reminder-item" style={{ marginTop: '20px' }}>
                    <div className="reminder-title">{r.title}</div>
                    <div className="reminder-time">
                      Due: {new Date(r.dueTime).toLocaleTimeString()}
                    </div>
                  </div>
                ))
              ) : (
                <div>No reminders for today 🎉</div>
              )}
            </div>
          </div>

          {/* Pending Tasks List */}
          <div className="panel">
            <h3 className="panel-title">My Pending Tasks</h3>
            <div className="tasks-list">
              {pendingTaskList.length > 0 ? (
                pendingTaskList.map(task => (
                  <div key={task._id} className="task-item">
                    <span>{task.title}</span>
                    <span
                      className={`priority-badge priority-${task.priority?.toLowerCase() === 'medium' ? 'med' : task.priority?.toLowerCase()
                        }`}
                    >
                      {task.priority}
                    </span>
                  </div>
                ))
              ) : (
                <div>No pending tasks 🎉</div>
              )}
            </div>
          </div>
          {/* Weekly Tasks Chart */}
          <div className="panel">
            <h3 className="panel-title">Weekly Task Activity</h3>
            <div style={{ height: '280px' }}>
              <Bar data={weeklyTasksData} options={commonOptions} />
            </div>
          </div>

          {/* Task Status Chart */}
          <div className="panel">
            <h3 className="panel-title">Task Status Breakdown</h3>
            <div style={{ height: '280px' }}>
              <Doughnut data={statusChartData} options={commonOptions} />
            </div>
          </div>

          {/* Priority Distribution Chart */}
          <div className="panel">
            <h3 className="panel-title">Priority Distribution</h3>
            <div style={{ height: '280px' }}>
              <Doughnut data={priorityChartData} options={commonOptions} />
            </div>
          </div>
          {/* Productivity Trend Chart */}
          <div className="panel">
            <h3 className="panel-title">Productivity Trend</h3>
            <div style={{ height: '280px' }}>
              <Line data={productivityChartData} options={commonOptions} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}