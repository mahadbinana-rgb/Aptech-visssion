import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import AdminSidebar from "../components/AdminSidebar";
import api from "../services/mockApi";
import "../AuraAdmin.css";
import "../Employees.css";

const RECOGNITION_TYPES = [
  { value: "employee_of_month", label: "Employee of the Month", icon: "⭐" },
  { value: "most_productive", label: "Most Productive", icon: "🔥" },
  { value: "most_helpful", label: "Most Helpful", icon: "🤝" },
  { value: "best_ideas", label: "Best Ideas", icon: "💡" },
];

const RECOGNITION_MAP = {};
RECOGNITION_TYPES.forEach((t) => { RECOGNITION_MAP[t.value] = t; });

export default function EmployeeProfile() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [employee, setEmployee] = useState(null);
  const [recognitions, setRecognitions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [awardType, setAwardType] = useState("employee_of_month");
  const [awardNote, setAwardNote] = useState("");
  const [awarding, setAwarding] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!id) return;
    setLoading(true);

    Promise.all([
      api.getUserById(id).catch((err) => { setError("Failed to load profile"); return null; }),
      api.getEmployeeRecognitions(id).catch(() => []),
    ]).then(([userData, recData]) => {
      if (userData) setEmployee(userData);
      if (Array.isArray(recData)) setRecognitions(recData);
      setLoading(false);
    });
  }, [id]);

  const handleAward = async () => {
    setAwarding(true);
    setError("");
    try {
      const result = await api.awardRecognition({
        employeeId: id,
        type: awardType,
        note: awardNote,
      });
      setRecognitions((prev) => [result, ...prev]);
      setAwardNote("");
    } catch (err) {
      setError(err.response?.data?.message || "Failed to award recognition");
    }
    setAwarding(false);
  };

  const handleDeleteRecognition = async (recId) => {
    if (!window.confirm("Delete this recognition?")) return;
    try {
      await api.deleteRecognition(recId);
      setRecognitions((prev) => prev.filter((r) => r._id !== recId));
    } catch (err) {
      setError("Failed to delete");
    }
  };

  if (loading) {
    return (
      <div className="aura-admin-wrapper">
        <div className="layout-wrapper">
          <AdminSidebar />
          <main className="main-content" style={{ padding: "40px", color: "#a1a1aa" }}>Loading profile...</main>
        </div>
      </div>
    );
  }

  if (!employee) {
    return (
      <div className="aura-admin-wrapper">
        <div className="layout-wrapper">
          <AdminSidebar />
          <main className="main-content" style={{ padding: "40px", color: "#ef4444" }}>
            {error || "Employee not found"}
            <br />
            <button onClick={() => navigate("/employees")} className="profile-link-btn" style={{ marginTop: "1rem" }}>
              Back to Employees
            </button>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="aura-admin-wrapper">
      <div className="security-banner">
        <i className="fa-solid fa-triangle-exclamation"></i> Administrator Privileges Active — Employee Profile View
      </div>
      <div className="layout-wrapper">
        <AdminSidebar />
        <main className="main-content">
          <header className="header">
            <div>
              <h1>Employee Profile</h1>
              <p>{employee.name} — {employee.email}</p>
            </div>
            <button onClick={() => navigate("/employees")} className="profile-link-btn">
              ← Back
            </button>
          </header>

          {error && (
            <div style={{ backgroundColor: "rgba(239,68,68,0.1)", border: "1px solid #ef4444", color: "#fca5a5", padding: "0.75rem", borderRadius: "8px", marginBottom: "1rem" }}>
              {error}
            </div>
          )}

          {/* Profile Card */}
          <div className="employee-profile-card">
            <div className="employee-profile-header">
              <div className="employee-avatar">
                {employee.name?.[0]?.toUpperCase() || "U"}
              </div>
              <div className="employee-profile-info">
                <h2>{employee.name}</h2>
                <span className="role-tag">{employee.role?.toUpperCase()}</span>
                <div className="email">{employee.email}</div>
                <div style={{ color: "#52525b", fontSize: "0.8rem", marginTop: "0.25rem" }}>
                  Joined: {employee.createdAt ? new Date(employee.createdAt).toLocaleDateString() : "N/A"}
                </div>
              </div>
            </div>

            {/* Stats */}
            <h3 className="recognition-section-title">Activity Overview</h3>
            <div className="profile-stat-grid">
              <div className="profile-stat-item">
                <div className="profile-stat-number">{recognitions.length}</div>
                <div className="profile-stat-label">Recognitions</div>
              </div>
              <div className="profile-stat-item">
                <div className="profile-stat-number">{recognitions.length}</div>
                <div className="profile-stat-label">Tasks Completed</div>
              </div>
            </div>
          </div>

          {/* Award Recognition (admin only) */}
          <div className="employee-profile-card">
            <h3 className="recognition-section-title">🎖️ Award Recognition</h3>
            <div className="award-form">
              <select value={awardType} onChange={(e) => setAwardType(e.target.value)}>
                {RECOGNITION_TYPES.map((t) => (
                  <option key={t.value} value={t.value}>{t.icon} {t.label}</option>
                ))}
              </select>
              <input
                type="text"
                placeholder="Note (optional)"
                value={awardNote}
                onChange={(e) => setAwardNote(e.target.value)}
              />
              <button onClick={handleAward} disabled={awarding}>
                {awarding ? "Awarding..." : "Award Recognition"}
              </button>
            </div>
          </div>

          {/* Recognition History */}
          <div className="employee-profile-card">
            <h3 className="recognition-section-title">🏆 Recognition History</h3>
            {recognitions.length === 0 ? (
              <p style={{ color: "#a1a1aa", fontSize: "0.9rem" }}>No recognitions awarded yet.</p>
            ) : (
              recognitions.map((r) => (
                <div key={r._id} className="recognition-badge">
                  <span className="recognition-icon">{r.icon || "🏆"}</span>
                  <span className="recognition-label">{r.label}</span>
                  {r.note && <span className="recognition-note">— {r.note}</span>}
                  <span className="recognition-awarded-by">
                    by {r.awardedBy?.name || "Admin"}
                  </span>
                  <span className="recognition-date">
                    {r.awardedAt ? new Date(r.awardedAt).toLocaleDateString() : ""}
                  </span>
                  <button
                    className="recognition-delete-btn"
                    onClick={() => handleDeleteRecognition(r._id)}
                    title="Delete recognition"
                  >
                    ×
                  </button>
                </div>
              ))
            )}
          </div>
        </main>
      </div>
    </div>
  );
}