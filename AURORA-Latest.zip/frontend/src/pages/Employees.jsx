import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import mockApi from '../services/mockApi';
import AdminSidebar from '../components/AdminSidebar';
import '../AuraAdmin.css';

export default function Employees() {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    mockApi.getUsers()
      .then((users) => {
        if (Array.isArray(users)) setEmployees(users);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Failed to load employees:", err);
        setLoading(false);
      });
  }, []);

  const handleProvisionEmployee = async () => {
    const name = prompt("Enter employee's full name:");
    const email = prompt("Enter employee's corporate email:");
    const password = prompt("Assign temporary login password:");
    const role = prompt("Role: employee, lead, or manager (admin only)", "employee")?.toLowerCase() || 'employee';

    if (!name || !email || !password) {
      alert("Provisioning aborted: All identification fields are mandatory.");
      return;
    }

    try {
      await mockApi.provisionEmployee({
        name,
        email,
        password,
        role
      });
      const updatedStats = await mockApi.fetchDashboardStats();
      const updatedUsers = await mockApi.getUsers();
      alert(`Successfully provisioned network node for ${email}.`);
      location.reload()
    } catch (err) {
      console.error("FULL ERROR:", err);
      console.error("RESPONSE:", err.response);
      console.error("DATA:", err.response?.data);

      alert(
        `Provisioning Failed: ${err.response?.data?.message ||
        err.message ||
        "Unknown network rejection."
        }`
      );
    }
  };

  const handleDeleteEmployee = async (employeeId) => {
    if (!window.confirm("Are you sure you want to deprovision this employee? This action cannot be undone.")) {
      return;
    }
    try {
      await mockApi.deleteUser(employeeId);
      const updatedUsers = await mockApi.getUsers();
      if (Array.isArray(updatedUsers)) setEmployees(updatedUsers);
    } catch (err) {
      console.error("Delete error:", err);
      alert("Failed to delete employee.");
    }
  };

  return (
    <div className="aura-admin-wrapper" style={{ backgroundColor: '#09090b', minHeight: '100vh', color: '#f4f4f5' }}>
      <div className="security-banner" style={{ background: '#7f1d1d', padding: '10px 24px', color: '#fca5a5', fontSize: '13px', fontWeight: 600 }}>
        <i className="fa-solid fa-triangle-exclamation"></i> Administrator Privileges Active — Proceed with Caution
      </div>

      <div style={{ display: 'flex', flex: 1 }}>
        <AdminSidebar />
        <main style={{ flex: 1, padding: '24px', marginLeft: '300px', maxWidth: '1200px' }}>
          <div style={{ marginBottom: '24px' }}>
            <h1 style={{ fontSize: '24px', color: '#f4f4f5', marginBottom: '4px' }}>Identity & Access Management</h1>
            <p style={{ color: '#a1a1aa', fontSize: '14px' }}>Manage intranet access and monitor personnel directory.</p>
            <button className="btn-add" style={{ marginTop: '15px' }} onClick={handleProvisionEmployee}>
              <i className="fa-solid fa-plus"></i> Provision Employee
            </button>
          </div>

          {loading ? (
            <div style={{ textAlign: 'center', padding: '40px', color: '#a1a1aa' }}>Loading personnel directory...</div>
          ) : (
            <>
              <h3 style={{ color: '#f4f4f5', fontSize: '16px', marginBottom: '16px', borderBottom: '1px solid #27272a', paddingBottom: '8px' }}>
                Authorized Personnel Directory ({employees.filter(e => e.role !== 'admin').length})
              </h3>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '16px' }}>
                {employees
                  .filter(emp => emp.role !== 'admin')
                  .map((emp, idx) => (
                    <div key={emp._id || emp.id} style={{
                      backgroundColor: '#18181b',
                      border: '1px solid #27272a',
                      borderRadius: '12px',
                      padding: '20px',
                    }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                        <span style={{ fontFamily: 'monospace', color: '#f59e0b', fontWeight: 700, fontSize: '13px' }}>
                          EMP-{String(idx + 1).padStart(3, '0')}
                        </span>
                        <span style={{
                          fontSize: '11px', fontWeight: 700, textTransform: 'uppercase',
                          padding: '4px 8px', borderRadius: '999px',
                          background: 'rgba(16, 185, 129, 0.15)', color: '#10b981'
                        }}>
                          {emp.role?.toUpperCase() || 'EMPLOYEE'}
                        </span>
                      </div>
                      <div style={{ fontSize: '16px', fontWeight: 700, color: '#f4f4f5', marginBottom: '6px' }}>{emp.name}</div>
                      <div style={{ fontSize: '13px', color: '#a1a1aa', marginBottom: '12px' }}>{emp.email}</div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', color: '#10b981', fontWeight: 600, marginBottom: '16px' }}>
                        <i className="fa-solid fa-lock"></i> BCRYPT SECURED
                      </div>
                      <div style={{ display: 'flex', gap: '8px' }}>
                        <button
                          onClick={() => navigate(`/employee-profile/${emp._id || emp.id}`)}
                          style={{
                            flex: 1, padding: '8px 12px', borderRadius: '6px', border: 'none',
                            background: '#f59e0b', color: '#09090b', fontWeight: 600, fontSize: '13px',
                            cursor: 'pointer'
                          }}
                        >
                          👤 Profile
                        </button>
                        <button
                          onClick={() => navigate("/taskAssighn", {
                            state: {
                              employeeId: emp._id || emp.id,
                              employeeName: emp.name || 'Employee'
                            }
                          })}
                          style={{
                            flex: 1, padding: '8px 12px', borderRadius: '6px', border: 'none',
                            background: '#084f19', color: 'white', fontWeight: 600, fontSize: '10px',
                            cursor: 'pointer'
                          }}
                        >
                          Assighn A Task
                        </button>
                        <button
                          onClick={() => handleDeleteEmployee(emp._id || emp.id)}
                          style={{
                            flex: 1, padding: '8px 12px', borderRadius: '6px',
                            background: 'transparent', color: '#ef4444', border: '1px solid #ef4444',
                            fontWeight: 600, fontSize: '13px', cursor: 'pointer'
                          }}
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  ))}
              </div>
            </>
          )}
        </main>
      </div>
    </div>
  );
}