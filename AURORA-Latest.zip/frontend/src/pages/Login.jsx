import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import '../Login.css';
import '../main.css';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useAuth();
  const nav = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    try {
      const res = await login({ email, password });
      if (['admin', 'manager', 'lead'].includes(res.user?.role)) {
        nav('/admin');
      } else {
        nav('/');
      }
    } catch (err) {
      alert(err.message || 'Login failed');
    }
  };

  return (
    <div className="login-body">
      <div className="login-card">
        <div className="brand">
          <i className="fa-solid fa-microchip"></i> AURORA AI
        </div>
        <div className="subtitle">Secure Corporate Portal Login</div>
        
        <form onSubmit={submit}>
          <div className="input-group">
            <label>Corporate Email</label>
            <div className="input-wrapper">
              <i className="fa-solid fa-envelope"></i>
              <input 
                type="email" 
                placeholder="employee@company.local" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required 
              />
            </div>
          </div>
          
          <div className="input-group">
            <label>Security Password</label>
            <div className="input-wrapper">
              <i className="fa-solid fa-lock"></i>
              <input 
                type="password" 
                placeholder="••••••••" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required 
              />
            </div>
          </div>
          
          <button type="submit" className="btn-login">
            Enter Workspace
          </button>
        </form>
        
        <div className="footer-note">
          <p>Dont have a account? <Link to='/register'>Make a account</Link></p>
          <i className="fa-solid fa-shield-halved" style={{ color: 'var(--accent-blue)' }}></i> 
          Secured Intranet Connection Active
        </div>
      </div>
    </div>
  );
}