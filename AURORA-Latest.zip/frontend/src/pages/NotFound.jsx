import React from 'react'

export default function NotFound() {
  return (
    <center>
      <div className="text-center mt-20">
        <h1 className="text-4xl">404</h1>
        <p className="muted">Page not found</p>
      </div>
    </center>
  )
}