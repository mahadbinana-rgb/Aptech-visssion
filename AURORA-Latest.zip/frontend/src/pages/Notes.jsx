import React, { useEffect, useState } from 'react';
import mockApi from '../services/mockApi';
import '../Notes.css';
import '../main.css';
import Sidebar from '../components/Sidebar';

export default function Notes() {
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState('');
  const [summaries, setSummaries] = useState({});
  
  // Track loading state per note ID
  const [loadingSummaries, setLoadingSummaries] = useState({});

  const summarizeNote = async (note) => {
    const noteId = note._id || note.id;
    if (!noteId) return;

    // Set loading to true for this specific note
    setLoadingSummaries(prev => ({ ...prev, [noteId]: true }));

    try {
      const result = await mockApi.summarizeNote({ content: note.content });
      setSummaries(prev => ({ ...prev, [noteId]: result.response || result }));
    } catch (error) {
      console.error("Failed to generate summary:", error);
    } finally {
      // Set loading to false when done (success or error)
      setLoadingSummaries(prev => ({ ...prev, [noteId]: false }));
    }
  };

  useEffect(() => {
    let mounted = true;
    mockApi.getNotes().then((n) => {
      if (mounted) {
        setNotes(n);
        setLoading(false);
      }
    }).catch(() => {
      if (mounted) setLoading(false);
    });
    return () => {
      mounted = false;
    };
  }, []);

  // CSV Export Function for Notes
  const exportToCSV = () => {
    if (notes.length === 0) {
      alert("No notes available to export!");
      return;
    }

    // 1. Define column headers
    const headers = ['Note ID', 'Title', 'Content', 'Created At', 'AI Summary'];

    // 2. Map data rows and escape quotes so multi-line text blocks do not break columns
    const rows = notes.map((n) => {
      const currentId = n._id || n.id || '';
      const summaryText = summaries[currentId] || 'No summary generated';
      const creationDate = n.createdAt ? new Date(n.createdAt).toLocaleString() : 'Just now';

      return [
        currentId,
        `"${(n.title || '').replace(/"/g, '""')}"`,
        `"${(n.content || '').replace(/"/g, '""')}"`,
        `"${creationDate}"`,
        `"${summaryText.replace(/"/g, '""')}"`
      ];
    });

    // 3. Combine headers and rows with new line strings
    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');

    // 4. Wrap file contents with a UTF-8 BOM to ensure Excel opens text symbols correctly
    const blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), csvContent], { 
      type: 'text/csv;charset=utf-8;' 
    });

    // 5. Generate virtual file attachment hook and simulate cursor click
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `notes_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    
    // Cleanup browser engine file tracking pointers
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const add = async () => {
    if (!content.trim()) return;
    const n = await mockApi.createNote({ title: content.slice(0, 30), content });
    setNotes((s) => [n, ...s]);
    setContent('');
  };

  const deleteNote = async (id) => {
    await mockApi.deleteNote(id);
    setNotes((s) => s.filter((x) => x._id !== id && x.id !== id));
  }

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const formData = new FormData();
    formData.append('file', file);
    try {
      const response = await fetch(
        'http://localhost:1000/api/notes/upload',
        { method: 'POST', body: formData }
      );
      const note = await response.json();
      setNotes((prev) => [note, ...prev]);
    } catch (err) {
      console.error(err);
      alert('Failed to upload file');
    }
  };

  if (loading) return <div className="card">Loading notes...</div>;

  return (
    <div style={{ display: 'flex' }}>
      <Sidebar />
      <div style={{ width: '100%', padding: '20px' }} className='main-content'>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '20px', marginBottom: '20px' }}>
          <h2 style={{ margin: 0 }}>Notes</h2>
          {/* Integrated Export CSV Action Button */}
          <button 
            className="btn btn-secondary" 
            onClick={exportToCSV}
            style={{ padding: '8px 16px', cursor: 'pointer', border: '1px solid #ccc', borderRadius: '4px' }}
          >
            Export CSV
          </button>
        </div>

        <div className="card notes-editor">
          <textarea 
            value={content} 
            onChange={(e) => setContent(e.target.value)} 
            className="note-textarea" 
            placeholder="Write a note..." 
          ></textarea>
          <div className="text-right">
            <button className="btn btn-primary" onClick={add} style={{color: 'black'}}>+ Create Note</button>
          </div>
        </div>
        <div className="notes-list">
          {notes.map(n => {
            const currentId = n._id || n.id;
            const isSummarizing = !!loadingSummaries[currentId];

            return (
              <div key={currentId} className="card note-card">
                <div className="note-content">
                  <div className="note-title">{n.title}</div>
                  <div className="note-text">{n.content}</div>
                  <div className="createdAt">
                    Created: {n.createdAt ? new Date(n.createdAt).toLocaleString() : 'Just now'}
                  </div>
                </div>
                <div className="note-actions">
                  <button 
                    className="btn-summarize" 
                    onClick={() => summarizeNote(n)}
                    disabled={isSummarizing}
                    style={{ opacity: isSummarizing ? 0.6 : 1, cursor: isSummarizing ? 'not-allowed' : 'pointer' }}
                  >
                    {isSummarizing ? 'Summarizing...' : 'Summarize with AURORA AI'}
                  </button>
                </div>
                {summaries[currentId] && (
                  <div className="note-summary mt-2 p-2 bg-gray-100 rounded">
                    <strong>Summary:</strong> {summaries[currentId]}
                  </div>
                )}
                <button className="delete-btn" onClick={() => deleteNote(currentId)}>
                  Delete
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}