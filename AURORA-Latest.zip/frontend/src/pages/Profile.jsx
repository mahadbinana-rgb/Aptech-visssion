import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import Sidebar from "../components/Sidebar";
import api from "../services/mockApi";
import "../main.css";

const RECOGNITION_ICONS = {
  employee_of_month: "⭐",
  most_productive: "🔥",
  most_helpful: "🤝",
  best_ideas: "💡",
};

export default function Profile() {
  const { user } = useAuth();
  const [recognitions, setRecognitions] = useState([]);
  const [stats, setStats] = useState({ tasks: 0, notes: 0, reminders: 0 });

  useEffect(() => {
    if (!user?.id) return;

    api.getEmployeeRecognitions(user.id).then((data) => {
      if (Array.isArray(data)) setRecognitions(data);
    }).catch(() => {});

    // Load stats
    Promise.all([
      api.getTasks().catch(() => []),
      api.getNotes().catch(() => []),
      api.getReminders().catch(() => []),
    ]).then(([tasks, notes, reminders]) => {
      setStats({
        tasks: Array.isArray(tasks) ? tasks.length : 0,
        notes: Array.isArray(notes) ? notes.length : 0,
        reminders: Array.isArray(reminders) ? reminders.length : 0,
      });
    }).catch(() => {});
  }, [user?.id]);

  if (!user) {
    return (
      <div style={{ display: "flex" }}>
        <Sidebar />
        <div style={{ padding: "2rem", marginLeft: "300px", color: "#94a3b8" }}>
          Loading profile...
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: "flex", backgroundColor: "#0f172a", minHeight: "100vh", color: "#f8fafc" }}>
      <Sidebar />
      <main style={{ flex: 1, padding: "2rem", marginLeft: "300px", maxWidth: "900px" }}>
        {/* Profile Header */}
        <div style={{ backgroundColor: "#1e293b", border: "1px solid #334155", borderRadius: "12px", padding: "2rem", marginBottom: "1.5rem" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "1.5rem", marginBottom: "1.5rem" }}>
            <div style={{
              width: "80px", height: "80px", borderRadius: "50%",
              backgroundColor: "#0f172a", display: "flex", alignItems: "center",
              justifyContent: "center", fontSize: "2rem", color: "#38bdf8",
              border: "2px solid #38bdf8"
            }}>
              {user.name?.[0]?.toUpperCase() || "U"}
            </div>
            <div>
              <h2 style={{ fontSize: "1.5rem", color: "#f1f5f9", marginBottom: "0.25rem" }}>{user.name}</h2>
              <span style={{
                fontSize: "0.75rem", fontWeight: 600, textTransform: "uppercase",
                padding: "0.2rem 0.6rem", borderRadius: "4px",
                backgroundColor: user.role === "admin" ? "rgba(245, 158, 11, 0.15)" : "rgba(56, 189, 248, 0.15)",
                color: user.role === "admin" ? "#f59e0b" : "#38bdf8",
                border: `1px solid ${user.role === "admin" ? "rgba(245, 158, 11, 0.3)" : "rgba(56, 189, 248, 0.3)"}`
              }}>
                {user.role === "admin" ? "ADMINISTRATOR" : "EMPLOYEE"}
              </span>
              <div style={{ color: "#94a3b8", fontSize: "0.9rem", marginTop: "0.25rem" }}>{user.email}</div>
            </div>
          </div>

          {/* Stats */}
          <h3 style={{ fontSize: "1rem", color: "#e2e8f0", marginBottom: "0.75rem" }}>Your Activity</h3>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(120px, 1fr))", gap: "0.75rem" }}>
            {[
              { label: "Tasks", value: stats.tasks, color: "#38bdf8" },
              { label: "Notes", value: stats.notes, color: "#10b981" },
              { label: "Reminders", value: stats.reminders, color: "#f59e0b" },
              { label: "Recognitions", value: recognitions.length, color: "#f472b6" },
            ].map((s) => (
              <div key={s.label} style={{
                backgroundColor: "#0f172a", border: "1px solid #334155",
                borderRadius: "8px", padding: "0.75rem", textAlign: "center"
              }}>
                <div style={{ fontSize: "1.5rem", fontWeight: 700, color: s.color }}>{s.value}</div>
                <div style={{ fontSize: "0.8rem", color: "#64748b", marginTop: "0.25rem" }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Recognitions */}
        <div style={{ backgroundColor: "#1e293b", border: "1px solid #334155", borderRadius: "12px", padding: "1.5rem" }}>
          <h3 style={{ fontSize: "1.1rem", fontWeight: 600, color: "#e2e8f0", marginBottom: "1rem", paddingBottom: "0.5rem", borderBottom: "1px solid #334155" }}>
            🏆 Recognitions
          </h3>
          {recognitions.length === 0 ? (
            <p style={{ color: "#64748b", fontSize: "0.9rem" }}>No recognitions yet.</p>
          ) : (
            recognitions.map((r) => (
              <div key={r._id} style={{
                display: "flex", alignItems: "center", gap: "0.5rem",
                backgroundColor: "#0f172a", border: "1px solid #334155",
                borderRadius: "8px", padding: "0.75rem 1rem", marginBottom: "0.5rem"
              }}>
                <span style={{ fontSize: "1.25rem" }}>{r.icon || RECOGNITION_ICONS[r.type] || "🏆"}</span>
                <span style={{ fontWeight: 600, color: "#f1f5f9" }}>{r.label}</span>
                {r.note && <span style={{ color: "#94a3b8", fontSize: "0.85rem", fontStyle: "italic" }}>— {r.note}</span>}
                <span style={{ color: "#475569", fontSize: "0.75rem", marginLeft: "auto" }}>
                  {r.awardedAt ? new Date(r.awardedAt).toLocaleDateString() : ""}
                </span>
              </div>
            ))
          )}
        </div>
      </main>
    </div>
  );
}