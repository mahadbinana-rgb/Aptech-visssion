import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import '../Login.css';
import '../main.css';

export default function Register() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    companyName: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const { register, user } = useAuth();
  const navigate = useNavigate();

  // Unified routing logic
  const handleRedirect = (currentUser) => {
    if (!currentUser) return;
    if (currentUser.role === 'admin') {
      navigate('/admin');
    } else {
      navigate('/');
    }
  };

  // Redirect if user is already logged in
  useEffect(() => {
    handleRedirect(user);
  }, [user, navigate]);

  // Handle single state object updates
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(false);

    // Basic client-side validation
    if (formData.password.length < 8) {
      setError('Password must be at least 8 characters long.');
      return;
    }

    try {
      setLoading(true);
      const res = await register({
        name: formData.name,
        email: formData.email,
        password: formData.password,
        companyName: formData.companyName
      });

      handleRedirect(res?.user);
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Signup failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-body">
      <div className="login-card">
        <div className="brand">
          <i className="fa-solid fa-microchip"></i> AURORA AI
        </div>
        <div className="subtitle">Create your secure workspace account</div>

        {error && <div className="error-message" style={{ color: 'red', marginBottom: '15px' }}>{error}</div>}

        <form onSubmit={submit}>
          <div className="input-group">
            <label htmlFor="name">Full Name</label>
            <div className="input-wrapper">
              <i className="fa-solid fa-user"></i>
              <input
                id="name"
                name="name"
                type="text"
                placeholder="Jane Doe"
                value={formData.name}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          <div className="input-group">
            <label htmlFor="companyName">Company Name</label>
            <div className="input-wrapper">
              <i className="fa-solid fa-building"></i>
              <input
                id="companyName"
                name="companyName"
                type="text"
                placeholder="My Company"
                value={formData.companyName}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          <div className="input-group">
            <label htmlFor="email">Corporate Email</label>
            <div className="input-wrapper">
              <i className="fa-solid fa-envelope"></i>
              <input
                id="email"
                name="email"
                type="email"
                placeholder="employee@company.local"
                value={formData.email}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          <div className="input-group">
            <label htmlFor="password">Create Password</label>
            <div className="input-wrapper">
              <i className="fa-solid fa-lock"></i>
              <input
                id="password"
                name="password"
                type="password"
                placeholder="••••••••"
                value={formData.password}
                onChange={handleChange}
                required
                minLength={8}
              />
            </div>
          </div>

          <button type="submit" className="btn-login" disabled={loading}>
            {loading ? 'Creating Account...' : 'Create Account'}
          </button>
        </form>

        <div className="footer-note">
          Already have an account? <Link to="/login">Log in</Link>
        </div>
        <div className="footer-note">
          <i className="fa-solid fa-shield-halved" style={{ color: 'var(--accent-blue)' }}></i> Secured Intranet Connection Active
        </div>
      </div>
    </div>
  );
}