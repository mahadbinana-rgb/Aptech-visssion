import React, { useEffect, useState } from "react";
import mockApi from "../services/mockApi";
import Sidebar from "../components/Sidebar";
import "../main.css";
import "../Reminder.css";

export default function ReminderPage() {
  const [reminders, setReminders] = useState([]);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    title: "",
    message: "",
    dueTime: "",
  });

  const load = async () => {
    try {
      const res = await mockApi.getReminders();
      setReminders(res || []);
    } catch (err) {
      console.error("Failed to load reminders:", err);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const create = async () => {
    setError("");

    if (!form.title.trim()) {
      setError("Title is required.");
      return;
    }

    if (!form.dueTime) {
      setError("Due date/time is required.");
      return;
    }

    try {
      await mockApi.createReminder({
        title: form.title.trim(),
        message: form.message.trim(),
        dueTime: new Date(form.dueTime).toISOString(),
      });
      setForm({ title: "", message: "", dueTime: "" });
      load();
    } catch (err) {
      const msg = err.response?.data?.message || "Failed to create reminder.";
      setError(msg);
      console.error("Create reminder error:", err);
    }
  };

  const remove = async (id) => {
    try {
      await mockApi.deleteReminder(id);
      load();
    } catch (err) {
      console.error("Failed to delete reminder:", err);
    }
  };

  return (
    <div className="reminder-layout">
      <Sidebar />
      
      <main className="reminder-container">
        <header className="reminder-header">
          <h2>Reminders Management</h2>
          <p>Create, view, and organize your active notifications.</p>
        </header>

        {/* Input Form Section */}
        <section className="reminder-form-panel">
          <h3>Create New Reminder</h3>
          {error && <div className="error-banner">{error}</div>}
          <div className="reminder-form-grid">
            <input
              type="text"
              placeholder="Title *"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
            />
            <input
              type="text"
              placeholder="Message"
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
            />
            <input
              type="datetime-local"
              min={Date.now()}
              value={form.dueTime}
              onChange={(e) => setForm({ ...form, dueTime: e.target.value })}
            />
          </div>
          <button className="btn-primary" onClick={create}>
            Create Reminder
          </button>
        </section>

        <hr className="divider" />

        {/* Reminders List Feed */}
        <section className="reminders-feed">
          <h3>Active Reminders</h3>
          {reminders.length > 0 ? (
            <div className="reminders-grid">
              {reminders.map((r) => (
                <div key={r._id} className="reminder-card">
                  <div className="card-body">
                    <h4>{r.title}</h4>
                    <p>{r.message}</p>
                    <span className="due-timestamp">
                      Due: {new Date(r.dueTime).toLocaleString()}
                    </span>
                  </div>
                  <button className="btn-danger" onClick={() => remove(r._id)}>
                    Delete
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="empty-state">No reminders set yet. 🎉</div>
          )}
        </section>
      </main>
    </div>
  );
}