import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import mockApi from '../services/mockApi';
import AdminSidebar from '../components/AdminSidebar';
import '../AuraAdmin.css';
import { useLocation } from 'react-router-dom';

export default function TaskAssighn() {
    const location = useLocation();
    const { employeeId, employeeName } = location.state || {};
    const navigate = useNavigate();

    const [Title, setTitle] = useState("");
    const [Description, setDescription] = useState("");
    const [Priority, setPriority] = useState("Medium");

    if (!employeeId) {
      alert('Missing employee target. Returning to employee directory.');
      navigate('/employees');
      return null;
    }

    const id = employeeId;
    const name = employeeName || 'Employee';

    const handleSubmit = async (e) => {
        e.preventDefault();

        const newTask = {
            title: Title,
            description: Description,
            priority: Priority,
            completed: false,
            assignedTo: id
        };

        try {
            await mockApi.createTask(newTask);
            alert("Successfully assigned a task to the employee!");
            navigate("/employees");
        } catch (error) {
            console.error("Task assignment failed:", error);
            alert("Failed to assign task. Please try again or contact support.");
        }
    };

    return (
        <div className="aura-admin-wrapper" style={{ backgroundColor: '#09090b', minHeight: '100vh', color: '#f4f4f5' }}>
            <div className="security-banner" style={{ background: '#7f1d1d', padding: '10px 24px', color: '#fca5a5', fontSize: '13px', fontWeight: 600 }}>
                <i className="fa-solid fa-triangle-exclamation"></i> Administrator Privileges Active — Proceed with Caution
            </div>

            <div style={{ display: 'flex', flex: 1 }}>
                <AdminSidebar />
                <form className="task-assighn-form" onSubmit={handleSubmit}>
                    <h4>Create New Task for Employee {name}</h4>
                    <div className="form-group">
                        <label>Title</label>
                        <input
                            type="text"
                            // value={}
                            onChange={(e) => setTitle(e.target.value)}
                            required
                            placeholder="Task title..."
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Description</label>
                        <textarea
                            // value={}
                            onChange={(e) => setDescription(e.target.value)}
                            placeholder="Task description..."
                            style={{ resize: 'none' }}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Priority</label>
                        <select onChange={(e) => setPriority(e.target.value)}>
                            <option value="Low">Low</option>
                            <option value="Medium">Medium</option>
                            <option value="High">High</option>
                        </select>
                    </div>
                    <button type="submit" className="btn-primary" style={{ padding: '10px' }}>
                        Save Task
                    </button>
                </form>
            </div>
        </div>
    );
}