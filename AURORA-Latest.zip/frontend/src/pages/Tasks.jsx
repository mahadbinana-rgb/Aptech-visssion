import React, { useEffect, useState } from 'react';
import mockApi from '../services/mockApi';
import Sidebar from '../components/Sidebar';
import '../main.css';
import '../Tasks.css';

export default function Tasks() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  // Form State
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState('Medium');

  useEffect(() => {
    let mounted = true;

    const fetchTasks = async () => {
      try {
        const t = await mockApi.getTasks();
        if (mounted) {
          setTasks(t);
        }
      } catch (error) {
        console.error('Failed to fetch tasks', error);
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    fetchTasks();

    return () => {
      mounted = false;
    };
  }, []);

  // CSV Export Function
  const exportToCSV = () => {
    if (tasks.length === 0) {
      alert("No tasks available to export!");
      return;
    }

    // 1. Define column headers
    const headers = ['Task ID', 'Title', 'Description', 'Priority', 'Status'];

    // 2. Map data rows and escape internal quotes to prevent layout breakage in Excel
    const rows = tasks.map((t) => [
      t._id || t.id || '',
      `"${(t.title || '').replace(/"/g, '""')}"`,
      `"${(t.description || '').replace(/"/g, '""')}"`,
      t.priority || 'Medium',
      t.completed ? 'Completed' : 'Pending'
    ]);

    // 3. Combine headers and rows with new lines
    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');

    // 4. Create a Blob with UTF-8 character encoding BOM for Excel compatibility
    const blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), csvContent], { 
      type: 'text/csv;charset=utf-8;' 
    });

    // 5. Generate hidden download link and click it
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `tasks_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    
    // Clean up memory
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const toggle = async (id) => {
    try {
      const stats = await mockApi.fetchDashboardStats();
      console.log(stats);

      const task = tasks.find((x) => x._id === id || x.id === id);
      if (!task) return;

      await mockApi.updateTask(id, { completed: !task.completed });

      setTasks((s) =>
        s.map((x) =>
          x._id === id || x.id === id ? { ...x, completed: !x.completed } : x
        )
      );
    } catch (error) {
      console.error('Failed to toggle task', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim()) return;

    const newTask = {
      title,
      description,
      priority,
      completed: false,
    };

    try {
      const createdTask = await mockApi.createTask(newTask);
      setTasks((s) => [...s, createdTask]);
      
      setTitle('');
      setDescription('');
      setPriority('Medium');
      setShowForm(false);
    } catch (error) {
      console.error('Failed to create task', error);
    }
  };

  if (loading) return <div className="card">Loading tasks...</div>;

  return (
    <div style={{ display: 'flex' }}>
      <Sidebar />
      <div style={{ flex: 1, padding: '20px' }} className="main-content">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 style={{ marginTop: '0' }}>Tasks</h2>
          <div style={{ display: 'flex', gap: '10px' }}>
            {/* Added Export CSV button */}
            <button 
              className="task-csv" 
              onClick={exportToCSV}
              style={{ padding: '8px 16px', cursor: 'pointer' }}
            >
              Export CSV
            </button>
            <button className="btn-primary" onClick={() => setShowForm(!showForm)}>
              {showForm ? 'Cancel' : '+ Add Task'}
            </button>
          </div>
        </div>

        {/* Task Creation Modal/Form */}
        {showForm && (
          <form className="card task-form" onSubmit={handleSubmit}>
            <h3>Create New Task</h3>
            <div className="form-group">
              <label>Title</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                placeholder="Task title..."
              />
            </div>
            <div className="form-group">
              <label>Description</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Task description..."
              />
            </div>
            <div className="form-group">
              <label>Priority</label>
              <select value={priority} onChange={(e) => setPriority(e.target.value)}>
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
              </select>
            </div>
            <button type="submit" className="btn-primary">
              Save Task
            </button>
          </form>
        )}

        {/* Task List */}
        <div className="task-list">
          {tasks.map((t) => (
            <div key={t._id || t.id} className="card task-item">
              <div className="task-info">
                <div className="task-title">{t.title}</div>
                <div className="task-desc">{t.description}</div>
              </div>
              <div className="task-actions">
                <div className={`task-priority ${t.priority.toLowerCase()}`}>
                  {t.priority}
                </div>
                <button
                  className={`task-toggle ${t.completed ? 'done' : ''}`}
                  onClick={() => toggle(t._id || t.id)}
                >
                  {t.completed ? 'Completed' : 'Mark Complete'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}