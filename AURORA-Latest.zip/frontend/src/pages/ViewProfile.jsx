import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../services/mockApi";
import { useAuth } from "../context/AuthContext";
import Sidebar from "../components/Sidebar";
import "../main.css";

const RECOGNITION_ICONS = {
  employee_of_month: "⭐",
  most_productive: "🔥",
  most_helpful: "🤝",
  best_ideas: "💡",
};

/**
 * Read-only profile view for employees to view their coworkers.
 * No edit/delete/award capabilities. Company-scoped on backend.
 */
export default function ViewProfile() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [profile, setProfile] = useState(null);
  const [recognitions, setRecognitions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const isOwnProfile = id === user?.id || id === user?._id;

  useEffect(() => {
    if (!id) return;
    setLoading(true);

    Promise.all([
      api.getUserById(id).catch(() => { setError("Could not load this profile."); return null; }),
      api.getEmployeeRecognitions(id).catch(() => []),
    ]).then(([userData, recData]) => {
      if (userData) setProfile(userData);
      if (Array.isArray(recData)) setRecognitions(recData);
      setLoading(false);
    });
  }, [id]);

  if (loading) {
    return (
      <div style={{ display: "flex", backgroundColor: "#0f172a", minHeight: "100vh" }}>
        <Sidebar />
        <div style={{ padding: "2rem", marginLeft: "300px", color: "#94a3b8" }}>Loading profile...</div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div style={{ display: "flex", backgroundColor: "#0f172a", minHeight: "100vh" }}>
        <Sidebar />
        <div style={{ padding: "2rem", marginLeft: "300px", color: "#f87171" }}>
          {error || "Profile not found."}
          <br />
          <button onClick={() => navigate("/team")} style={{ marginTop: "1rem", padding: "0.5rem 1rem", background: "#38bdf8", color: "#0f172a", border: "none", borderRadius: "6px", cursor: "pointer", fontWeight: 600 }}>
            ← Back to Team
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: "flex", backgroundColor: "#0f172a", minHeight: "100vh", color: "#f8fafc" }}>
      <Sidebar />
      <main style={{ flex: 1, padding: "2rem", marginLeft: "300px", maxWidth: "900px" }}>
        <button
          onClick={() => navigate("/team")}
          style={{ marginBottom: "1rem", padding: "0.5rem 1rem", background: "transparent", color: "#38bdf8", border: "1px solid #38bdf8", borderRadius: "6px", cursor: "pointer", fontWeight: 600 }}
        >
          ← Back to Team
        </button>

        {/* Profile Header */}
        <div style={{ backgroundColor: "#1e293b", border: "1px solid #334155", borderRadius: "12px", padding: "2rem", marginBottom: "1.5rem" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "1.5rem" }}>
            <div style={{
              width: "80px", height: "80px", borderRadius: "50%",
              backgroundColor: "#0f172a", display: "flex", alignItems: "center",
              justifyContent: "center", fontSize: "2rem",
              color: profile.role === "admin" ? "#f59e0b" : "#38bdf8",
              border: `2px solid ${profile.role === "admin" ? "#f59e0b" : "#38bdf8"}`
            }}>
              {profile.name?.[0]?.toUpperCase() || "U"}
            </div>
            <div>
              <h2 style={{ fontSize: "1.5rem", color: "#f1f5f9", marginBottom: "0.25rem" }}>
                {profile.name} {isOwnProfile && <span style={{ color: "#64748b", fontSize: "0.8rem" }}>(you)</span>}
              </h2>
              <span style={{
                fontSize: "0.75rem", fontWeight: 600, textTransform: "uppercase",
                padding: "0.2rem 0.6rem", borderRadius: "4px",
                backgroundColor: profile.role === "admin" ? "rgba(245, 158, 11, 0.15)" : "rgba(56, 189, 248, 0.15)",
                color: profile.role === "admin" ? "#f59e0b" : "#38bdf8",
              }}>
                {profile.role === "admin" ? "ADMINISTRATOR" : "EMPLOYEE"}
              </span>
              <div style={{ color: "#94a3b8", fontSize: "0.9rem", marginTop: "0.25rem" }}>{profile.email}</div>
              <div style={{ color: "#475569", fontSize: "0.8rem", marginTop: "0.25rem" }}>
                Joined: {profile.createdAt ? new Date(profile.createdAt).toLocaleDateString() : "N/A"}
              </div>
            </div>
          </div>
        </div>

        {/* Recognitions (read-only) */}
        <div style={{ backgroundColor: "#1e293b", border: "1px solid #334155", borderRadius: "12px", padding: "1.5rem" }}>
          <h3 style={{ fontSize: "1.1rem", fontWeight: 600, color: "#e2e8f0", marginBottom: "1rem", paddingBottom: "0.5rem", borderBottom: "1px solid #334155" }}>
            🏆 Recognitions
          </h3>
          {recognitions.length === 0 ? (
            <p style={{ color: "#64748b", fontSize: "0.9rem" }}>No recognitions yet.</p>
          ) : (
            recognitions.map((r) => (
              <div key={r._id} style={{
                display: "flex", alignItems: "center", gap: "0.5rem",
                backgroundColor: "#0f172a", border: "1px solid #334155",
                borderRadius: "8px", padding: "0.75rem 1rem", marginBottom: "0.5rem"
              }}>
                <span style={{ fontSize: "1.25rem" }}>{r.icon || RECOGNITION_ICONS[r.type] || "🏆"}</span>
                <span style={{ fontWeight: 600, color: "#f1f5f9" }}>{r.label}</span>
                {r.note && <span style={{ color: "#94a3b8", fontSize: "0.85rem", fontStyle: "italic" }}>— {r.note}</span>}
                <span style={{ color: "#475569", fontSize: "0.75rem", marginLeft: "auto" }}>
                  {r.awardedAt ? new Date(r.awardedAt).toLocaleDateString() : ""}
                </span>
              </div>
            ))
          )}
        </div>
      </main>
    </div>
  );
}