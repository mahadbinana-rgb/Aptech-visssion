export const showDesktopNotification = (
  title,
  body
) => {
  if (
    window.electronAPI &&
    window.electronAPI.notify
  ) {
    window.electronAPI.notify(title, body);
  }
};