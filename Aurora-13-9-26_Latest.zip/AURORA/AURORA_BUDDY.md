# AURORA Buddy

AURORA Buddy is the small global assistant mounted on every authenticated app page.

## What it does
- Local-only Ollama chat through `POST /api/buddy/chat`.
- Role-scoped company context is assembled on the backend before the model is called.
- Employees receive personal workspace data plus projects they can already view.
- Leads receive their personal workspace data plus employee-level people visibility.
- Managers receive company operational data, excluding admin-owned records.
- Admins receive all data belonging to their own company.
- Personal reminders remain user-scoped for normal roles; admin context may include company reminders.
- CodeSpace project access is still enforced by the existing project permission system.
- CRUD actions are limited to the currently authenticated user's own tasks, notes, and reminders.
- Navigation is restricted to known AURORA routes and the user's role.
- Destructive CRUD requests are never executed against another user's records.

## UI
The launcher is a 52px circular button at the bottom-left. The chat window is 370x500px (with a 70vh mobile cap), and only the conversation area scrolls.

## Secure company-chat files
Chat files are stored on disk but are not exposed through the old public `/uploads` static route. The backend issues a two-minute company-scoped signed browser URL through `/api/chat-file/token/:filename` and serves it through `/api/chat-file/open/:token`.

Existing stored chat records using `/uploads/chat/...` continue to resolve by filename.
