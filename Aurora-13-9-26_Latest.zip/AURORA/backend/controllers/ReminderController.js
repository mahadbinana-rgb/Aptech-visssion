const Reminder = require("../models/Reminder");

// CREATE
const createReminder = async (req, res) => {
  try {
    const reminder = await Reminder.create({
      userId: req.user.id,
      companyId: req.user.companyId,
      title: req.body.title,
      message: req.body.message,
      dueTime: req.body.dueTime,
    });
    res.status(201).json(reminder);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// GET ALL
const getReminders = async (req, res) => {
  try {
    const reminders = await Reminder.find({ userId: req.user?.id }).sort({ dueTime: 1 });
    res.json(reminders);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// DELETE
const updateReminder = async (req, res) => {
  try {
    const reminder = await Reminder.findOne({ _id: req.params.id, userId: req.user.id, companyId: req.user.companyId });
    if (!reminder) return res.status(404).json({ message: "Reminder not found" });
    for (const field of ['title', 'message', 'priority', 'completed', 'dueTime']) {
      if (req.body[field] !== undefined) reminder[field] = req.body[field];
    }
    await reminder.save();
    res.json(reminder);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const deleteReminder = async (req, res) => {
  try {
    const deleted = await Reminder.findOneAndDelete({ _id: req.params.id, userId: req.user.id, companyId: req.user.companyId });
    if (!deleted) return res.status(404).json({ message: "Reminder not found" });
    res.json({ message: "Deleted" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
const getDueReminders = async (
  req,
  res
) => {
  try {
    const reminders = await Reminder.find({
      userId: req.user.id,
      companyId: req.user.companyId,
      sent: true,
      notified: { $ne: true }
    });

    res.json(reminders);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
const markReminderNotified =
  async (req, res) => {

  const reminder = await Reminder.findOneAndUpdate(
    { _id: req.params.id, userId: req.user.id, companyId: req.user.companyId },
    { notified: true },
    { new: true }
  );
  if (!reminder) return res.status(404).json({ message: 'Reminder not found' });

  res.json({
    success: true
  });
};

module.exports = {
  createReminder,
  getReminders,
  deleteReminder,
  updateReminder,
  getDueReminders,
  markReminderNotified
};