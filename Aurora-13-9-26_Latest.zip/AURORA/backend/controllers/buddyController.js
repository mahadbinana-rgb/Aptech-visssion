const Task = require('../models/Task');
const Note = require('../models/Note');
const Reminder = require('../models/Reminder');
const { logActivity } = require('../services/activityService');
const {
  buildVisibleContext,
  callBuddyModel,
  ACTIONS,
  navigationAllowed,
} = require('../services/buddyService');

const same = (a, b) => String(a) === String(b);

const applyAction = async (action, req) => {
  if (!action || !ACTIONS.has(action.type)) return { executed: false, reason: 'No supported action was requested.' };
  const data = action.data && typeof action.data === 'object' ? action.data : {};
  const userId = req.user._id;
  const companyId = req.user.companyId;

  const taskOwned = async (targetId) => Task.findOne({ _id: targetId, companyId, assignedTo: userId });
  const noteOwned = async (targetId) => Note.findOne({ _id: targetId, userId });
  const reminderOwned = async (targetId) => Reminder.findOne({ _id: targetId, companyId, userId });

  if (action.type === 'create_task') {
    if (!String(data.title || '').trim()) return { executed: false, reason: 'A task title is required.' };
    const task = await Task.create({
      title: String(data.title).trim(),
      description: String(data.description || ''),
      priority: ['High', 'Medium', 'Low'].includes(data.priority) ? data.priority : 'Medium',
      completed: Boolean(data.completed),
      assignedTo: userId,
      companyId,
    });
    await logActivity({ userId, companyId, io: req.app.get('io'), action: `${req.user.name} created a task through AURORA Buddy: ${task.title}` });
    return { executed: true, type: action.type, id: String(task._id), summary: `Created task "${task.title}".` };
  }

  if (action.type === 'update_task' || action.type === 'delete_task') {
    const task = await taskOwned(data.id);
    if (!task) return { executed: false, reason: 'That task is not one of your current tasks.' };
    if (action.type === 'delete_task') {
      await task.deleteOne();
      await logActivity({ userId, companyId, io: req.app.get('io'), action: `${req.user.name} deleted a task through AURORA Buddy: ${task.title}` });
      return { executed: true, type: action.type, id: String(task._id), summary: `Deleted task "${task.title}".` };
    }
    for (const field of ['title', 'description', 'priority', 'completed']) {
      if (data[field] !== undefined) {
        if (field === 'priority' && !['High', 'Medium', 'Low'].includes(data[field])) continue;
        task[field] = field === 'title' ? String(data[field]).trim() : data[field];
      }
    }
    await task.save();
    return { executed: true, type: action.type, id: String(task._id), summary: `Updated task "${task.title}".` };
  }

  if (action.type === 'create_note') {
    if (!String(data.title || '').trim()) return { executed: false, reason: 'A note title is required.' };
    const note = await Note.create({ title: String(data.title).trim(), content: String(data.content || ''), userId });
    return { executed: true, type: action.type, id: String(note._id), summary: `Created note "${note.title}".` };
  }

  if (action.type === 'update_note' || action.type === 'delete_note') {
    const note = await noteOwned(data.id);
    if (!note) return { executed: false, reason: 'That note is not one of your notes.' };
    if (action.type === 'delete_note') {
      await note.deleteOne();
      return { executed: true, type: action.type, id: String(note._id), summary: `Deleted note "${note.title}".` };
    }
    if (data.title !== undefined) note.title = String(data.title).trim();
    if (data.content !== undefined) note.content = String(data.content);
    await note.save();
    return { executed: true, type: action.type, id: String(note._id), summary: `Updated note "${note.title}".` };
  }

  if (action.type === 'create_reminder') {
    const due = new Date(data.dueTime);
    if (!String(data.title || '').trim()) return { executed: false, reason: 'A reminder title is required.' };
    if (Number.isNaN(due.getTime())) return { executed: false, reason: 'The reminder due time is invalid.' };
    const reminder = await Reminder.create({
      companyId,
      userId,
      title: String(data.title).trim(),
      message: String(data.message || ''),
      dueTime: due,
      priority: ['low', 'medium', 'high'].includes(data.priority) ? data.priority : 'medium',
      completed: Boolean(data.completed),
    });
    return { executed: true, type: action.type, id: String(reminder._id), summary: `Created reminder "${reminder.title}" for ${reminder.dueTime.toLocaleString()}.` };
  }

  if (action.type === 'update_reminder' || action.type === 'delete_reminder') {
    const reminder = await reminderOwned(data.id);
    if (!reminder) return { executed: false, reason: 'That reminder is not one of your reminders.' };
    if (action.type === 'delete_reminder') {
      await reminder.deleteOne();
      return { executed: true, type: action.type, id: String(reminder._id), summary: `Deleted reminder "${reminder.title}".` };
    }
    for (const field of ['title', 'message', 'priority', 'completed']) {
      if (data[field] !== undefined) {
        if (field === 'priority' && !['low', 'medium', 'high'].includes(data[field])) continue;
        reminder[field] = field === 'title' ? String(data[field]).trim() : data[field];
      }
    }
    if (data.dueTime !== undefined) {
      const due = new Date(data.dueTime);
      if (!Number.isNaN(due.getTime())) reminder.dueTime = due;
    }
    await reminder.save();
    return { executed: true, type: action.type, id: String(reminder._id), summary: `Updated reminder "${reminder.title}".` };
  }

  return { executed: false, reason: 'Unsupported action.' };
};

const buddyChat = async (req, res, next) => {
  try {
    const { message, history = [], clientTimezone = 'UTC' } = req.body;
    if (!message || typeof message !== 'string' || !message.trim()) {
      return res.status(400).json({ success: false, message: 'A message is required.' });
    }

    const context = await buildVisibleContext(req.user, { clientTimezone });
    const result = await callBuddyModel({ context, message: message.trim(), history });

    let navigation = null;
    if (result.navigate?.path && navigationAllowed(req.user, result.navigate.path)) {
      navigation = { path: result.navigate.path, label: result.navigate.label || undefined };
    }

    let actionResult = null;
    if (result.action) {
      try {
        actionResult = await applyAction(result.action, req);
      } catch (actionError) {
        console.error('[AURORA Buddy] Action failed:', actionError);
        actionResult = { executed: false, reason: 'The requested action could not be completed safely.' };
      }
    }

    let response = result.message;
    if (result.action && actionResult) {
      response = actionResult.executed
        ? `${response}\n\n✓ ${actionResult.summary}`
        : `${response}\n\nI did not change anything: ${actionResult.reason}`;
    }

    return res.status(200).json({
      success: true,
      response,
      navigation,
      action: actionResult,
      roleScope: context.access.scope,
    });
  } catch (error) {
    console.error('[AURORA Buddy] Error:', error);
    next(error);
  }
};

module.exports = { buddyChat };
