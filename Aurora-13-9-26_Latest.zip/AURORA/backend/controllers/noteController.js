const Note = require('../models/Note');

const getNotes = async (req, res, next) => {
  try {
    const companyUsers = await require('../models/User').find({ companyId: req.user.companyId }).select('_id');
    const companyUserIds = companyUsers.map((u) => u._id);
    const query = ['admin', 'manager'].includes(req.user.role) ? { userId: { $in: companyUserIds } } : { userId: req.user.id };
    const notes = await Note.find(query).populate('userId', 'name email');
    res.json(notes);
  } catch (error) {
    next(error);
  }
};

const createNote = async (req, res, next) => {
  try {
    const { title, content } = req.body;
    const note = await Note.create({
      title,
      content,
      userId: req.user.id,
    });
    res.status(201).json(note);
  } catch (error) {
    next(error);
  }
};

const updateNote = async (req, res, next) => {
  try {
    const note = await Note.findById(req.params.id);
    if (!note) return res.status(404).json({ message: 'Note not found' });
    const owner = await require('../models/User').findById(note.userId).select('companyId');
    if (!owner || String(owner.companyId) !== String(req.user.companyId)) return res.status(403).json({ message: 'Not authorized for this company' });
    if (req.user.role !== 'admin' && note.userId.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Not authorized to update this note' });
    }

    if (req.body.title !== undefined) note.title = String(req.body.title).trim();
    if (req.body.content !== undefined) note.content = String(req.body.content);
    await note.save();
    res.json(note);
  } catch (error) {
    next(error);
  }
};

const deleteNote = async (req, res, next) => {
  try {
    const note = await Note.findById(req.params.id);
    if (!note) return res.status(404).json({ message: 'Note not found' });
    const owner = await require('../models/User').findById(note.userId).select('companyId');
    if (!owner || String(owner.companyId) !== String(req.user.companyId)) return res.status(403).json({ message: 'Not authorized for this company' });
    if (req.user.role !== 'admin' && note.userId.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Not authorized to delete this note' });
    }

    await Note.findByIdAndDelete(req.params.id);
    res.json({ message: 'Note removed' });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getNotes,
  createNote,
  updateNote,
  deleteNote,
};
