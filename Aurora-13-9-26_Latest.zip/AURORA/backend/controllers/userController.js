const User = require('../models/User');
const bcrypt = require('bcryptjs');

const getUsers = async (req, res, next) => {
  try {
    const users = await User.find({
      companyId: req.user.companyId
    }).select('-password').sort({ createdAt: -1 });
    res.json(users);
  } catch (error) {
    next(error);
  }
};
const getUserById = async (req, res, next) => {
  try {
    const targetUser = await User.findById(req.params.id).select('-password');
    if (!targetUser) return res.status(404).json({ message: 'User not found' });

    const currentUser = req.user;

    // Security rules:
    // 1. Employees can only see their own profile
    // 2. Admins can see any profile within their own company
    if (!['admin', 'manager', 'lead'].includes(currentUser.role) && String(currentUser.id) !== String(targetUser.id)) {
      return res.status(403).json({ message: 'Access denied' });
    }

    // Admin cross-company check
    if (['admin', 'manager', 'lead'].includes(currentUser.role) && 
        targetUser.companyId.toString() !== currentUser.companyId.toString()) {
      return res.status(403).json({ message: 'Access denied: different company' });
    }

    res.json(targetUser);
  } catch (error) {
    next(error);
  }
};

// GET own profile shortcut
const getMyProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json(user);
  } catch (error) {
    next(error);
  }
};

const deleteUser = async (req, res, next) => {
  try {
    const target = await User.findById(req.params.id).select('_id companyId role');
    if (!target) return res.status(404).json({ message: 'User not found' });
    if (String(target.companyId) !== String(req.user.companyId)) return res.status(403).json({ message: 'Cannot manage another company' });
    if (String(target._id) === String(req.user._id)) return res.status(400).json({ message: 'You cannot delete your own account here' });
    if (req.user.role !== 'admin' && ['admin', 'manager'].includes(target.role)) {
      return res.status(403).json({ message: 'Managers cannot remove administrators or other managers' });
    }
    await target.deleteOne();
    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    console.error('Delete user error:', error);
    next(error);
  }
};
const provisionEmployee = async (req, res) => {

  if (!['admin', 'manager'].includes(req.user.role)) {
    return res.status(403).json({
      message: 'Admin access required'
    });
  }

  const { name, email, password, role = 'employee' } = req.body;

  const hashedPassword = await bcrypt.hash(password, 10);

  const employee = await User.create({
    name,
    email,
    password: hashedPassword,
    role: ['manager', 'lead', 'employee'].includes(role) && req.user.role !== 'manager' ? role : (req.user.role === 'manager' && role === 'manager' ? 'lead' : 'employee'),

    companyId: req.user.companyId
  });

  res.json(employee);
}

module.exports = {
  getUsers,
  getUserById,
  getMyProfile,
  deleteUser,
  provisionEmployee
};