const mongoose = require("mongoose");

const companyMessageSchema = new mongoose.Schema({
  companyId: { type: String, required: true },
  roomId: { type: String, default: "general" },

  senderId: { type: String, required: true },
  senderName: { type: String, required: true },
  role: { type: String, enum: ["admin", "manager", "lead", "employee"], default: "employee" },

  message: { type: String, required: true },

  // FORCE Mongoose to recognize this strictly as an Object
  file: {
    url: String,
    name: String,
    fileType: String, // Changed from type to fileType
    size: Number
  }
}, { timestamps: true });

module.exports = mongoose.model("CompanyMessage", companyMessageSchema);