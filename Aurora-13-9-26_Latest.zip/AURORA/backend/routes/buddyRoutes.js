const express = require('express');
const { protect } = require('../middleware/authMiddleware');
const { buddyChat } = require('../controllers/buddyController');

const router = express.Router();
router.post('/chat', protect, buddyChat);

module.exports = router;
