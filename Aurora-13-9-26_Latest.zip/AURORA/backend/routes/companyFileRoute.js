const express = require('express');
const fs = require('fs');
const path = require('path');
const jwt = require('jsonwebtoken');
const CompanyMessage = require('../models/CompanyMessage');
const { protect } = require('../middleware/authMiddleware');

const router = express.Router();
const secret = () => process.env.JWT_SECRET || 'supersecretjwt';

const findCompanyFile = async (filename, companyId) => {
  const safeName = path.basename(filename);
  const expectedUrls = [`/chat-file/${safeName}`, `/uploads/chat/${safeName}`];
  const message = await CompanyMessage.findOne({
    'file.url': { $in: expectedUrls },
    companyId: String(companyId),
  }).select('file companyId');
  return { safeName, message };
};

// Create a short-lived browser-safe URL after authenticating the user.
router.get('/token/:filename', protect, async (req, res) => {
  try {
    const { safeName, message } = await findCompanyFile(req.params.filename, req.user.companyId);
    if (!message?.file?.url) return res.status(404).json({ message: 'File not found' });

    const token = jwt.sign(
      { kind: 'aura-chat-file', filename: safeName, companyId: String(req.user.companyId) },
      secret(),
      { expiresIn: '2m' }
    );

    return res.json({
      url: `/api/chat-file/open/${token}`,
      name: message.file.name || safeName,
      fileType: message.file.fileType || 'application/octet-stream',
    });
  } catch (err) {
    console.error('[Chat File Token] Error:', err);
    return res.status(500).json({ message: 'Unable to prepare file access' });
  }
});

// Short-lived signed URL endpoint. It is not publicly enumerable and is
// restricted to the same company encoded into the token.
router.get('/open/:token', async (req, res) => {
  try {
    const decoded = jwt.verify(req.params.token, secret());
    if (decoded.kind !== 'aura-chat-file' || !decoded.filename || !decoded.companyId) {
      return res.status(403).json({ message: 'Invalid file token' });
    }

    const { safeName, message } = await findCompanyFile(decoded.filename, decoded.companyId);
    if (!message?.file?.url) return res.status(404).json({ message: 'File not found' });

    const absolute = path.join(process.cwd(), 'uploads', 'chat', safeName);
    if (!fs.existsSync(absolute)) return res.status(404).json({ message: 'File not found on disk' });

    const originalName = String(message.file.name || safeName).replace(/[\r\n"]/g, '_');
    const contentType = message.file.fileType || 'application/octet-stream';
    const disposition = req.query.download === '1' ? 'attachment' : 'inline';
    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', `${disposition}; filename="${encodeURIComponent(originalName)}"`);
    return res.sendFile(absolute);
  } catch (err) {
    if (err.name === 'TokenExpiredError' || err.name === 'JsonWebTokenError') {
      return res.status(403).json({ message: 'File link expired. Please open it again from the chat.' });
    }
    console.error('[Chat File Open] Error:', err);
    return res.status(500).json({ message: 'Unable to load file' });
  }
});

module.exports = router;
