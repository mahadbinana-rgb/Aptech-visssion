const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");

const {
  createReminder,
  getReminders,
  deleteReminder,
  updateReminder,
  getDueReminders,
  markReminderNotified
} = require("../controllers/ReminderController");

router.post("/", protect, createReminder);
router.get("/", protect, getReminders);
router.get("/due", protect, getDueReminders);
router.route("/:id").put(protect, updateReminder).delete(protect, deleteReminder);
router.put("/:id/notified", protect, markReminderNotified);
router.get("/due-system", protect, getDueReminders);

module.exports = router;