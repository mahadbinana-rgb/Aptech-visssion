const User = require('../models/User');
const Task = require('../models/Task');
const Note = require('../models/Note');
const Reminder = require('../models/Reminder');
const Project = require('../models/Project');
const Activity = require('../models/Activity');
const AiLog = require('../models/AiLog');
const Recognition = require('../models/Recognition');
const CompanyMessage = require('../models/CompanyMessage');
const ChatChannel = require('../models/ChatChannel');
const Company = require('../models/Company');
const { hasRoleLevel } = require('../middleware/roleMiddleware');
const { canViewProject, permissionFor } = require('./projectAccessService');
const aiService = require('./aiService');

const MAX = {
  users: 60,
  tasks: 70,
  notes: 50,
  reminders: 30,
  projects: 25,
  activities: 50,
  aiLogs: 40,
  recognitions: 40,
  messages: 60,
  channels: 30,
};

const clean = (value, max = 5000) => String(value ?? '').slice(0, max);
const id = (value) => String(value);

const taskView = (task) => ({
  id: id(task._id),
  title: clean(task.title, 160),
  description: clean(task.description, 700),
  priority: task.priority,
  completed: task.completed,
  assignedTo: task.assignedTo?.name || id(task.assignedTo),
  assignedToId: task.assignedTo?._id ? id(task.assignedTo._id) : id(task.assignedTo),
  createdAt: task.createdAt,
});

const noteView = (note) => ({
  id: id(note._id),
  title: clean(note.title, 180),
  content: clean(note.content, 1000),
  owner: note.userId?.name || id(note.userId),
  ownerId: note.userId?._id ? id(note.userId._id) : id(note.userId),
  createdAt: note.createdAt,
});

const reminderView = (reminder) => ({
  id: id(reminder._id),
  title: clean(reminder.title, 180),
  message: clean(reminder.message, 1200),
  dueTime: reminder.dueTime,
  priority: reminder.priority,
  completed: reminder.completed,
});

const projectView = (project, permission) => ({
  id: id(project._id),
  name: clean(project.name, 160),
  description: clean(project.description, 1400),
  kind: project.kind,
  status: project.status,
  ownerId: id(project.ownerId),
  fileCount: project.files?.length || 0,
  files: (project.files || []).slice(0, 5).map((file) => ({
    path: clean(file.path, 300),
    language: clean(file.language, 60),
    // A small source preview helps the buddy answer project questions without
    // dumping entire codebases into the local model context.
    preview: clean(file.content, 350),
  })),
  permission,
  updatedAt: project.updatedAt,
});

const userView = (user) => ({
  id: id(user._id),
  name: clean(user.name, 120),
  email: clean(user.email, 180),
  role: user.role,
  createdAt: user.createdAt,
});

const buildVisibleContext = async (user, runtime = {}) => {
  const company = await Company.findById(user.companyId).select('name');
  const companyUsers = await User.find({ companyId: user.companyId }).select('_id name email role createdAt').sort({ createdAt: 1 }).limit(MAX.users);
  const isAdmin = user.role === 'admin';
  const elevatedData = hasRoleLevel(user, 'manager');
  const leadData = hasRoleLevel(user, 'lead');
  const managerVisibleUsers = companyUsers.filter((entry) => entry.role !== 'admin');
  const leadVisibleUsers = companyUsers.filter((entry) => entry.role === 'employee' || id(entry._id) === id(user._id));

  let [ownTasks, ownNotes, ownReminders, visibleProjects, channels, recentMessages] = await Promise.all([
    Task.find({ companyId: user.companyId, assignedTo: user._id }).populate('assignedTo', 'name email role').sort({ createdAt: -1 }).limit(MAX.tasks),
    Note.find({ userId: user._id }).populate('userId', 'name email role').sort({ createdAt: -1 }).limit(MAX.notes),
    Reminder.find({ companyId: user.companyId, userId: user._id }).sort({ dueTime: 1 }).limit(MAX.reminders),
    Project.find({
      $or: [
        { ownerId: user._id },
        { companyId: user.companyId, kind: 'company' },
      ],
    }).sort({ updatedAt: -1 }).limit(MAX.projects),
    ChatChannel.find({ companyId: user.companyId }).sort({ createdAt: 1 }).limit(MAX.channels),
    CompanyMessage.find({ companyId: id(user.companyId) }).sort({ createdAt: -1 }).limit(MAX.messages),
  ]);

  const allowedProjects = visibleProjects
    .filter((project) => canViewProject(project, user))
    .map((project) => projectView(project, permissionFor(project, user)));

  let tasks = ownTasks;
  let notes = ownNotes;
  let activities = [];
  let aiLogs = [];
  let recognitions = [];

  if (elevatedData) {
    const operationalUserIds = (isAdmin ? companyUsers : managerVisibleUsers).map((entry) => entry._id);
    [tasks, notes, activities, aiLogs, recognitions] = await Promise.all([
      Task.find(isAdmin ? { companyId: user.companyId } : { companyId: user.companyId, assignedTo: { $in: operationalUserIds } }).populate('assignedTo', 'name email role').sort({ createdAt: -1 }).limit(MAX.tasks),
      // Notes historically did not have a companyId field. Scope them through
      // company-owned users so old notes remain usable without cross-company leakage.
      Note.find({ userId: { $in: operationalUserIds } }).populate('userId', 'name email role').sort({ createdAt: -1 }).limit(MAX.notes),
      Activity.find(isAdmin ? { companyId: user.companyId } : { companyId: user.companyId, userId: { $in: operationalUserIds } }).populate('userId', 'name email role').sort({ timestamp: -1 }).limit(MAX.activities),
      AiLog.find(isAdmin ? { companyId: user.companyId } : { companyId: user.companyId, userId: { $in: operationalUserIds } }).populate('userId', 'name email role').sort({ createdAt: -1 }).limit(MAX.aiLogs),
      Recognition.find({ companyId: user.companyId }).populate('employeeId', 'name email role').populate('awardedBy', 'name role').sort({ awardedAt: -1 }).limit(MAX.recognitions),
    ]);

    const reminderQuery = isAdmin
      ? { companyId: user.companyId }
      : { companyId: user.companyId, userId: { $in: operationalUserIds } };
    ownReminders = await Reminder.find(reminderQuery).sort({ dueTime: 1 }).limit(MAX.reminders);
  } else if (leadData) {
    // Leads can use the company people directory, but not company-wide private
    // task/note history. Their own records remain available for actions.
    activities = await Activity.find({ userId: user._id, companyId: user.companyId }).sort({ timestamp: -1 }).limit(MAX.activities);
    aiLogs = await AiLog.find({ userId: user._id, companyId: user.companyId }).sort({ createdAt: -1 }).limit(MAX.aiLogs);
  } else {
    activities = await Activity.find({ userId: user._id, companyId: user.companyId }).sort({ timestamp: -1 }).limit(MAX.activities);
    aiLogs = await AiLog.find({ userId: user._id, companyId: user.companyId }).sort({ createdAt: -1 }).limit(MAX.aiLogs);
  }

  return {
    access: {
      role: user.role,
      scope: isAdmin
        ? 'admin_company_all'
        : elevatedData
          ? 'manager_company_operations'
          : leadData
            ? 'lead_company_people_plus_personal'
            : 'employee_personal_plus_visible_company_projects',
      companyId: id(user.companyId),
    },
    company: {
      id: id(company?._id || user.companyId),
      name: company?.name || '',
      memberCount: companyUsers.length,
      channels: channels.map((channel) => ({ id: id(channel._id), name: channel.name, description: clean(channel.description, 300) })),
      recentChat: recentMessages.reverse().map((message) => ({
        id: id(message._id),
        roomId: message.roomId,
        sender: message.senderName,
        role: message.role,
        message: clean(message.message, 800),
        hasFile: Boolean(message.file?.url),
        createdAt: message.createdAt,
      })),
    },
    runtime: { serverNow: new Date().toISOString(), clientTimezone: runtime.clientTimezone || 'UTC' },
    currentUser: userView(user),
    people: isAdmin ? companyUsers.map(userView) : elevatedData ? managerVisibleUsers.map(userView) : leadData ? leadVisibleUsers.map(userView) : [userView(user)],
    tasks: tasks.map(taskView),
    notes: notes.map(noteView),
    reminders: ownReminders.map(reminderView),
    projects: allowedProjects,
    activities: activities.map((activity) => ({
      id: id(activity._id),
      action: clean(activity.action, 900),
      user: activity.userId?.name || id(activity.userId),
      timestamp: activity.timestamp,
    })),
    aiLogs: aiLogs.map((log) => ({
      id: id(log._id),
      user: log.userId?.name || id(log.userId),
      toolType: log.toolType,
      prompt: clean(log.prompt, 700),
      response: clean(log.response, 900),
      createdAt: log.createdAt,
    })),
    recognitions: recognitions.map((recognition) => ({
      id: id(recognition._id),
      employee: recognition.employeeId?.name || id(recognition.employeeId),
      type: recognition.label || recognition.type,
      note: clean(recognition.note, 700),
      awardedBy: recognition.awardedBy?.name || id(recognition.awardedBy),
      awardedAt: recognition.awardedAt,
    })),
  };
};

const NAVIGATION = {
  '/': 'Dashboard',
  '/tasks': 'Tasks',
  '/notes': 'Notes',
  '/codespace': 'CodeSpace',
  '/ai': 'AI Hub',
  '/reminders': 'Reminders',
  '/message': 'Company Chat',
  '/activities': 'Activity',
  '/profile': 'Profile',
  '/aiGen': 'AI Generator',
  '/aiCode': 'AI Code Fixer',
  '/taskAssighn': 'Task Assignment',
  '/admin': 'Management',
  '/employees': 'People',
  '/ailogs': 'AI Audit',
  '/adminchat': 'Secure Company Chat',
};

const navigationAllowed = (user, path) => {
  if (!NAVIGATION[path]) return false;
  if (['/admin', '/ailogs', '/adminchat', '/taskAssighn'].includes(path) && !hasRoleLevel(user, 'manager')) return false;
  if (path === '/employees' && !hasRoleLevel(user, 'lead')) return false;
  return true;
};

const ACTIONS = new Set([
  'create_task', 'update_task', 'delete_task',
  'create_note', 'update_note', 'delete_note',
  'create_reminder', 'update_reminder', 'delete_reminder',
]);

const systemPrompt = (context) => `You are AURORA Buddy, the local offline assistant inside the AURORA private workspace.
You are running against the company's local Ollama model. Never claim to have web access, cloud access, or hidden data.
The DATA CONTEXT below is the complete set of data you are permitted to see for this user. Treat it as a hard security boundary.
Never reveal, infer, or fabricate data outside this context. Never reveal passwords or secrets.
The user's role controls the context you received: employee data is personal/visible-project scoped; lead data adds people; manager data adds company operational data; admin data covers all data in that user's company.
You may answer general knowledge questions from your model knowledge too, but clearly distinguish them from workspace facts.
You can request navigation and perform CRUD actions only on the CURRENT user's own tasks, notes, and reminders.
For destructive actions, only act when the user clearly requested it. For edits/deletes, use IDs from the supplied context; never invent an ID.
For navigation, choose only an exact path from the allowed navigation list.
Always return ONLY valid JSON, no markdown fences, with this exact shape:
{
  "message": "natural-language answer for the user",
  "navigate": {"path":"/tasks"} | null,
  "action": {"type":"create_task|update_task|delete_task|create_note|update_note|delete_note|create_reminder|update_reminder|delete_reminder", "data":{}} | null
}
Rules for action data:
- create_task: title, description, priority, completed(optional)
- update_task: id plus only fields that change (title, description, priority, completed)
- delete_task: id
- create_note: title, content
- update_note: id plus title and/or content
- delete_note: id
- create_reminder: title, message, dueTime (ISO date/time), priority(optional), completed(optional)
- update_reminder: id plus title/message/dueTime/priority/completed as needed
- delete_reminder: id
Do not place actions inside message. Do not output more than one action in a response.
Allowed navigation paths: ${Object.entries(NAVIGATION).map(([path, label]) => `${path}=${label}`).join(', ')}

DATA CONTEXT:
${JSON.stringify(context, null, 2)}`;

const callBuddyModel = async ({ context, message, history = [] }) => {
  const safeHistory = Array.isArray(history)
    ? history.slice(-10).map((entry) => ({ role: entry.role === 'assistant' ? 'assistant' : 'user', content: clean(entry.content, 1800) }))
    : [];
  const prompt = `${systemPrompt(context)}\n\nCONVERSATION HISTORY:\n${JSON.stringify(safeHistory)}\n\nCURRENT USER MESSAGE:\n${clean(message, 5000)}\n\nReturn JSON now:`;
  const raw = await aiService.callOllama(prompt);
  const withoutThinking = String(raw || '').replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
  const fenced = withoutThinking.replace(/^```(?:json)?\s*/i, '').replace(/```$/i, '').trim();
  const start = fenced.indexOf('{');
  const end = fenced.lastIndexOf('}');
  const cleaned = start >= 0 && end > start ? fenced.slice(start, end + 1) : fenced;
  try {
    const parsed = JSON.parse(cleaned);
    return {
      message: clean(parsed.message || 'I could not produce a response.', 6000),
      navigate: parsed.navigate && typeof parsed.navigate === 'object' ? parsed.navigate : null,
      action: parsed.action && typeof parsed.action === 'object' ? parsed.action : null,
    };
  } catch {
    return { message: String(raw || '').trim() || 'I could not produce a response.', navigate: null, action: null };
  }
};

module.exports = {
  buildVisibleContext,
  callBuddyModel,
  ACTIONS,
  NAVIGATION,
  navigationAllowed,
};
