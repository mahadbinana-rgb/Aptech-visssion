import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import Sidebar from './components/Sidebar';
import Tasks from './pages/Tasks';
import Notes from './pages/Notes';
import Employees from './pages/Employees';
import AILogs from './pages/AILogs';
import Login from './pages/Login';
import Register from './pages/Register';
import Profile from './pages/Profile';
import NotFound from './pages/NotFound';
import AuraAdmin from './pages/AdminDashboard';
import ProtectedRoute from './components/ProtectedRoute';
import AiLogsEmp from './pages/AILogsEmp';
import AIGenerator from './pages/AIGenerator';
import AICodeFixer from './pages/AICodeFixer';
import Reminders from './pages/Reminders';
import CompanyChat from './pages/CompanyChat';
import AdminChat from './pages/AdminChat';
import EmployeeProfile from './pages/EmployeeProfile';
import ActivityFeed from './components/ActivityFeed';
import TaskAssighn from './pages/taskAssighn';
import Activity from './pages/Activity';
import CodeSpace from './pages/CodeSpace';
import AuraBuddy from './components/AuraBuddy';
import { useAuth } from './context/AuthContext';

const App = () => {
  const { user } = useAuth();

  return (
    <div className="app-layout" style={{ display: 'flex', minHeight: '100vh' }}>
      <div className="flex-1" style={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
        <div style={{ padding: '0', flex: 1 }}>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            <Route path="/" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
            <Route path="/tasks" element={<ProtectedRoute><Tasks /></ProtectedRoute>} />
            <Route path="/activities" element={<ProtectedRoute><Activity /></ProtectedRoute>} />
            <Route path="/codespace" element={<ProtectedRoute><CodeSpace /></ProtectedRoute>} />
            <Route path="/notes" element={<ProtectedRoute><Notes /></ProtectedRoute>} />
            <Route path="/ai" element={<ProtectedRoute><AiLogsEmp /></ProtectedRoute>} />
            <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
            <Route path="/aiGen" element={<ProtectedRoute><AIGenerator /></ProtectedRoute>} />
            <Route path="/aiCode" element={<ProtectedRoute><AICodeFixer /></ProtectedRoute>} />
            <Route path="/message" element={<ProtectedRoute><CompanyChat /></ProtectedRoute>} />
            <Route
              path="/taskAssighn"
              element={
                <ProtectedRoute minRole="manager">
                  <TaskAssighn />
                </ProtectedRoute>
              }
            />
            <Route path="/admin" element={<ProtectedRoute minRole="manager"><AuraAdmin /></ProtectedRoute>} />
            <Route path="/employees" element={<ProtectedRoute minRole="lead"><Employees /></ProtectedRoute>} />
            <Route path="/ailogs" element={<ProtectedRoute minRole="manager"><AILogs /></ProtectedRoute>} />
            <Route path="/adminchat" element={<ProtectedRoute minRole="manager"><AdminChat /></ProtectedRoute>} />
            <Route path="/employee-profile/:id" element={<ProtectedRoute minRole="lead"><EmployeeProfile /></ProtectedRoute>} />
            <Route path="/reminders" element={<ProtectedRoute><Reminders /></ProtectedRoute>} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </div>
      </div>
      {user && <AuraBuddy />}
    </div>
  );
};

export default App;
