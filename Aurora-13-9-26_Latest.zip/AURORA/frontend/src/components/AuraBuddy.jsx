import { useEffect, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../services/mockApi';
import './AuraBuddy.css';

const WELCOME = {
  employee: "Hi! I’m your AURORA Buddy. I can answer questions about your workspace, your tasks/notes/reminders, visible projects, and help you navigate the app. I can also make changes to your own tasks, notes, and reminders.",
  lead: "Hi! I’m your AURORA Buddy. I can answer questions using the workspace information your lead access allows, help with your own tasks/notes/reminders, and navigate AURORA for you.",
  manager: "Hi! I’m your AURORA Buddy. I can work with the company operational data available to your manager role, help with your own tasks/notes/reminders, and navigate AURORA for you.",
  admin: "Hi! I’m your AURORA Buddy. I can answer questions using the data available to you in your company, manage your own tasks/notes/reminders, and navigate AURORA for you.",
};

const QUICK = ['What do I need to work on?', 'Show my reminders', 'Take me to Notes'];

export default function AuraBuddy() {
  const { user } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const [messages, setMessages] = useState([]);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (!user) return;
    setMessages([{ role: 'assistant', content: WELCOME[user.role] || WELCOME.employee }]);
  }, [user]);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, sending]);

  if (!user || ['/login', '/register'].includes(location.pathname)) return null;

  const send = async (forcedText) => {
    const text = String(forcedText ?? input).trim();
    if (!text || sending) return;

    const nextMessages = [...messages, { role: 'user', content: text }];
    setMessages(nextMessages);
    setInput('');
    setError('');
    setSending(true);

    try {
      const data = await api.buddyChat({
        message: text,
        history: nextMessages.slice(-10),
      });

      setMessages((prev) => [...prev, { role: 'assistant', content: data.response || 'I could not produce a response.' }]);
      if (data.navigation?.path) {
        navigate(data.navigation.path);
      }
    } catch (err) {
      const message = err.response?.data?.message || 'Buddy could not reach the local AI service.';
      setError(message);
      setMessages((prev) => [...prev, { role: 'assistant', content: `I couldn’t complete that request. ${message}` }]);
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (event) => {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      send();
    }
  };

  return (
    <div className="aura-buddy-root">
      {open && (
        <section className="aura-buddy-window" aria-label="AURORA Buddy chat">
          <header className="aura-buddy-header">
            <div className="aura-buddy-heading">
              <div className="aura-buddy-mini-logo">✦</div>
              <div>
                <strong>AURORA Buddy</strong>
                <span><i /> Local · Ollama · {user.role}</span>
              </div>
            </div>
            <button className="aura-buddy-close" onClick={() => setOpen(false)} aria-label="Close AURORA Buddy">×</button>
          </header>

          <div className="aura-buddy-quick">
            {QUICK.map((item) => (
              <button key={item} onClick={() => send(item)} disabled={sending}>{item}</button>
            ))}
          </div>

          <div className="aura-buddy-messages" ref={scrollRef}>
            {messages.map((message, index) => (
              <div key={`${message.role}-${index}`} className={`aura-buddy-message ${message.role}`}>
                {message.content}
              </div>
            ))}
            {sending && <div className="aura-buddy-message assistant aura-buddy-thinking"><span /><span /><span /></div>}
          </div>

          {error && <div className="aura-buddy-error">{error}</div>}

          <div className="aura-buddy-input-row">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask Buddy anything…"
              rows={2}
              disabled={sending}
              aria-label="Message AURORA Buddy"
            />
            <button onClick={() => send()} disabled={sending || !input.trim()} aria-label="Send message">↑</button>
          </div>
        </section>
      )}

      <button
        className={`aura-buddy-launcher ${open ? 'open' : ''}`}
        onClick={() => setOpen((value) => !value)}
        aria-label={open ? 'Close AURORA Buddy' : 'Open AURORA Buddy'}
        title="AURORA Buddy"
      >
        <span className="aura-buddy-orbit" />
        <span className="aura-buddy-symbol">✦</span>
      </button>
    </div>
  );
}
