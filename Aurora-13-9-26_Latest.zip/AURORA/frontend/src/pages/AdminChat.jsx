import { useEffect, useState, useRef, useCallback } from "react";
import api from "../services/mockApi";
import { io } from "socket.io-client";
import { useAuth } from "../context/AuthContext";
import AdminSidebar from "../components/AdminSidebar";
import '../AdminChat.css';

const RAW_URL = import.meta.env.VITE_API_URL || "http://localhost:1000";
const SOCKET_URL = RAW_URL.replace(/\/api\/?$/, "");
const POLL_INTERVAL = 5000;

export default function AdminChat() {
  const { user, refreshUser } = useAuth();
  const [messages, setMessages] = useState([]);
  const [channels, setChannels] = useState([]);
  const [activeChannel, setActiveChannel] = useState(null);
  const [text, setText] = useState("");

  // New State for handling File Selection
  const [selectedFile, setSelectedFile] = useState(null);

  const [connected, setConnected] = useState(false);
  const [sending, setSending] = useState(false);
  const [statusMessage, setStatusMessage] = useState("");
  const [newChannelName, setNewChannelName] = useState("");
  const [newChannelDesc, setNewChannelDesc] = useState("");
  const [showCreateChannel, setShowCreateChannel] = useState(false);
  const [deletingMsgId, setDeletingMsgId] = useState(null);
  
  const socketRef = useRef(null);
  const pollRef = useRef(null);
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null); // Ref to clear input after sending

  const companyId = user?.companyId;
  const isAdmin = user?.role === "admin";

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Refresh user if companyId missing
  useEffect(() => {
    if (user && !user.companyId) refreshUser();
  }, [user, refreshUser]);

  // Load channels
  const loadChannels = useCallback(async () => {
    if (!companyId) return;
    try {
      const data = await api.getChannels(companyId);
      if (Array.isArray(data)) {
        setChannels(data);
        if (!activeChannel && data.length > 0) {
          setActiveChannel(data[0]);
        }
      }
    } catch (err) {
      console.error("Failed to load channels:", err);
    }
  }, [companyId, activeChannel]);

  useEffect(() => {
    if (companyId) loadChannels();
  }, [companyId, loadChannels]);

  const currentRoomId = activeChannel?._id || "general";

  const loadMessages = useCallback(async () => {
    if (!companyId || !currentRoomId) return;
    try {
      const data = await api.getCompanyMessages(companyId, currentRoomId);
      if (Array.isArray(data)) {
        setMessages((prev) => {
          if (JSON.stringify(prev) === JSON.stringify(data)) return prev;
          return data;
        });
      }
      setStatusMessage("");
    } catch (err) {
      console.error("Failed to load messages:", err);
      setStatusMessage("Could not load messages.");
    }
  }, [companyId, currentRoomId]);

  // Socket + polling + activity feed
  useEffect(() => {
    if (!companyId || !currentRoomId) return;

    loadMessages();

    const socket = io(SOCKET_URL, {
      transports: ["websocket", "polling"],
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 2000,
    });

    socketRef.current = socket;

    socket.on("connect", () => {
      setConnected(true);
      setStatusMessage("");
      socket.emit("join-company-room", { companyId, roomId: currentRoomId });
      socket.emit("join-company-feed", { companyId });
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
    });

    socket.on("disconnect", () => {
      setConnected(false);
      setStatusMessage("Reconnecting...");
      if (!pollRef.current) {
        pollRef.current = setInterval(loadMessages, POLL_INTERVAL);
      }
    });

    socket.on("connect_error", () => {
      setConnected(false);
      setStatusMessage("Cannot connect to chat server.");
    });

    socket.on("receive-company-message", (msg) => {
      if (msg.roomId === currentRoomId) {
        setMessages((prev) => {
          if (msg._id && prev.some((m) => m._id === msg._id)) return prev;
          return [...prev, msg];
        });
      }
    });

    socket.on("activity-alert", (data) => {
      alert(`🔔 ${data.action}`);
    });

    pollRef.current = setInterval(loadMessages, POLL_INTERVAL);

    return () => {
      socket.off("connect");
      socket.off("disconnect");
      socket.off("connect_error");
      socket.off("receive-company-message");
      socket.off("activity-alert");
      socket.disconnect();
      socketRef.current = null;
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
    };
  }, [companyId, currentRoomId, loadMessages]);

  useEffect(() => {
    if (socketRef.current?.connected && companyId && currentRoomId) {
      socketRef.current.emit("join-company-room", { companyId, roomId: currentRoomId });
    }
  }, [currentRoomId, companyId]);

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const sendMessage = async () => {
    if ((!text.trim() && !selectedFile) || !companyId || !user) {
      setStatusMessage("Unable to send — session incomplete or empty message.");
      return;
    }

    setSending(true);
    setStatusMessage("");

    try {
      // 1. Build FormData for Multipart API Persistence
      const formData = new FormData();
      formData.append("companyId", companyId);
      formData.append("roomId", currentRoomId);
      formData.append("message", text.trim());

      if (selectedFile) {
        formData.append("file", selectedFile);
      }

      // The backend broadcasts the persisted message with its durable file URL.
      const saved = await api.sendCompanyMessage(formData);
      if (saved && saved._id) {
        setMessages((prev) => {
          if (prev.some((m) => m._id === saved._id)) return prev;
          return [...prev, saved];
        });
      }

    } catch (err) {
      const errorMsg = err.response?.data?.message || "Failed to send message";
      setStatusMessage(errorMsg);
      setSending(false);
      return;
    }

    // Clean field states
    setText("");
    setSelectedFile(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
    setSending(false);
    setTimeout(loadMessages, 500);
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  // Admin Actions
  const handleCreateChannel = async () => {
    if (!newChannelName.trim()) return;
    try {
      await api.createChannel({
        companyId,
        name: newChannelName.trim(),
        description: newChannelDesc.trim(),
      });
      setNewChannelName("");
      setNewChannelDesc("");
      setShowCreateChannel(false);
      loadChannels();
    } catch (err) {
      setStatusMessage(err.response?.data?.message || "Failed to create channel");
    }
  };

  const handleDeleteChannel = async (channelId) => {
    if (!window.confirm("Delete this channel and all its messages?")) return;
    try {
      await api.deleteChannel(channelId);
      if (activeChannel?._id === channelId) {
        setActiveChannel(null);
      }
      loadChannels();
      setMessages([]);
    } catch (err) {
      setStatusMessage("Failed to delete channel");
    }
  };

  const handleDeleteMessage = async (msgId) => {
    setDeletingMsgId(msgId);
    try {
      await api.deleteCompanyMessage(msgId);
      setMessages((prev) => prev.filter((m) => m._id !== msgId));
    } catch (err) {
      setStatusMessage("Failed to delete message");
    }
    setDeletingMsgId(null);
  };

  const formatTime = (m) => {
    if (m.createdAt) {
      return new Date(m.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    }
    return "";
  };

  const openStoredFile = async (fileUrl, download = false) => {
    try {
      await api.getCompanyFile(fileUrl, { download });
    } catch (err) {
      setStatusMessage('Unable to open that file.');
    }
  };

  return (
    <div className="admin-chat-layout">
      <AdminSidebar />

      <div className="admin-chat-layout-inner">
        <aside className="admin-chat-channel-sidebar">
          <div className="admin-channel-sidebar-header">
            <h3 className="admin-channel-sidebar-title">Channels</h3>
            {isAdmin && (
              <button
                className="admin-channel-add-btn"
                onClick={() => setShowCreateChannel(!showCreateChannel)}
                title="Create Channel"
              >
                +
              </button>
            )}
          </div>

          {showCreateChannel && (
            <div className="admin-create-channel-form">
              <input
                type="text"
                placeholder="Channel name"
                value={newChannelName}
                onChange={(e) => setNewChannelName(e.target.value)}
                className="admin-channel-input"
              />
              <input
                type="text"
                placeholder="Description (optional)"
                value={newChannelDesc}
                onChange={(e) => setNewChannelDesc(e.target.value)}
                className="admin-channel-input"
              />
              <button className="admin-channel-create-btn" onClick={handleCreateChannel}>
                Create
              </button>
            </div>
          )}

          {channels.length === 0 && (
            <p className="admin-channel-empty">No channels yet.</p>
          )}
          <ul className="admin-channel-list">
            {channels.map((ch) => (
              <li key={ch._id} className="admin-channel-list-item">
                <button
                  className={`admin-channel-item ${activeChannel?._id === ch._id ? "active" : ""}`}
                  onClick={() => setActiveChannel(ch)}
                >
                  <span className="admin-channel-hash">#</span>
                  <span className="admin-channel-name">{ch.name}</span>
                </button>
                {isAdmin && (
                  <button
                    className="admin-channel-delete-btn"
                    onClick={() => handleDeleteChannel(ch._id)}
                    title="Delete channel"
                  >
                    ×
                  </button>
                )}
              </li>
            ))}
          </ul>
        </aside>

        <div className="admin-chat-container">
          <div className="admin-chat-header">
            <h2 className="admin-chat-title">
              #{activeChannel?.name || "general"}
            </h2>
            <span className="admin-chat-badge">Admin Access</span>
            {activeChannel?.description && (
              <span className="admin-chat-desc">{activeChannel.description}</span>
            )}
            <span className={`admin-chat-status ${connected ? "connected" : "disconnected"}`}>
              {connected ? "● Connected" : "○ Disconnected"}
            </span>
          </div>

          {statusMessage && (
            <div className="admin-chat-notification">{statusMessage}</div>
          )}

          <div className="admin-chat-box">
            {messages.length === 0 && !statusMessage && (
              <div className="admin-chat-empty">
                No messages yet in #{activeChannel?.name || "this channel"}.
              </div>
            )}
            {messages.map((m, i) => (
              <div key={m._id || i} className={`admin-chat-message ${m.role === "admin" ? "admin" : "employee"}`}>
                <div className="admin-chat-message-top">
                  <div className="admin-chat-sender">
                    {m.senderName || "Unknown"} <span>({m.role || "user"})</span>
                    <span className="admin-chat-time">{formatTime(m)}</span>
                  </div>
                  {isAdmin && (
                    <button
                      className="admin-msg-delete-btn"
                      onClick={() => handleDeleteMessage(m._id)}
                      disabled={deletingMsgId === m._id}
                      title="Delete message"
                    >
                      {deletingMsgId === m._id ? "..." : "×"}
                    </button>
                  )}
                </div>
                <div className="admin-chat-text">
                  {m.message}

                  {/* File Rendering Logic for Admin view */}
                  {m.file && (
                    <div className="chat-file-attachment" style={{ marginTop: '8px' }}>
                      <div style={{ display: 'flex', gap: '9px', alignItems: 'center', flexWrap: 'wrap' }}>
                        <button
                          type="button"
                          onClick={() => openStoredFile(m.file.url, false)}
                          style={{ color: '#9fb8ff', textDecoration: 'underline', background: 'none', border: 0, padding: 0, cursor: 'pointer' }}
                          title="Open file"
                        >
                          {m.file.type?.startsWith("image/") || m.file.fileType?.startsWith("image/") ? '🖼️' : '📄'} {m.file.name || "Open File"}
                        </button>
                        <button
                          type="button"
                          onClick={() => openStoredFile(m.file.url, true)}
                          style={{ color: '#7f8da3', background: 'none', border: 0, padding: 0, cursor: 'pointer', fontSize: '11px' }}
                          title="Download file"
                        >
                          Download
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Integrated Input Wrapper Area */}
          <div className="admin-chat-input-wrapper" style={{ display: 'flex', flexDirection: 'column', gap: '5px', padding: '10px 0' }}>
            {/* File Selected Strip */}
            {selectedFile && (
              <div className="file-preview-strip" style={{ fontSize: '12px', padding: '0 10px', color: '#555' }}>
                📎 Ready to send: <strong>{selectedFile.name}</strong>
                <button 
                  onClick={() => { setSelectedFile(null); if (fileInputRef.current) fileInputRef.current.value = ""; }} 
                  style={{ marginLeft: '10px', color: 'red', background: 'none', border: 'none', cursor: 'pointer' }}
                >
                  Change
                </button>
              </div>
            )}

            <div className="admin-chat-input-area" style={{ display: 'flex', alignItems: 'center' }}>
              {/* Trigger icon for File Upload */}
              <label htmlFor="admin-file-upload" style={{ cursor: 'pointer', padding: '0 10px', fontSize: '20px' }}>
                ➕
              </label>
              <input
                id="admin-file-upload"
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                disabled={sending}
                style={{ display: 'none' }}
              />

              <input
                className="admin-chat-input"
                value={text}
                onChange={(e) => setText(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={`Message #${activeChannel?.name || "general"}...`}
                disabled={sending}
                style={{ flex: 1 }}
              />
              <button
                className="admin-chat-send-btn"
                onClick={sendMessage}
                disabled={sending || (!text.trim() && !selectedFile)}
              >
                {sending ? "Sending..." : "Send"}
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}