import { useEffect, useState, useRef, useCallback, Fragment } from "react";
import api from "../services/mockApi";
import { io } from "socket.io-client";
import { useAuth } from "../context/AuthContext";
import Sidebar from "../components/Sidebar";
import '../main.css';
import '../Chat.css';

const RAW_URL = import.meta.env.VITE_API_URL || "http://localhost:1000";
const SOCKET_URL = RAW_URL.replace(/\/api\/?$/, "");
const POLL_INTERVAL = 5000;

export default function CompanyChat() {
  const { user, refreshUser } = useAuth();
  const [messages, setMessages] = useState([]);
  const [channels, setChannels] = useState([]);
  const [activeChannel, setActiveChannel] = useState(null);
  const [text, setText] = useState("");

  // New State for handling File Selection
  const [selectedFile, setSelectedFile] = useState(null);

  const [connected, setConnected] = useState(false);
  const [sending, setSending] = useState(false);
  const [statusMessage, setStatusMessage] = useState("");

  const socketRef = useRef(null);
  const pollRef = useRef(null);
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null); // Ref to clear input after sending

  const companyId = user?.companyId;

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Refresh user if companyId missing
  useEffect(() => {
    if (user && !user.companyId) {
      refreshUser();
    }
  }, [user, refreshUser]);

  // Load channels
  const loadChannels = useCallback(async () => {
    if (!companyId) return;
    try {
      const data = await api.getChannels(companyId);
      if (Array.isArray(data)) {
        setChannels(data);
        if (!activeChannel && data.length > 0) {
          setActiveChannel(data[0]);
        }
      }
    } catch (err) {
      console.error("Failed to load channels:", err);
    }
  }, [companyId, activeChannel]);

  // Load channels on mount
  useEffect(() => {
    if (companyId) loadChannels();
  }, [companyId, loadChannels]);

  const currentRoomId = activeChannel?._id || "general";

  const loadMessages = useCallback(async () => {
    if (!companyId || !currentRoomId) return;
    try {
      const data = await api.getCompanyMessages(companyId, currentRoomId);
      if (Array.isArray(data)) {
        setMessages((prev) => {
          if (JSON.stringify(prev) === JSON.stringify(data)) return prev;
          return data;
        });
      }
      setStatusMessage("");
    } catch (err) {
      console.error("Failed to load messages:", err);
      setStatusMessage("Could not load messages.");
    }
  }, [companyId, currentRoomId]);

  // Socket + polling + activity feed
  useEffect(() => {
    if (!companyId) return;
    if (!currentRoomId) return;

    loadMessages();

    const socket = io(SOCKET_URL, {
      transports: ["websocket", "polling"],
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 2000,
    });
    socketRef.current = socket;

    socket.on("connect", () => {
      setConnected(true);
      setStatusMessage("");
      socket.emit("join-company-room", { companyId, roomId: currentRoomId });
      socket.emit("join-company-feed", { companyId });

      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
    });

    socket.on("disconnect", () => {
      setConnected(false);
      setStatusMessage("Reconnecting...");
      if (!pollRef.current) {
        pollRef.current = setInterval(loadMessages, POLL_INTERVAL);
      }
    });

    socket.on("connect_error", () => {
      setConnected(false);
      setStatusMessage("Cannot connect to chat server.");
    });

    socket.on("receive-company-message", (msg) => {
      if (msg.roomId === currentRoomId) {
        setMessages((prev) => {
          if (msg._id && prev.some((m) => m._id === msg._id)) return prev;
          return [...prev, msg];
        });
      }
    });

    socket.on("activity-alert", (data) => {
      alert(`🔔 ${data.action}`);
    });

    pollRef.current = setInterval(loadMessages, POLL_INTERVAL);

    return () => {
      socket.off("connect");
      socket.off("disconnect");
      socket.off("connect_error");
      socket.off("receive-company-message");
      socket.off("activity-alert");
      socket.disconnect();
      socketRef.current = null;
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
    };
  }, [companyId, currentRoomId, loadMessages]);

  // Re-join socket room when channel changes
  useEffect(() => {
    if (socketRef.current?.connected && companyId && currentRoomId) {
      socketRef.current.emit("join-company-room", { companyId, roomId: currentRoomId });
    }
  }, [currentRoomId, companyId]);

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const sendMessage = async () => {
    if ((!text.trim() && !selectedFile) || !companyId || !user) {
      setStatusMessage("Unable to send — session incomplete or empty message.");
      return;
    }

    setSending(true);
    setStatusMessage("");

    try {
      // 1. Build FormData for HTTP API Persistence
      const formData = new FormData();
      formData.append("companyId", companyId);
      formData.append("roomId", currentRoomId);
      formData.append("message", text.trim());

      if (selectedFile) {
        formData.append("file", selectedFile); // Append the raw binary file
      }

      // The backend broadcasts the persisted message with its durable file URL.
      const saved = await api.sendCompanyMessage(formData);
      if (saved && saved._id) {
        // Use the database-saved record containing the Cloudinary URL
        setMessages((prev) => {
          // Prevent duplicating if the socket already injected a preview
          if (prev.some((m) => m._id === saved._id)) return prev;
          return [...prev, saved];
        });
      }

    } catch (err) {
      const errorMsg = err.response?.data?.message || "Failed to send message";
      setStatusMessage(errorMsg);
      setSending(false);
      return;
    }

    // Reset fields
    setText("");
    setSelectedFile(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
    setSending(false);
    setTimeout(loadMessages, 500);
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const formatTime = (m) => {
    if (m.createdAt) {
      return new Date(m.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    }
    return "";
  };

  const openStoredFile = async (fileUrl, download = false) => {
    try {
      await api.getCompanyFile(fileUrl, { download });
    } catch (err) {
      setStatusMessage('Unable to open that file.');
    }
  };

  return (
    <div className="chat-layout">
      <Sidebar />
      <div className="chat-layout-inner">
        <aside className="chat-channel-sidebar">
          <h3 className="channel-sidebar-title">Channels</h3>
          {channels.length === 0 && <p className="channel-empty">No channels yet.</p>}
          <ul className="channel-list">
            {channels.map((ch) => (
              <li key={ch._id}>
                <button
                  className={`channel-item ${activeChannel?._id === ch._id ? "active" : ""}`}
                  onClick={() => setActiveChannel(ch)}
                >
                  <span className="channel-hash">#</span>
                  <span className="channel-name">{ch.name}</span>
                </button>
              </li>
            ))}
          </ul>
        </aside>

        <div className="chat-container">
          <div className="chat-header">
            <h2 className="chat-title">#{activeChannel?.name || "general"}</h2>
            {activeChannel?.description && <span className="chat-desc">{activeChannel.description}</span>}
            <span className={`chat-status ${connected ? "connected" : "disconnected"}`}>
              {connected ? "● Connected" : "○ Disconnected"}
            </span>
          </div>

          {statusMessage && <div className="chat-notification">{statusMessage}</div>}

          <div className="chat-box">
            {messages.length === 0 && !statusMessage && (
              <div className="chat-empty">No messages yet in #{activeChannel?.name || "this channel"}.</div>
            )}

            {messages.map((m, i) => (
              <div key={m._id || i} className={`chat-message ${m.role === "admin" ? "admin" : ""}`}>
                <div className="chat-sender">
                  {m.senderName || "Unknown"} <span>({m.role || "user"})</span>
                  <span className="chat-brand-time chat-time">{formatTime(m)}</span>
                </div>
                <div className="chat-text">
                  {m.message}

                  {/* File Rendering Logic */}
                  {m.file && (
                    <div className="chat-file-attachment" style={{ marginTop: '8px' }}>
                      <div style={{ display: 'flex', gap: '9px', alignItems: 'center', flexWrap: 'wrap' }}>
                        <button
                          type="button"
                          onClick={() => openStoredFile(m.file.url, false)}
                          style={{ color: '#9fb8ff', textDecoration: 'underline', background: 'none', border: 0, padding: 0, cursor: 'pointer' }}
                          title="Open file"
                        >
                          {m.file.fileType?.startsWith("image/") ? '🖼️' : '📄'} {m.file.name || "Open File"}
                        </button>
                        <button
                          type="button"
                          onClick={() => openStoredFile(m.file.url, true)}
                          style={{ color: '#7f8da3', background: 'none', border: 0, padding: 0, cursor: 'pointer', fontSize: '11px' }}
                          title="Download file"
                        >
                          Download
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area Group */}
          <div className="chat-input-wrapper" style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
            {/* Tiny Preview strip if a file is loaded */}
            {selectedFile && (
              <div className="file-preview-strip" style={{ fontSize: '12px', padding: '0 10px', color: '#555' }}>
                📎 Ready to send: <strong>{selectedFile.name}</strong>
                <button onClick={() => { setSelectedFile(null); if (fileInputRef.current) fileInputRef.current.value = ""; }} style={{ marginLeft: '10px', color: 'red', background: 'none', border: 'none', cursor: 'pointer' }}>Change</button>
              </div>
            )}

            <div className="chat-input-area" style={{ display: 'flex', alignItems: 'center' }}>
              {/* Hidden Native Input triggered by a styling icon button or simple label */}
              <label htmlFor="chat-file-upload" style={{ cursor: 'pointer', padding: '0 10px', fontSize: '20px' }}>
                ➕
              </label>
              <input
                id="chat-file-upload"
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                disabled={sending}
                style={{ display: 'none' }}
              />

              <input
                className="chat-input"
                value={text}
                onChange={(e) => setText(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={`Message #${activeChannel?.name || "general"}...`}
                disabled={sending}
                style={{ flex: 1 }}
              />
              <button
                className="chat-send-btn"
                onClick={sendMessage}
                disabled={sending || (!text.trim() && !selectedFile)}
              >
                {sending ? "Sending..." : "Send"}
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}