import axios from 'axios';

const baseURL = import.meta.env.VITE_API_URL || 'http://localhost:1000/api';

const getCookie = (name) => {
  const token = document.cookie.split('; ').find((cookie) => cookie.startsWith(`${name}=`));
  return token ? token.split('=')[1] : '';
};

const setAuthToken = (token) => {
  if (token) {
    document.cookie = `aura_token=${token}; path=/; max-age=${60 * 60 * 24 * 7}; SameSite=Lax`;
    localStorage.setItem('aura_token', token);
  }
};
const removeAuthToken = () => {
  document.cookie = 'aura_token=; path=/; max-age=0; SameSite=Lax';
  localStorage.removeItem('aura_token');
  localStorage.removeItem('username');
};

const axiosInstance = axios.create({
  baseURL,
});

axiosInstance.interceptors.request.use((config) => {
  const token = getCookie('aura_token') || localStorage.getItem('aura_token');
  if (token) {
    config.headers = config.headers || {};
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

const api = {
  login: async ({ email, password }) => {
    const response = await axiosInstance.post('/auth/login', { email, password });
    setAuthToken(response.data.token);
    return response.data;
  },
  register: async ({
    name,
    email,
    password,
    companyName
  }) => {

    const response = await axiosInstance.post(
      '/auth/register',
      {
        name,
        email,
        password,
        companyName
      }
    );

    setAuthToken(response.data.token);

    return response.data;
  },
  provisionEmployee: async (data) => {
    const response = await axiosInstance.post(
      '/users/provision',
      data
    );
    return response.data;
  },
  fetchDashboardStats: async () => {
    const response = await axiosInstance.get('/analytics/summary');
    return response.data;
  },
  getAnalyticsSummary: async () => {
    const response = await axiosInstance.get('/analytics/summary');
    return response.data;
  },
  getTasks: async () => {
    const response = await axiosInstance.get('/tasks');
    return response.data;
  },

  createTask: async (task) => {
    const response = await axiosInstance.post('/tasks', task);
    return response.data;
  },

  getReminders: async () => {
    const res = await axiosInstance.get("/reminders");
    return res.data;
  },

  createReminder: async (data) => {
    const res = await axiosInstance.post("/reminders", data);
    return res.data;
  },

  deleteReminder: async (id) => {
    const res = await axiosInstance.delete(`/reminders/${id}`);
    return res.data;
  },

  updateReminder: async (id, patch) => {
    const res = await axiosInstance.put(`/reminders/${id}`, patch);
    return res.data;
  },

  updateTask: async (id, patch) => {
    const response = await axiosInstance.put(`/tasks/${id}`, patch);
    return response.data;
  },

  deleteTask: async (id) => {
    const response = await axiosInstance.delete(`/tasks/${id}`);
    return response.data;
  },

  getNotes: async () => {
    const response = await axiosInstance.get('/notes');
    return response.data;
  },
  getActivities: async () => {
    const response = await axiosInstance.get('/activities');
    return response.data;
  },
  createNote: async (note) => {
    const response = await axiosInstance.post('/notes', note);
    return response.data;
  },

  updateNote: async (id, patch) => {
    const response = await axiosInstance.put(`/notes/${id}`, patch);
    return response.data;
  },

  deleteNote: async (id) => {
    const response = await axiosInstance.delete(`/notes/${id}`);
    return response.data;
  },

  getActivities: async () => {
    const response = await axiosInstance.get('/activities');
    return response.data;
  },

  getAiLogs: async () => {
    const response = await axiosInstance.get('/ai/logs');
    return response.data;
  },
  // RECOGNITIONS API
  getEmployeeRecognitions: async (userId) => {
    const response = await axiosInstance.get(`/recognitions/employee/${userId}`);
    return response.data;
  },

  getCompanyRecognitions: async () => {
    const response = await axiosInstance.get("/recognitions/company");
    return response.data;
  },

  awardRecognition: async (data) => {
    const response = await axiosInstance.post("/recognitions/award", data);
    return response.data;
  },

  deleteRecognition: async (id) => {
    const response = await axiosInstance.delete(`/recognitions/${id}`);
    return response.data;
  },

  getaiLogsForEmployee: async (employeeId) => {
    const response = await axiosInstance.get(`/ai/employee-logs?userId=${employeeId}`);
    return response.data;
  },
  addAiLog: async (log) => {
    const response = await axiosInstance.post('/ai/logs/add', { ...log });
    return response.data;
  },
  buddyChat: async ({ message, history = [] }) => {
    const response = await axiosInstance.post('/buddy/chat', { message, history, clientTimezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC' }, { timeout: 180000 });
    return response.data;
  },

  getCompanyFile: async (fileUrl, { download = false } = {}) => {
    const filename = String(fileUrl || '').split('/').pop();
    if (!filename) throw new Error('Invalid file URL');
    const popup = window.open('about:blank', '_blank');
    try {
      const response = await axiosInstance.get(`/chat-file/token/${encodeURIComponent(filename)}`);
      const origin = baseURL.replace(/\/api\/?$/, '');
      const target = `${origin}${response.data.url}${download ? '?download=1' : ''}`;
      if (popup) {
        popup.location.href = target;
      } else {
        window.location.href = target;
      }
    } catch (error) {
      popup?.close();
      throw error;
    }
  },

  generate: async ({ tool, input }) => {
    const response = await axiosInstance.post('/ai/generate', { type: tool, input });
    return response.data;
  },

  summarizeNote: async ({ content }) => {
    const response = await axiosInstance.post('/ai/generate', { type: 'summarize', input: content });
    return response.data;
  },

  getUsers: async () => {
    const response = await axiosInstance.get('/users');
    return response.data;
  },

  getUserById: async (id) => {
    const response = await axiosInstance.get(`/users/${id}`);
    return response.data;
  },

  getMyProfile: async () => {
    const response = await axiosInstance.get('/users/me');
    return response.data;
  },

  deleteUser: async (id) => {
    const response = await axiosInstance.delete(`/users/delete/${id}`);
    return response.data;
  },

  // Admin Analytics
  getAdminStats: async () => {
    const response = await axiosInstance.get('/analytics/summary');
    return response.data;
  },

  getTotalAIRequests: async () => {
    const response = await axiosInstance.get('/ai/stats/total');
    return response.data;
  },

  getMostUsedTool: async () => {
    const response = await axiosInstance.get('/ai/stats/most-used');
    return response.data;
  },

  getRecentRequests: async (limit = 10) => {
    const response = await axiosInstance.get(`/ai/stats/recent?limit=${limit}`);
    return response.data;
  },

  getMostActiveUsers: async (limit = 10) => {
    const response = await axiosInstance.get(`/ai/stats/active-users?limit=${limit}`);
    return response.data;
  },

  getAIStatistics: async () => {
    const response = await axiosInstance.get('/ai/stats/all');
    return response.data;
  },

  // COMPANY CHAT API
  getCompanyMessages: async (companyId, roomId) => {
    const response = await axiosInstance.get(
      `/chat/${companyId}/${roomId}`
    );
    return response.data;
  },

  sendCompanyMessage: async (formData) => {
    const response = await axiosInstance.post(
      "/chat/send",
      formData,
      {
        headers: {
          "Content-Type": "multipart/form-data"
        }
      }
    );

    return response.data;
  },

  deleteCompanyMessage: async (id) => {
    const response = await axiosInstance.delete(`/chat/message/${id}`);
    return response.data;
  },

  // CHANNELS API
  getChannels: async (companyId) => {
    const response = await axiosInstance.get(`/chat/channels/${companyId}`);
    return response.data;
  },

  createChannel: async (data) => {
    const response = await axiosInstance.post("/chat/channels", data);
    return response.data;
  },

  deleteChannel: async (id) => {
    const response = await axiosInstance.delete(`/chat/channels/${id}`);
    return response.data;
  },


  // CODESPACE / LOCAL PROJECTS
  getProjects: async () => {
    const response = await axiosInstance.get('/projects');
    return response.data;
  },
  getProject: async (id) => {
    const response = await axiosInstance.get(`/projects/${id}`);
    return response.data;
  },
  createProject: async (data) => {
    const response = await axiosInstance.post('/projects', data);
    return response.data;
  },
  updateProject: async (id, data) => {
    const response = await axiosInstance.put(`/projects/${id}`, data);
    return response.data;
  },
  deleteProject: async (id) => {
    const response = await axiosInstance.delete(`/projects/${id}`);
    return response.data;
  },
  upsertProjectFile: async (id, data) => {
    const response = await axiosInstance.post(`/projects/${id}/files`, data);
    return response.data;
  },
  codeSpaceAI: async (id, data) => {
    const response = await axiosInstance.post(`/projects/${id}/ai`, data, { timeout: 300000 });
    return response.data;
  },

  //logout
  logout: async () => {
    removeAuthToken();
  },
};

export default api;