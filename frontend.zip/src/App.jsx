import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import Sidebar from './components/Sidebar';
import Tasks from './pages/Tasks';
import Notes from './pages/Notes';
import AIEngine from './pages/AIEngine';
import Employees from './pages/Employees';
import AILogs from './pages/AILogs';
import Login from './pages/Login';
import Register from './pages/Register';
import Profile from './pages/Profile';
import NotFound from './pages/NotFound';
import AuraAdmin from './pages/AdminDashboard';
import ProtectedRoute from './components/ProtectedRoute';

const App = () => {
  return (
    <div className="app-layout" style={{ display: 'flex', minHeight: '100vh' }}>
      <div className="flex-1" style={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
        <div className="main-content" style={{ padding: '0', flex: 1 }}>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            <Route path="/" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
            <Route path="/tasks" element={<ProtectedRoute><Tasks /></ProtectedRoute>} />
            <Route path="/notes" element={<ProtectedRoute><Notes /></ProtectedRoute>} />
            <Route path="/ai" element={<ProtectedRoute><AIEngine /></ProtectedRoute>} />
            <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />

            <Route path="/admin" element={<ProtectedRoute role="admin"><AuraAdmin /></ProtectedRoute>} />
            <Route path="/employees" element={<ProtectedRoute role="admin"><Employees /></ProtectedRoute>} />
            <Route path="/ailogs" element={<ProtectedRoute role="admin"><AILogs /></ProtectedRoute>} />

            <Route path="*" element={<NotFound />} />
          </Routes>
        </div>
      </div>
    </div>
  );
};

export default App;
