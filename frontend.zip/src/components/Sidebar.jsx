import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Sidebar({ className = '' }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <aside className={`sidebar ${className}`}>
      <div className="logo"><i className="fa-solid fa-microchip"></i> AURORA Workspace</div>
      <ul className="nav-links">
        <li>
          <NavLink to="/" className={({ isActive }) => (isActive ? 'active' : '')}>
            <i className="fa-solid fa-house"></i> My Dashboard
          </NavLink>
        </li>
        <li>
          <NavLink to="/tasks" className={({ isActive }) => (isActive ? 'active' : '')}>
            <i className="fa-solid fa-list-check"></i> Project Tasks
          </NavLink>
        </li>
        <li>
          <NavLink to="/notes" className={({ isActive }) => (isActive ? 'active' : '')}>
            <i className="fa-regular fa-folder-closed"></i> Secure Notes
          </NavLink>
        </li>
        <li>
          <NavLink to="/ai" className={({ isActive }) => (isActive ? 'active' : '')}>
            <i className="fa-solid fa-wand-magic-sparkles"></i> AI Intranet Hub
          </NavLink>
        </li>
        {user?.role === 'admin' && (
          <>
            <li>
              <NavLink to="/admin" className={({ isActive }) => (isActive ? 'active' : '')}>
                <i className="fa-solid fa-server"></i> Admin Root
              </NavLink>
            </li>
            <li>
              <NavLink to="/analytics" className={({ isActive }) => (isActive ? 'active' : '')}>
                <i className="fa-solid fa-chart-simple"></i> Analytics
              </NavLink>
            </li>
          </>
        )}
      </ul>
      <div className="sidebar-footer">
        <div>Logged in as:</div>
        <div>{user?.name || 'Guest'}</div>
      </div>
      <button className="btn-logout" onClick={handleLogout}>
        <i className="fa-solid fa-right-from-bracket"></i> Log Out
      </button>
    </aside>
  );
}
