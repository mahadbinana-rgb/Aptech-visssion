import { createContext, useContext, useEffect, useState } from 'react';
import api from '../services/mockApi';

const AuthContext = createContext();

export const useAuth = () => useContext(AuthContext);

const getStoredUser = () => {
  try {
    return JSON.parse(localStorage.getItem('aura_user')) || null;
  } catch {
    return null;
  }
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(getStoredUser);
  const [token, setToken] = useState(() => localStorage.getItem('aura_token') || '');

  useEffect(() => {
    if (user) {
      localStorage.setItem('aura_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('aura_user');
    }
  }, [user]);

  useEffect(() => {
    if (token) {
      localStorage.setItem('aura_token', token);
      document.cookie = `aura_token=${token}; path=/; max-age=${60 * 60 * 24 * 7}; SameSite=Lax`;
    } else {
      document.cookie = 'aura_token=; path=/; max-age=0; SameSite=Lax';
      localStorage.removeItem('aura_token');
    }
  }, [token]);

  const login = async ({ email, password }) => {
    const res = await api.login({ email, password });
    setUser(res.user);
    setToken(res.token);
    return res;
  };

  const register = async ({ name, email, password }) => {
    const res = await api.register({ name, email, password });
    setUser(res.user);
    setToken(res.token);
    return res;
  };

  const logout = async () => {
    setUser(null);
    setToken('');
    await api.logout();
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export default AuthContext;
