import React, { useState } from 'react';
import mockApi from '../services/mockApi';
import { generateAI } from '../services/aiService';
import '../main.css';
import '../AiEngine.css';

export default function AIEngine() {
  const [type, setType] = useState("startup");
  const [input, setInput] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {

    try {
      setLoading(true);

      const aiResponse = await generateAI(
        type,
        input
      );

      setResult(aiResponse);

    } catch (err) {
      setResult("AI request failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="ai-engine">
      <h2 className="text-2xl">AI Engine</h2>
      <div className="card">
        <div className="ai-input-group">
          <label className="ai-label">Tool</label>
          <select value={tool} onChange={(e) => setTool(e.target.value)} className="ai-select">
            <option value="GenerateIdea">Generate Startup Idea</option>
            <option value="LearningRoadmap">Learning Roadmap</option>
            <option value="ProjectOutline">Project Outline</option>
            <option value="NoteSummarizer">Note Summarizer</option>
          </select>
        </div>
        <div className="ai-input-group">
          <label className="ai-label">Prompt</label>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="ai-textarea"
            placeholder="Enter topic or prompt"
          />
        </div>
        <div className="text-right mt-3">
          <button className="btn btn-primary" onClick={handleGenerate} disabled={loading}>
            {loading ? "Generating..." : "Run"}
          </button>
        </div>
      </div>
      {result && (
        <div className="ai-result">
          <div className="ai-result-title">Result</div>
          <div className="ai-result-content">{result}</div>
        </div>
      )}
    </div>
  );
}
