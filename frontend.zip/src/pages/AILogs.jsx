import React, { useEffect, useState } from 'react';
import mockApi from '../services/mockApi';
import '../main.css';
import '../AiLogs.css';

export default function AILogs() {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    let mounted = true;
    mockApi.getAiLogs().then((l) => {
      if (mounted) setLogs(l);
    }).catch(console.error);
    return () => { mounted = false; };
  }, []);

  return (
    <div>
      <h2 className="text-2xl mb-4">AI Logs</h2>
      <div className="ai-logs-list">
        {logs.map((l) => (
          <div key={l.id} className="log-entry">
            <div className="log-tool">{l.toolType}</div>
            <div className="log-time">{new Date(l.createdAt).toLocaleString()}</div>
            <div className="log-prompt">Prompt: {l.prompt}</div>
            <div className="log-response">{l.response}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
