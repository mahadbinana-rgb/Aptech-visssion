import React, { useEffect, useState } from 'react';
import { Bar, Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, PointElement, LineElement, Tooltip, Legend, Title, Filler } from 'chart.js';
import mockApi from '../services/mockApi';
import { useAuth } from '../context/AuthContext';
import '../main.css';
import '../Dashboard.css';
import Sidebar from '../components/Sidebar';

ChartJS.register(CategoryScale, LinearScale, BarElement, PointElement, LineElement, Tooltip, Legend, Title, Filler);

export default function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [aiInput, setAiInput] = useState('');

  useEffect(() => {
    let mounted = true;
    Promise.all([mockApi.fetchDashboardStats(), mockApi.getTasks()])
      .then(([summary, taskList]) => {
        if (mounted) {
          setStats(summary);
          setTasks(taskList.slice(0, 3));
          setLoading(false);
        }
      })
      .catch(err => {
        console.error('Dashboard load error:', err);
        if (mounted) setLoading(false);
      });
    return () => { mounted = false; };
  }, []);

  const weeklyTaskCompletion = [
    { day: 'Mon', value: 8 },
    { day: 'Tue', value: 11 },
    { day: 'Wed', value: 15 },
    { day: 'Thu', value: 13 },
    { day: 'Fri', value: 18 },
    { day: 'Sat', value: 9 },
    { day: 'Sun', value: 6 },
  ];

  const weeklyAiUsage = [
    { day: 'Mon', value: 4 },
    { day: 'Tue', value: 6 },
    { day: 'Wed', value: 7 },
    { day: 'Thu', value: 10 },
    { day: 'Fri', value: 12 },
    { day: 'Sat', value: 5 },
    { day: 'Sun', value: 3 },
  ];

  const taskChartData = {
    labels: weeklyTaskCompletion.map((item) => item.day),
    datasets: [
      {
        label: 'Completed Tasks',
        data: weeklyTaskCompletion.map((item) => item.value),
        backgroundColor: 'rgba(59, 130, 246, 0.75)',
        borderColor: 'rgba(37, 99, 235, 1)',
        borderWidth: 1,
        borderRadius: 8,
        maxBarThickness: 36,
      },
    ],
  };

  const taskChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      title: {
        display: true,
        text: 'Weekly Task Throughput',
        color: '#e2e8f0',
        font: { size: 14, weight: '600' },
      },
      tooltip: {
        callbacks: {
          label: (context) => `${context.parsed.y} tasks`,
        },
      },
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { color: '#cbd5e1' },
      },
      y: {
        beginAtZero: true,
        grid: { color: 'rgba(148, 163, 184, 0.15)' },
        ticks: { color: '#cbd5e1', stepSize: 5 },
      },
    },
  };

  const aiChartData = {
    labels: weeklyAiUsage.map((item) => item.day),
    datasets: [
      {
        label: 'AI Requests',
        data: weeklyAiUsage.map((item) => item.value),
        fill: true,
        backgroundColor: 'rgba(56, 189, 248, 0.18)',
        borderColor: 'rgba(56, 189, 248, 1)',
        pointBackgroundColor: '#38bdf8',
        tension: 0.35,
      },
    ],
  };

  const aiChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      title: {
        display: true,
        text: 'AI Tool Usage',
        color: '#e2e8f0',
        font: { size: 14, weight: '600' },
      },
      tooltip: {
        callbacks: {
          label: (context) => `${context.parsed.y} requests`,
        },
      },
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { color: '#cbd5e1' },
      },
      y: {
        beginAtZero: true,
        grid: { color: 'rgba(148, 163, 184, 0.15)' },
        ticks: { color: '#cbd5e1', stepSize: 2 },
      },
    },
  };

  const handleProcessAI = () => {
    if (!aiInput.trim()) return;
    alert(`Processing confidential notes locally: "${aiInput.slice(0, 30)}..."`);
  };

  if (loading) {
    return (
      <div className="aura-workspace-container">
        <Sidebar />
        <main className="main-content">
          <div className="card" style={{ padding: '40px', textAlign: 'center' }}>Loading dashboard...</div>
        </main>
      </div>
    );
  }

  return (
    <div className="aura-workspace-container">
      <Sidebar />
      <main className="main-content">
        <header className="header">
          <div>
            <h1>Welcome, {user?.name || 'Employee'}</h1>
            <p>Your strictly confidential productivity dashboard.</p>
          </div>
          <div className="status-badge">
            <div className="pulse"></div> AI Connected to Intranet
          </div>
        </header>

        <div className="dashboard-grid">
          <div className="panel metrics-panel">
            <h3 className="panel-title">Live Summary</h3>
            <div className="stats-row">
              <div className="stat-card">
                <span>Total Employees</span>
                <strong>{stats?.totalEmployees ?? '—'}</strong>
              </div>
              <div className="stat-card">
                <span>Total Tasks</span>
                <strong>{stats?.totalTasks ?? '—'}</strong>
              </div>
              <div className="stat-card">
                <span>Completed</span>
                <strong>{stats?.completedTasks ?? '—'}</strong>
              </div>
              <div className="stat-card">
                <span>AI Requests</span>
                <strong>{stats?.aiRequests ?? '—'}</strong>
              </div>
            </div>
          </div>

          <div className="panel">
            <h3 className="panel-title" style={{ marginBottom: '15px' }}>Pending Tasks</h3>
            <div className="tasks-list">
              {tasks.length > 0 ? tasks.map((task) => (
                <div key={task._id || task.id} className="task-item">
                  <span className={task.completed ? 'completed-text' : ''}>
                    <i className={task.completed ? 'fa-regular fa-circle-check completed-icon' : 'fa-regular fa-circle'}></i>
                    {' '}{task.title || task.text}
                  </span>
                  <span className={`priority-badge priority-${(task.priority || 'Medium').toLowerCase()}`}>
                    {task.priority || 'Medium'}
                  </span>
                </div>
              )) : <div>No tasks found.</div>}
            </div>
          </div>

          <div className="panel chart-panel">
            <h3 className="panel-title">Employee Productivity Charts</h3>
            <div className="dashboard-charts">
              <div className="employee-chart-card chart-card-wrapper">
                <Bar data={taskChartData} options={taskChartOptions} className="chart-wrapper" />
              </div>
              <div className="employee-chart-card chart-card-wrapper">
                <Line data={aiChartData} options={aiChartOptions} className="chart-wrapper" />
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}