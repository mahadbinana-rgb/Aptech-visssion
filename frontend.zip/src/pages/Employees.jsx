import React, { useEffect, useState } from 'react';
import mockApi from '../services/mockApi';
import '../main.css'
import '../Employee.css'

export default function Employees() {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    mockApi.getUsers().then((users) => {
      if (mounted) {
        setEmployees(users);
        setLoading(false);
      }
    }).catch(() => { if (mounted) setLoading(false); });
    return () => { mounted = false; };
  }, []);

  if (loading) return <div className="card">Loading employees...</div>;

  return (
    <div>
      <h2 className="text-2xl mb-4">Employees</h2>
      <div className="employees-grid">
        {employees.map((emp) => (
          <div key={emp._id || emp.id} className="employee-card">
            <div className="employee-name">{emp.name}</div>
            <div className="employee-email">{emp.email}</div>
            <div className="employee-role">{emp.role}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
