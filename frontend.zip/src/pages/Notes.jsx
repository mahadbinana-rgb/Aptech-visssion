import React, { useEffect, useState } from 'react'; 
import mockApi from '../services/mockApi'; 
import '../Notes.css';
import '../main.css';
import { generateAI } from '../services/aiService'; 

export default function Notes() { 
  const [notes, setNotes] = useState([]); 
  const [loading, setLoading] = useState(true); 
  const [content, setContent] = useState(''); 
  // Fix 1: Added state to store summaries mapped by note ID
  const [summaries, setSummaries] = useState({}); 

  // Fix 2: Updated function to store summary by its specific note ID
  const summarizeNote = async (note) => { 
    try {
      const summary = await generateAI("summarize", note.content); 
      setSummaries(prev => ({ ...prev, [note.id]: summary })); 
    } catch (error) {
      console.error("Failed to generate summary:", error);
    }
  };

  useEffect(() => { 
    let mounted = true; 
    mockApi.getNotes().then((n) => { 
      if (mounted) { 
        setNotes(n); 
        setLoading(false); 
      } 
    }).catch(() => { 
      if (mounted) setLoading(false); 
    }); 
    return () => { 
      mounted = false; 
    }; 
  }, []); 

  const add = async () => { 
    if (!content.trim()) return; 
    const n = await mockApi.createNote({ title: content.slice(0, 30), content }); 
    setNotes((s) => [n, ...s]); 
    setContent(''); 
  }; 

  if (loading) return <div className="card">Loading notes...</div>; 

  return ( 
    <div> 
      <h2 className="text-2xl">Notes</h2> 
      <div className="card notes-editor"> 
        <textarea 
          value={content} 
          onChange={(e) => setContent(e.target.value)} 
          className="note-textarea" 
          placeholder="Write a note..."
        ></textarea> 
        <div className="text-right"> 
          <button className="btn btn-primary" onClick={add}>Add Note</button> 
        </div> 
      </div> 
      
      <div className="notes-list"> 
        {notes.map(n => ( 
          // Fix 3: Wrapped components inside a single parent container per map item
          <div key={n.id} className="card note-card"> 
            <div className="note-content"> 
              <div className="note-title">{n.title}</div> 
              <div className="note-text">{n.content}</div> 
            </div> 
            <div className="note-actions"> 
              <button className="btn-summarize" onClick={() => summarizeNote(n)}>
                Summarize with AURA
              </button> 
            </div> 
            {summaries[n.id] && ( 
              <div className="note-summary mt-2 p-2 bg-gray-100 rounded"> 
                <strong>Summary:</strong> {summaries[n.id]} 
              </div> 
            )}
          </div> 
        ))} 
      </div> 
    </div> 
  ); 
}