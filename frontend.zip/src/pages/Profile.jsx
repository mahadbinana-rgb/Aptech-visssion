import React from 'react'
import { useAuth } from '../context/AuthContext'

export default function Profile(){
  const { user } = useAuth()
  return (
    <div>
      <h2 className="text-2xl mb-4">Profile</h2>
      <div className="card">
        <div className="profile-field">
          <div className="profile-label">Name</div>
          <div className="profile-value">{user?.name}</div>
        </div>
        <div className="profile-field">
          <div className="profile-label">Email</div>
          <div className="profile-value">{user?.email}</div>
        </div>
        <div className="profile-field">
          <div className="profile-label">Role</div>
          <div className="profile-value">{user?.role}</div>
        </div>
      </div>
    </div>
  )
}
