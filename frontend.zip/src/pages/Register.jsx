import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import '../Login.css';
import '../main.css';

export default function Register() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { register, user } = useAuth();
  const nav = useNavigate();

  useEffect(() => {
    if (user) {
      nav('/');
    }
  }, [user, nav]);

  const submit = async (e) => {
    e.preventDefault();
    try {
      await register({ name, email, password });
      nav('/');
    } catch (err) {
      alert(err.response?.data?.message || err.message || 'Signup failed');
    }
  };

  return (
    <div className="login-body">
      <div className="login-card">
        <div className="brand">
          <i className="fa-solid fa-microchip"></i> AURORA AI
        </div>
        <div className="subtitle">Create your secure workspace account</div>

        <form onSubmit={submit}>
          <div className="input-group">
            <label>Full Name</label>
            <div className="input-wrapper">
              <i className="fa-solid fa-user"></i>
              <input
                type="text"
                placeholder="Jane Doe"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="input-group">
            <label>Corporate Email</label>
            <div className="input-wrapper">
              <i className="fa-solid fa-envelope"></i>
              <input
                type="email"
                placeholder="employee@company.local"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="input-group">
            <label>Create Password</label>
            <div className="input-wrapper">
              <i className="fa-solid fa-lock"></i>
              <input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
          </div>

          <button type="submit" className="btn-login">
            Create Account
          </button>
        </form>

        <div className="footer-note">
          Already have an account? <Link to="/login">Log in</Link>
        </div>
        <div className="footer-note">
          <i className="fa-solid fa-shield-halved" style={{ color: 'var(--accent-blue)' }}></i>
          Secured Intranet Connection Active
        </div>
      </div>
    </div>
  );
}
