import React, { useEffect, useState } from 'react';
import mockApi from '../services/mockApi';
import '../Tasks.css'
import '../main.css'

export default function Tasks() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    mockApi.getTasks().then((t) => {
      if (mounted) {
        setTasks(t);
        setLoading(false);
      }
    }).catch(() => { if (mounted) setLoading(false); });
    return () => { mounted = false; };
  }, []);

  const toggle = async (id) => {
    const task = tasks.find((x) => x.id === id);
    if (!task) return;
    await mockApi.updateTask(id, { completed: !task.completed });
    setTasks((s) => s.map((x) => (x.id === id ? { ...x, completed: !x.completed } : x)));
  };

  if (loading) return <div className="card">Loading tasks...</div>;

  return (
    <div>
      <h2 className="text-2xl">Tasks</h2>
      <div className="task-list">
        {tasks.map((t) => (
          <div key={t.id} className="card task-item">
            <div className="task-info">
              <div className="task-title">{t.title}</div>
              <div className="task-desc">{t.description}</div>
            </div>
            <div className="task-actions">
              <div className={`task-priority ${t.priority.toLowerCase()}`}>
                {t.priority}
              </div>
              <button className={`task-toggle ${t.completed ? 'done' : ''}`} onClick={() => toggle(t.id)}>
                {t.completed ? 'Completed' : 'Mark Complete'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
