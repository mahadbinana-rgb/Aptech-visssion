import axios from "axios";

const API =
    "http://localhost:5000/api/ai/generate";

export const generateAI = async (
    type,
    input
) => {

    const response =
        await axios.post(API, {
            type,
            input
        });

    return response.data.response;
};