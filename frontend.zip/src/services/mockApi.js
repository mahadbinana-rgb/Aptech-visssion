import axios from 'axios';

const baseURL = import.meta.env.VITE_API_URL || 'http://localhost:1000/api';

const getCookie = (name) => {
  const token = document.cookie.split('; ').find((cookie) => cookie.startsWith(`${name}=`));
  return token ? token.split('=')[1] : '';
};

const setAuthToken = (token) => {
  if (token) {
    document.cookie = `aura_token=${token}; path=/; max-age=${60 * 60 * 24 * 7}; SameSite=Lax`;
    localStorage.setItem('aura_token', token);
  }
};

const removeAuthToken = () => {
  document.cookie = 'aura_token=; path=/; max-age=0; SameSite=Lax';
  localStorage.removeItem('aura_token');
};

const axiosInstance = axios.create({
  baseURL,
});

axiosInstance.interceptors.request.use((config) => {
  const token = getCookie('aura_token') || localStorage.getItem('aura_token');
  if (token) {
    config.headers = config.headers || {};
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

const api = {
  login: async ({ email, password }) => {
    const response = await axiosInstance.post('/auth/login', { email, password });
    setAuthToken(response.data.token);
    return response.data;
  },

  register: async ({ name, email, password }) => {
    const response = await axiosInstance.post('/auth/register', { name, email, password });
    setAuthToken(response.data.token);
    return response.data;
  },

  fetchDashboardStats: async () => {
    const response = await axiosInstance.get('/analytics/summary');
    return response.data;
  },

  getAnalyticsSummary: async () => {
    const response = await axiosInstance.get('/analytics/summary');
    return response.data;
  },

  getTasks: async () => {
    const response = await axiosInstance.get('/tasks');
    return response.data;
  },

  createTask: async (task) => {
    const response = await axiosInstance.post('/tasks', task);
    return response.data;
  },

  updateTask: async (id, patch) => {
    const response = await axiosInstance.put(`/tasks/${id}`, patch);
    return response.data;
  },

  deleteTask: async (id) => {
    const response = await axiosInstance.delete(`/tasks/${id}`);
    return response.data;
  },

  getNotes: async () => {
    const response = await axiosInstance.get('/notes');
    return response.data;
  },

  createNote: async (note) => {
    const response = await axiosInstance.post('/notes', note);
    return response.data;
  },

  updateNote: async (id, patch) => {
    const response = await axiosInstance.put(`/notes/${id}`, patch);
    return response.data;
  },

  deleteNote: async (id) => {
    const response = await axiosInstance.delete(`/notes/${id}`);
    return response.data;
  },

  getActivities: async () => {
    const response = await axiosInstance.get('/activities');
    return response.data;
  },

  getAiLogs: async () => {
    const response = await axiosInstance.get('/ai/logs');
    return response.data;
  },

  generate: async ({ tool, input }) => {
    const response = await axiosInstance.post('/ai/generate', { tool, input });
    return response.data;
  },

  summarizeNote: async ({ content }) => {
    const response = await axiosInstance.post('/ai/generate', { tool: 'NoteSummarizer', input: content });
    return response.data;
  },

  getUsers: async () => {
    const response = await axiosInstance.get('/users');
    return response.data;
  },

  logout: async () => {
    removeAuthToken();
  },
};

export default api;
